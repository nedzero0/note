# JavaWeb项目模板

这个是在maven下做的

pom.xml

```xml
    <!-- https://mvnrepository.com/artifact/mysql/mysql-connector-java -->
    <dependency>
      <groupId>mysql</groupId>
      <artifactId>mysql-connector-java</artifactId>
      <version>8.0.16</version>
    </dependency>

    <!--druid连接池-->
    <!-- https://mvnrepository.com/artifact/com.alibaba/druid -->
    <dependency>
      <groupId>com.alibaba</groupId>
      <artifactId>druid</artifactId>
      <version>1.1.22</version>
    </dependency>

    <!--servlet类-->
    <!-- https://mvnrepository.com/artifact/javax.servlet/javax.servlet-api -->
    <dependency>
      <groupId>javax.servlet</groupId>
      <artifactId>javax.servlet-api</artifactId>
      <version>3.1.0</version>
      <scope>provided</scope>
    </dependency>
    <!--DBUtils工具类-->
    <!-- https://mvnrepository.com/artifact/commons-dbutils/commons-dbutils -->
    <dependency>
      <groupId>commons-dbutils</groupId>
      <artifactId>commons-dbutils</artifactId>
      <version>1.6</version>
    </dependency>

    <!--BeanUtils工具类-->
    <!-- https://mvnrepository.com/artifact/commons-beanutils/commons-beanutils -->
    <dependency>
      <groupId>commons-beanutils</groupId>
      <artifactId>commons-beanutils</artifactId>
      <version>1.9.3</version>
    </dependency>
    <!-- https://mvnrepository.com/artifact/commons-logging/commons-logging -->
    <dependency>
      <groupId>commons-logging</groupId>
      <artifactId>commons-logging</artifactId>
      <version>1.1.1</version>
    </dependency>

    <!--导入JSTL标签库-->
    <!-- https://mvnrepository.com/artifact/org.apache.taglibs/taglibs-standard-impl -->
    <dependency>
      <groupId>org.apache.taglibs</groupId>
      <artifactId>taglibs-standard-impl</artifactId>
      <version>1.2.5</version>
    </dependency>
    <!-- https://mvnrepository.com/artifact/org.apache.taglibs/taglibs-standard-spec -->
    <dependency>
      <groupId>org.apache.taglibs</groupId>
      <artifactId>taglibs-standard-spec</artifactId>
      <version>1.2.5</version>
    </dependency>


```

web.xml

```xml
 
 <servlet-mapping>
    <servlet-name>default</servlet-name>
    <url-pattern>/</url-pattern>
  </servlet-mapping>
  <!--访问不到静态资源的时候再配-->
  <!--对客户端请求的静态资源如图片、js文件等的请求交由默认的servlet进行处理 -->
```

```properties
driverClassName=com.mysql.cj.jdbc.Driver
url=jdbc:mysql://127.0.0.1:3306/aa?&useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8
username=root
password=182008
#aa是我的数据库名称
```



## **JdbcUtils(工具类)**

```java
public class JdbcUtils {

    private static DataSource dataSource;
    //注册驱动  用druid连接池
    static {
        try {
            //读取jdbc.properties 属性配置文件
            InputStream resource = JdbcUtils.class.getClassLoader().getResourceAsStream("conn.properties");
            Properties properties = new Properties();
            //从流中加载数据
            properties.load(resource);
            //创建数据库连接池
            dataSource = DruidDataSourceFactory.createDataSource(properties);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
   //获得连接
    public static Connection getConn(){
        try {
            return dataSource.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
   //关闭连接 ， 放回数据库连接 池
    public static void close(Connection conn){
        if (conn != null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
```

## WebUtils工具类

**导入BeanUtils第三方包**：专门   从前端获取数据

使用见下面的servlet  User举例

```java
public class WebUtils {
 /* 把Map中的值注入到对应的JavaBean 属性中。
    比如 注册的时候，把表单的数据封装到bean中   因为request请求都是键值对，即map*/

 public static <T> T copyParamToBean(Map value,T bean){
     try {
         //注入属性
         BeanUtils.populate(bean,value);
     } catch (IllegalAccessException e) {
         e.printStackTrace();
     } catch (InvocationTargetException e) {
         e.printStackTrace();
     }
     return bean;
 }

/**
 * 将字符串转换成为int类型的数据
 * @param strInt
 * @param defaultValue
 * @return
 */

public static int parseInt(String strInt,int defaultValue){
    if (strInt!=null){
        try {
            return Integer.parseInt(strInt);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    return defaultValue;
}


}



使用如User
  User user = WebUtils.copyParamToBean(req.getParameterMap(), new User());
  int id = WebUtils.parseInt(req.getParameter("id"), 0);
```

![无标题](JavaWeb.assets/无标题.png)

## Bean包(user举例)

User类：

```java
public class User {
    private int id;
    private String name;
    private int age;
................
get set方法等
.........
```



## dao包：

### **BaseDao(工具类)**

**导入DbUtils第三方工具包进行操作**

```java
/最基本的dao，所有类型的 dao都可以用的
public class BaseDao {
    // 使 用 DbUtils操 作 数 据 库
    private QueryRunner queryRunner = new QueryRunner();

    //update()方法用来执行: Insert \Update\Delete语句
    public int update(String sql,Object...args){
        Connection conn = JdbcUtils.getConn();
        try {
            return queryRunner.update(conn,sql,args);
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.close(conn);
        }
        return -1;
    }

    //查询返回多个javaBean的 sql语 句,返回一个list<T>对象
    public <T> List<T> queryForList(Class<T> type,String sql,Object...args){
        Connection conn = JdbcUtils.getConn();
        try {
            return queryRunner.query(conn,sql,new BeanListHandler<T>(type),args);
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.close(conn);
        }
        return null;
    }

    //返回一个对象
    public <T> T queryForOne(Class<T> type,String sql,Object...args){
        Connection conn = JdbcUtils.getConn();
        try {
            return queryRunner.query(conn,sql,new BeanHandler<T>(type),args);
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.close(conn);
        }
        return null;
    }
   //其它方法
   ..................

}
```

###  User举例

UserDao

```java
//User 对象的 CRUD
public interface UserDao {
  //增：添加保存user
  public int saveUser(User user);
  //查：返回全部user数据
  public List<User> queryAll();
  //查：返回一个user对象
  public User queryUserByname(String name);

  //删：删除一个user 根据id
  public int delUserOne(int id);


}

```

 UserDaoImpl

```java
public class UserDaoImpl extends BaseDao implements UserDao {
    @Override
    public int saveUser(User user) {
        String sql = "INSERT INTO `user`(NAME,age)\n" +
                "VALUES (?,?)";
        return update(sql,user.getName(),user.getAge());
    }

    @Override
    public List<User> queryAll() {
        String sql = "SELECT *FROM user";
        return queryForList(User.class,sql);
    }
```

## **service包（User为例）：**

 UserService

```java
public interface UserService {
    //注册用户
    public void registUser(User user);
    //登录
    public User login(User user);
    //用户名是否可用
    public boolean existUsername(String name);
    //显示所有用户
    public List<User> showUserAll();
    //删除一个用户，根据id
    public int delUserOne(int id);

}
```

UserServiceImpl

```java
public class UserServiceImpl implements UserService {
    UserDao userDao = new UserDaoImpl();

    //注册
    @Override
    public void registUser(User user) {
        userDao.saveUser(user);
    }

    //登录
    @Override
    public User login(User user) {
        return null;
    }
    //查看用户名是否存在
    @Override
    public boolean existUsername(String name) {
         if (userDao.queryUserByname(name)!=null) return true;
        return false;
    }
    //展示所有用户
    @Override
    public List<User> showUserAll() {
        return userDao.queryAll();
    }

    @Override
    public int delUserOne(int id) {
        return userDao.delUserOne(id);
    }
}
```

## **servlet包：**

### BaseServlet(工具类)

```java
//Servlet的基类
public class BaseServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
          // 解决post请求中文乱码问题
        req.setCharacterEncoding("UTF-8");
           // 解决响应中文乱码问题
        resp.setContentType("text/html;charset = UTF-8");
           // 获取action鉴别字符串，获取相应方法名 action必须是存在的方法名
        String action = req.getParameter("action");
           //通过反射获得对应的方法
        try {
            Method method = this.getClass().getDeclaredMethod(action,HttpServletRequest.class,HttpServletResponse.class);
               // 调用目标业务 方法
            method.invoke(this,req,resp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

### User举例

UserServlet

```java
@WebServlet("/userServlet")
public class UserServlet extends BaseServlet{
    UserService userService = new UserServiceImpl();

    //展示所有user
    protected void showUserAll(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<User> list = userService.showUserAll();

        req.setAttribute("users",list);

        req.getRequestDispatcher("/page/showUserAll.jsp").forward(req,resp);

    }

    protected void delUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
         int userid = Integer.parseInt(req.getParameter("userid"));
        System.out.println(userid);

         int delresult = userService.delUserOne(userid);

         //req.setAttribute("delresult",delresult);
        showUserAll(req,resp);

    }
}
//注册
protected void registUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        User user = WebUtils.copyParamToBean(req.getParameterMap(), new User());

        userService.registUser(user);
        showUserAll(req,resp);

    }

```



## 前端测试

index.jsp

```jsp
<h1>测试，跳转到user列表页面</h1>
<a href="userServlet?action=showUserAll" target="_blank">跳转</a>
```

showUserAll.jsp

```jsp
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page isELIgnored="false" %>
....................

<table>
    <tr>
        <td>id</td>
        <td>name</td>
        <td>age</td>
    </tr>

    <c:forEach items="${requestScope.users}" var="user">
        <tr>
            <td>${user.id}</td>
            <td>${user.name}</td>
            <td>${user.age}</td>
            <td><a href="#">修改</a></td>
            <td><a href="userServlet?action=delUser&userid=${user.id}" target="_blank">删除</a></td>

        </tr>
    </c:forEach>

```

registUser.jsp  注册

```jsp
<form action="../userServlet?action=registUser" method="post">
    用户名：<input type="text" name="name">
    年龄：<input type="text" name="age">
    <input type="submit" value="提交">

</form>
```







h5,css,js

form标签是表单标签
action属性设置提交的服务器地址
method属性设置提交的方式GET(默认值)或POST
**表单提交的时候，数据没有发送给服务器的三种情况:**
1、表单项没有name属性值
2、单选、复选（下拉列表中的option标签）都需要添加value属性，以便发送给服务器
3、表单项不在提交的form标签中



GET请求的特点是:
1、浏览器地址栏中的地址是:action属性[+?+请求参数]
请求参数的格式是:name=value&name=value
2、不安全
3、它有数据长度的限制

POST请求的特点是:
1、浏览器地址栏中只有action属性值
2、相对于GET请求要安全
3、理论上没有数据长度的限制

**在html页面引入jquery**，只需在页面中添加下面内容即可，src属性表示引入的路径，按住ctrl键，如果看到有个手型图标，可以点进去，说明引入成功

<script language="JavaScript" src="../js/jquery-1.11.1.js"></script>
# Tomcat

Tomcat服务器下载,安装,配置环境变量等教程：https://blog.csdn.net/qq_40881680/article/details/83582484

https://www.cnblogs.com/yjd_hycf_space/p/7483921.html

**1.启动**：命令行输入：startup.bat        
会打开一个窗口，表示Tomcat启动，这个窗口不能关闭，关闭了tomcat就关闭了  在idea项目中配置了就可以关闭了

**2.idea配置tomcat项目：**

![1602225428252](JavaWeb.assets\1602225428252.png)

![1602295129838](JavaWeb.assets\1602295129838.png)

**都要应用：点击Apply，同时最好改名与当前工程名一致，即服务器名 = 工程名，注意要先在deployment里配置工程路径   见下下下图**

![1602295302907](JavaWeb.assets\1602295302907.png)

![1602301737687](JavaWeb.assets\1602301737687.png)

on ‘update‘ action：当用户主动执行更新的时候更新　　　　快捷键:Ctrl + F9 
 on frame deactication:在编辑窗口失去焦点的时候更新 
**完成热部署**：即jsp页面更新     F5刷新页面将可以了，不用重新部署 ，**注意浏览器要  勾选  禁用缓存**

![1602295337574](JavaWeb.assets\1602295337574.png)

改完后的路径为：http://localhost:8770/servlet_01/ 

**启动：**

<img src="JavaWeb.assets\1602147406044.png" alt="1602147406044" style="zoom:67%;" />



## 注意

**可能要手动输入地址，如：http://localhost:8770/servlet_01/       servlet_01是我的服务器名**

tomcat默认的8080端口  可能  不能应用于项目，要在idea中手动建立web项目端口，如下例：

解决idea启动java的web项目端口占用：
**方法一(建议使用)**：
选择更换我们启动项目的端口，点击idea的Run菜单，选择Edit Configurations，打开Run/Debug Configurations对话框。修改port端口值，选择一个没有使用的端口即可，如果不确定，同样可以使用netstat命令查询修改的新端口是否被占用。
![1600841924583](JavaWeb.assets\1600841924583.png)

**方法二：**

关闭被占用的端口的应用，但该应用可能是必须的
第一步，win+R打开window窗口,输入命令提示符号，执行命令：netstat -ano
找到占用端口的进程的PID：如占用8080端口的进程的PID是47676
第二步，通过任务管理器关闭PID的对应的应用。(也可以通过 tasklist  命令找到应用)
第三步，重新启动tomcat，即可正常启动



# JDBC

详细的学习总结：https://www.cnblogs.com/--zz/p/9811818.html

详细的学习总结：尚硅谷JDBC课件里的JDBC.md文档

导入jar

<img src="JavaWeb.assets\1601006152326.png" alt="1601006152326" style="zoom: 67%;" />

**注意，在java中的jdbc语句都必须是  字符串  类型///////////////////////////////**

## **实例：**

```java
import java.sql.Connection;
import java.sql.*;

public class Test0 {
    public static void main(String[] args) throws Exception{
    
   String dburl = "jdbc:mysql://127.0.0.1:3306/test?&useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8";     
   // 时区与SLL连接方式禁用,强制改变驱动的编码方式  数据库名：test
   
        Connection conn = null;
        //加载数据库驱动程序
        try{
    //1.加载JDBC驱动，不同数据库版本可能是 com.mysql.cj.jdbc.Driver，不是8.0版本的好像用这个
            Class.forName("com.mysql.jdbc.Driver");//这是常用的加载方式
    //2.获得数据库的连接，连接对象：dburl,用户名：root,密码：182008 
            conn = DriverManager.getConnection(dburl,"root","182008");
     //3.获取数据库操作对象，创建Statement\PreparedStatement对象对数据库操作
          Statement stmt = conn.createStatement(); 
     //4.执行sql语句
            String sql = "select id,name from user";       
            ResultSet rst = stmt.executeQuery(sql);
            
          //查看是否有结果，必须要.next()  因为返回的是结果集，要next()才能读出来
         while (rst.next()){//和迭代器的next类似
     //以列的名字获取
           String id = rst.getString("id");
           String name = rst.getString("name");
     //$$$最好用   以列的下标获取
           //String id = rst.getString(1);
           //String id = rst.getString(2);
           
           System.out.println(id+"   "+name);
           //getString()方法不管数据库中的数据类型是什么，都以string的形式取出
         }
        或
         /* 
      String sql = "insert into user(id,name,pwd,sex,home,info) value(?,?,?,?,?,?)";
      PreparedStatement pre;
      try{
         //4.执行sql语句  预处理，下标从1开始 ?号表示占位符
          pre = (PreparedStatement) conn.prepareStatement(sql);
          pre.setInt(1,14);//   ?号直接替换为14
          pre.setString(2,"张三");//  ?号替换为'张三'，在语句中加了''号 ，因为是字符串类型
          pre.setString(3,"788002");
          pre.setString(4,"男");
          pre.setString(5,"迪夫");
          pre.setString(6,"eee");
          //执行
         pre.execute();
         */
        
         
         
         //5.释放资源，关闭对象
         rst.close();
         stmt.close();
         conn.close();
        }catch (ClassNotFoundException cne){
            cne.printStackTrace();
        }
        catch (SQLException se){
            se.printStackTrace();
        }
    }
}

```

**实例2：**

```java
//1.封装Connection  并返回   还可以再 封装驱动(用静态代码块)，封装释放资源(传参依次释放)
public class DaoUtil {
    private static final  String dburl = "jdbc:mysql://127.0.0.1:3306/manages?&useSSL=false&serverTimezone=UTC";
    
    public static Connection getConn(){
        Connection conn = null;
        //加载数据库驱动程序
        try{
            //1.加载JDBC驱动，不同版本可能是 com.mysql.cj.jdbc.Driver
            Class.forName("com.mysql.jdbc.Driver");
            //2.数据库的连接
            conn = DriverManager.getConnection(dburl,"root","182008");
        }catch (ClassNotFoundException cne){
            cne.printStackTrace();
        }
        catch (SQLException se){
            se.printStackTrace();
        }
        return conn;
    }
}

 //2.查看所有学生信息
    public static void showStudent(){
        //1.建立与数据库的连接 Connection
        Connection conn = DaoUtil.getConn();
        //2.创建 statement
        Statement stmt = null;
        try {

            stmt = conn.createStatement();
            String sql = "select stu.*,cla.cl_name " +
                    "from student stu left join class cla on stu.cl_id = cla.cl_id order by s_id\n";
            //定义结果集
            ResultSet rst = null;
            //3.执行
            rst = stmt.executeQuery(sql);
            //4.处理结果集，查看是否有结果，next判断是否有下一个
            while (rst.next()){
                System.out.println(rst.getString("s_id")+"\t"+rst.getString("s_name")+"\t"+
                        rst.getString("s_sex")+"\t"+rst.getString("s_birth")
                        +"\t班级："+rst.getString("cl_name")+"\t学号："+rst.getString("s_no"));
            }
            //关闭流
            rst.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
//3.添加学生 
    public static void addStudent(Student student){
        Connection conn = DaoUtil.getConn();
        int i;
     String sql = "insert into student(s_name,s_sex,s_birth,cl_id,s_no,s_pws) value(?,?,?,?,?,?)";
   //PreparedStatement: 预编译,可以让SQL拥有参数,防止SQL注入
    PreparedStatement pre;
      try{
          //添加语句，由于有？号，暂时没有执行，进行了预编译
          pre = (PreparedStatement) conn.prepareStatement(sql);
         //与sql语句的？号对应
         pre.setString(1,student.getName());//第一个？号
          pre.setString(2,student.getSex());
          pre.setString(3,student.getBirth());
         pre.setString(4,student.getCl_id());
         pre.setString(5,student.getS_no());
         pre.setString(6,student.getS_pws());

       i =  pre.executeUpdate();//执行语句，返回int
         if (i>0){
             System.out.println("添加成功");
         }
         else {
             System.out.println("添加失败,学号重复");
         }

         pre.close();
          conn.close();
     } catch (SQLException e) {
          e.printStackTrace();
     }
```



## **通用配置**

### **普通配置**

**Properties文件内容:**

```
driver=com.mysql.jdbc.Driver
url=jdbc:mysql://127.0.0.1:3306/manages?&useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8
user=root
password=182008

initialSize=10
maxActive=20
maxWait=1000
filters=wall
```



**数据库的连接和关闭（不用连接池）：**

```
public class DaoUtil {
    private static final String driver;
    private static final String url;
    private static final String user;
    private static final String password;
    //不使用连接池
    static {
        //调用Properties文件信息    conn是Properties文件名  我的conn在src下
        ResourceBundle bundle = ResourceBundle.getBundle("conn");//conn是Properties文件名
        driver = bundle.getString ("driver");
        url = bundle.getString ("url");
        user = bundle.getString ("user");
        password = bundle.getString ("password");
        //1.加载JDBC驱动，不同版本可能是 com.mysql.cj.jdbc.Driver
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    public static Connection getConn(){
        Connection conn = null;
        //加载数据库驱动程序
        try{
            //2.数据库的连接
            conn = DriverManager.getConnection(url,user,password);
        } catch (SQLException se){
            se.printStackTrace();
        }
        return conn;
    }

    // 释放资源   conn 连接对象  ps数据库操作对象  rs结果集(可能没有)，因此还要重载close方法
    public static void close(Connection conn, Statement ps, ResultSet rs){
        if (rs != null){
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (ps != null){
            try {
                ps.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
```

### **druid连接池配置**

**Properties文件内容（username这些字段是固定的，不能自己命名）:**

```
driverClassName=com.mysql.jdbc.Driver
url=jdbc:mysql://127.0.0.1:3306/test?&useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8&allowPublicKeyRetrieval=true
username=root
password=182008

initialSize=10
maxActive=20
maxWait=1000
filters=wall
```

**数据库的连接和关闭（使用德鲁伊(druid)连接池）：**

```
public class DaoUtil {

    private static DataSource dataSource;
    //注册驱动  用druid连接池
    static {
        try {
               //读取jdbc.properties 属性配置文件
            InputStream resource = DaoUtil.class.getClassLoader().getResourceAsStream("conn.properties");
            Properties properties = new Properties();
            //从流中加载数据
            properties.load(resource);
            //创建数据库连接池
            dataSource = DruidDataSourceFactory.createDataSource(properties);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
   //获得连接
    public static Connection getConn(){
        try {
            return dataSource.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    //释放资源  无结果集的
    private static void close(Connection conn, Statement ps) {
        if (ps != null){
            try {
                ps.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }
    //释放资源  有结果集的
    public static void close(Connection conn, Statement ps, ResultSet rs){
        close(conn,ps);
        if (rs != null){
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }


```

### 共有的(自己写的)

**使用PreparedStatement实现增、删、改操作**

```
	//通用的增、删、改操作（体现一：增、删、改 ； 体现二：针对于不同的表）
	public void update(String sql,Object ... args){
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			//1.获取数据库的连接
			conn = JDBCUtils.getConnection();
			
			//2.获取PreparedStatement的实例 (或：预编译sql语句)
			ps = conn.prepareStatement(sql);
			//3.填充占位符
			for(int i = 0;i < args.length;i++){
				ps.setObject(i + 1, args[i]);
			}
			
			//4.执行sql语句
			ps.execute();
		} catch (Exception e) {
			
			e.printStackTrace();
		}finally{
			//5.关闭资源
			JDBCUtils.closeResource(conn, ps);
			
		}
	}
```

**使用PreparedStatement实现查询操作**

```
// 通用的针对于不同表的查询:返回一个对象 (version 1.0)
	public <T> T getInstance(Class<T> clazz, String sql, Object... args) {

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			// 1.获取数据库连接
			conn = JDBCUtils.getConnection();

			// 2.预编译sql语句，得到PreparedStatement对象
			ps = conn.prepareStatement(sql);

			// 3.填充占位符
			for (int i = 0; i < args.length; i++) {
				ps.setObject(i + 1, args[i]);
			}

			// 4.执行executeQuery(),得到结果集：ResultSet
			rs = ps.executeQuery();

			// 5.得到结果集的元数据：ResultSetMetaData
			ResultSetMetaData rsmd = rs.getMetaData();

			// 6.1通过ResultSetMetaData得到columnCount,columnLabel；通过ResultSet得到列值
			int columnCount = rsmd.getColumnCount();
			if (rs.next()) {
				T t = clazz.newInstance();
				for (int i = 0; i < columnCount; i++) {// 遍历每一个列

					// 获取列值
					Object columnVal = rs.getObject(i + 1);
					// 获取列的别名:列的别名，使用类的属性名充当
					String columnLabel = rsmd.getColumnLabel(i + 1);
					// 6.2使用反射，给对象的相应属性赋值
					Field field = clazz.getDeclaredField(columnLabel);
					field.setAccessible(true);
					field.set(t, columnVal);

				}

				return t;

			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			// 7.关闭资源
			JDBCUtils.closeResource(conn, ps, rs);
		}

		return null;

	}
	
	
或
public static void getAll(String sql){
      Connection conn = null;
      PreparedStatement ps = null;
      ResultSet rs = null;
      try {
          conn = DaoUtil.getConn();
          ps = conn.prepareStatement(sql);
          rs = ps.executeQuery();
          //// 获取结果集的元数据
          ResultSetMetaData rsmd = rs.getMetaData();
          //// 获取结果集的列数
          int count = rsmd.getColumnCount();
          while (rs.next()){
            for (int i=1;i<=count;i++){
                System.out.print(rs.getObject(i)+"\t\t");
            }
              System.out.println("\t");

          }

      } catch (Exception e) {

          e.printStackTrace();
      }finally{
          DaoUtil.close(conn,ps,rs);

      }
}

```



## **基本知识**

### 基本

**API:**
java.sql.*
javax.sql.*

**连接数据库相关的:**

**DriverManager：**
　　  用URL连接数据库,
   　   在4.0版本之前要进行加载.  即用映射加载驱动 Class.forName("com.mysql.jdbc.Driver");
          DriverManager 会返回一个Connection

 **DataSource** 
　　 相对于DriverManager类,DataSource更适合用于获取操作数据的Connection对象,
　　 它相对灵活,并且支持 JNDI ,可以为servlet容器提供连接池 

 **Connection接口：**
　　 负责连接数据库并担任传送数据的任务。

**数据库SQL相关的:**

**Statement接口：**
　　负责执行SQL语句。凡是业务方面要求是需要进行sql语句拼接的，必须使用statement
        **PreparedStatement:** 预编译,可以让SQL拥有参数,**防止SQL注入，一般有参数的话，都用它**
        **CallableStatement:**  可以Statement基础上执行存储过程
**ResultSet接口：**
　　负责保存Statement执行后所产生的查询结果。**用next读出**
        以**列的下标获取或以列的名字获取，JDBC中所有下标从1开始**。不是从0开始**，列名是查询结果集的列名，不是表的列名，最好用下标获取**
**RowSet接口:**
　　RowSet 比 ResultSet 功能更多,更易使用,所有的RowSet对象都继承于 ResultSet.

**PreparedStatement设置和ResultSet取读最好分别都用     setObject  和getObject**   



**使用JDBC 的步骤（看上面的实例）**

-  **注册 驱动(告诉Java程序，即将要连接的是哪个品牌的数据库)**
-  **建立 与数据库的连接 (这属于进程之间的通信，重量级的，使用完之后一定要关闭)**
-  **获取数据库操作对象，即创建 statement或preparedStatement**
-  **执行 sql语句,即用execute等执行**
-  **处理 结果集(ResultSet)(只有当第四步执行的是select语句的时候，才有这第五步处理查询结果集)**
-  **关闭 连接，释放资源(使用完资源之后一定要关闭资源。Java和数据库属于进程间的通信，开启之后一定要关闭)**

**executeQuery** 只执行查 (select语句)   返回的是ResultSet
**executeUpdate** 执行 增删改  (insert或者update/delete（DML）语句，返回影响数据库中的记录条数(>0执行成功)  或者 什么也不返回的DDL语句)
**execute** 执行 增删改查    如果第一个结果是 ResultSet 对象，则返回 true；如果第一个结果是更新计数或者没有结果，则返回 false
意思就是如果是查询的话返回true，如果是更新或插入的话就返回false了；
**注意**：executeQuery 是只能执行一条SQL 语句的,要执行多条需要用到批处理

**关闭步骤（遵循从小到大依次关闭，最好分别对其用try..catch）**

**一般步骤是:**

```
} finally {
 try{
   if (stmt != null){ 
   stmt.close(); 
   }
  }catch(...){
   .......
  }
 try{
   if (conn != null){ 
   conn.close(); 
   }
  }catch(...){
   .......
  }  
}
```

 不过后来JAVA 7出那个新特性,可以用try来自动关闭了

```
try (Statement stmt = con.createStatement()) {...}
```

**将连接数据库的所有信息配置到配置文件中**
**注意**：实际开发中不建议把连接数据库的信息写死到java程序中，常用配置文件存储信息。

**1.创建Properties文件，文件中存储信息：**
driver=com.mysql.jdbc.Driver
url=jdbc:mysgl://192.168.151.9:3306/bjpowernode
user=root
password=981127

**2.在程序中调用Properties文件信息**

```
ResourceBundle bundle = ResourceBundle.getBundle("jdbc");//jdbc是Properties文件名
String driver = bundle.getString ("driver");
String url = bundle.getString ("url");
String user = bundle.getString ("user") ;
String password = bundle.getString ("password");
..............
   Class.forName(driver);  
   conn = DriverManager.getConnection(url,user,password);
   ...............
```

**JDBC实现模糊查询：**

```
String sql = "select ename from emp where ename like ?";
ps =conn.preparestatement (sql) ;
ps.setString (1,"_A%");
....................
```

**操作BLOB类型字段，批量插入，数据库连接池等看另一个文档**

### druid连接池配置文档

```
driverClassName=com.mysql.jdbc.Driver //驱动加载
url=jdbc:mysql://127.0.0.1:3306/student?characterEncoding=utf-8 //注册驱动
username=root //连接数据库的用户名
password=sjw58586 //连接数据库的密码。
filters=stat //属性类型的字符串，通过别名的方式配置扩展插件， 监控统计用的stat 日志用log4j 防御sql注入:wall
initialSize=2 //初始化时池中建立的物理连接个数。
maxActive=300 //最大的可活跃的连接池数量
maxWait=60000 //获取连接时最大等待时间，单位毫秒，超过连接就会失效。配置了maxWait之后，缺省启用公平锁，并发效率会有所下降， 如果需要可以通过配置useUnfairLock属性为true使用非公平锁。
timeBetweenEvictionRunsMillis=60000 // 连接回收器的运行周期时间，时间到了清理池中空闲的连接，testWhileIdle根据这个判断
minEvictableIdleTimeMillis=300000
validationQuery=SELECT 1 //用来检测连接是否有效的sql，要求是一个查询语句。
testWhileIdle=true //建议配置为true，不影响性能，并且保证安全性。 申请连接的时候检测，如果空闲时间大于timeBetweenEvictionRunsMillis， 执行validationQuery检测连接是否有效。
testOnBorrow=false //申请连接时执行validationQuery检测连接是否有效，做了这个配置会降低性能。设置为false
testOnReturn=false //归还连接时执行validationQuery检测连接是否有效，做了这个配置会降低性能,设置为flase
poolPreparedStatements=false //是否缓存preparedStatement，也就是PSCache。
maxPoolPreparedStatementPerConnectionSize=200 // 池中能够缓冲的preparedStatements语句数量
```

## DBUtils工具类（重要）

**DBUtils封装了对JDBC的操作，简化了JDBC操作，可以少写代码。** 
Dbutils三个核心功能介绍： 
 \1. QueryRunner中提供对sql语句操作的API. 
 \2. ResultSetHandler接口，用于定义select操作后，怎样封装结果集. 
 \3. DbUtils类，它就是一个工具类,定义了关闭资源与事务处理的方法



## 注意：

**程序可能存在的问题（SQL注入）:**
如sql语句为：

```
 String sql = "SELECT t_id,t_name,t_sex,t_no\n" +
                    "FROM teacher\n" +
                    "WHERE t_no = "+no+" "+"AND t_pws = "+pws+"";
             //no是工号   pws是密码
```

输入：
用户名:fdsa
密码:fdsa' or '1'='1
登录成功
这种现象被称为**SQL注入**(安全隐患)。（黑客经常使用）
**导致SQL注入的根本原因是什么?**
用户输入的信息中含有sql语句的关键字，并且这些关键字参与sql语句的编译过程，导致sql语句的原意被扭曲，进而达到sql注入。

**解决SQL注入问题?**
**只要用户提供的信息不参与SQL语句的编译过程**，问题就解决了。
即使用户提供的信息中含有SQL语句的关键字，但是没有参与编译，不起作用。
要想用户信息不参与SQL语句的编译，那么必须使用java.sql.Preparedstatement
Preparedstatement接口继承了java.sql.statement
Preparedstatement是属于预编译的数据库操作对象。
PreparedStatement的原理是:预先对SQL语句的框架进行编译，然后再给SQL语句传""值""。

**对比一下statement和Preparedstatement?**

- statement存在sql注入问题，Preparedstatement解决了sql注入问题。
- Statement是编译一次执行一次。Preparedstatement是编译一次，可执行N次。Preparedstatement效率较高一些。
- Preparedstatement会在编译阶段做类型的安全检查。
综上所述: Preparedstatement使用较多。只有极少数的情况下需要使用statement

**什么情况下必须使用statement呢?**
业务方面要求必须支持sql注入的时候。
statement支持sql注入，凡是业务方面要求是需要进行sql语句拼接的，必须使用statement

**JDBC的事务自动提交机制（重要）：**

只要执行一条语句就提交一次
即  i =  pre.executeUpdate();   

会造成  有两条pre.executeUpdate()  语句  第二条不执行   因为两条语句不在同一个事务里 ，报空指针异常
**重点三行代码解决自动提交机制?**
conn.setAutoCommit(false) ;   //关闭自动提交机制
conn.comit();   //手动提交
conn.rollback();   //回滚事务

```
  ..............
    Connection conn = DaoUtil.getConn();
    ...........
    PreparedStatement pre;
    conn.setAutoCommit(false) ;//关闭自动提交机制
    try{
    .................
     i =  pre.executeUpdate();
     conn.comit();   //手动提交
    }catch(....){
    if(conn!=null){
      try{
         conn.rollback();   //回滚事务
      } 
    }
    }
    关闭连接
    ...........
```






![1602053464483](JavaWeb.assets\1602053464483.png)

# XML

XML 指**可扩展标记语言**（e**X**tensible **M**arkup **L**anguage）
XML **被设计用来传输和存储数据,其焦点是数据的内容。**。

XML 文档形成了一种**树结构**，它从"根部"开始，然后扩展到"枝叶"。

**结构：**

**属性:**
version 是版本号 
encoding 是 xml 的文件编码 
standalone="yes/no" 表示这个 xml 文件是否是独立的 xml 文件

```xml
<?xml version="1.0" encoding="UTF-8"?>
<note id="501">
<to>Tove</to>
<from>Jani</from>
<heading>Reminder</heading>
<body>Don't forget me this weekend!</body>
</note>

note是根元素  接下来 4 行描述根的 4 个子元素
上面的 id 属性仅仅是一个标识符，用于标识不同的便签。它并不是便签数据的组成部分。
```

**语法规则**：
**1.XML 文档必须有根元素**
**2.必须有XML 声明(第一行)**
**3.所有的 XML 元素都必须有一个关闭标签**
**4.XML 标签对大小写敏感**
**5.XML 必须正确嵌套**
**6.XML 属性值必须加引号，如<note date="12/11/2007">**
**7.实体引用：一些字符拥有特殊的意义。见下图**
**8.XML 中的注释：html 和 XML 注释 一样 :<!-- html 注释 -->**
**9.在 XML 中，空格会被保留**
**10.XML 以 LF 存储换行**：
在 Windows 应用程序中，换行通常以一对字符来存储：回车符（CR）和换行符（LF）。
在 Unix 和 Mac OSX 中，使用 LF 来存储新行。
在旧的 Mac 系统中，使用 CR 来存储新行。
XML 以 LF 存储换行。

**XML 属性**(属性可以提供元素的额外信息)：在 XML 中，您应该尽量避免使用属性
**XML 属性必须加引号：**
<person sex="female">或<person sex='female'>
如果属性值本身包含双引号，您可以使用单引号，就像这个实例：
<gangster name='George "Shotgun" Ziegler'>
或者您可以使用字符实体：<gangster name="George &quot;Shotgun&quot; Ziegler">

```xml
<note date="10/01/2008"></note>
最好改为：
<note>
<date>
<day>10</day>
<month>01</month>
<year>2008</year>
</date>
</note>

因使用属性而引起的一些问题：
属性不能包含多个值（元素可以）
属性不能包含树结构（元素可以）
属性不容易扩展（为未来的变化）
属性难以阅读和维护。请尽量使用元素来描述数据。而仅仅使用属性来提供与数据无关的信息。
```

**针对元数据的 XML 属性**
有时候会向元素分配 ID 引用。这些 ID 索引可用于标识 XML 元素，它起作用的方式与 HTML 中 id 属性是一样的。这个实例向我们演示了这种情况：

```xml
<messages>
<note id="501">
<to>Tove</to>
<from>Jani</from>
<heading>Reminder</heading>
<body>Don't forget me this weekend!</body>
</note>
<note id="502">
<to>Jani</to>
<from>Tove</from>
<heading>Re: Reminder</heading>
<body>I will not</body>
</note>
</messages>
上面的 id 属性仅仅是一个标识符，用于标识不同的便签。它并不是便签数据的组成部分。
```

**在此我们极力向您传递的理念是：元数据（有关数据的数据）应当存储为属性，而数据本身应当存储为元素。**

**xml 解析**:

**javascript读取xml：**
使用 XMLHttpRequest 对象从服务器取回 XML 信息。

```xml
下面的实例把 XML 文档（"note.xml"）解析到 XML DOM 对象中，然后通过 JavaScript 提取一些信息：

<html>
<body>
<h1>W3Schools Internal Note</h1>
<div>
<b>To:</b> <span id="to"></span><br />
<b>From:</b> <span id="from"></span><br />
<b>Message:</b> <span id="message"></span>
</div>

<script>
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.open("GET","note.xml",false);
xmlhttp.send();
xmlDoc=xmlhttp.responseXML;

document.getElementById("to").innerHTML=
xmlDoc.getElementsByTagName("to")[0].childNodes[0].nodeValue;
document.getElementById("from").innerHTML=
xmlDoc.getElementsByTagName("from")[0].childNodes[0].nodeValue;
document.getElementById("message").innerHTML=
xmlDoc.getElementsByTagName("body")[0].childNodes[0].nodeValue;
</script>

</body>
</html>
```



**java读取xml的4种方法：**
第一种 DOM 实现方法：
第二种，DOM4J实现方法
第三种 JDOM实现方法：
第四种SAX实现方法：
其中 DOM 和 Sax 已经过时，但我们需要知道这两种技术

**dom4j 解析技术（重点）**

```xml
需要到 dom4j 官网下载 dom4j 的 jar 包

dom4j 编程步骤：
第一步： 先加载 xml 文件创建 Document 对象 
第二步：通过 Document 对象拿到根元素对象 
第三步：通过根元素.elelemts(标签名); 可以返回一个集合，这个集合里放着。所有你指定的标签名的元素对象
第四步：找到你想要修改、删除的子元素，进行相应在的操作 
第五步，保存到硬盘上

xml：
<?xml version="1.0" encoding="UTF-8"?> 
<books> 
<book sn="SN12341232"> 
<name>辟邪剑谱</name> 
<price>9.9</price>
<author>班主任</author> 
</book> 
<book sn="SN12341231"> 
<name>葵花宝典</name> 
<price>99.99</price> 
<author>班长</author> 
</book> 
</books>

遍历 标签 获取所有标签中的内容（*****重点）
public void readXML() throws DocumentException {
// 需要分四步操作:
// 第一步，通过创建 SAXReader 对象。来读取 xml 文件，获取 Document 对象
// 第二步，通过 Document 对象。拿到 XML 的根元素对象
// 第三步，通过根元素对象。获取所有的 book 标签对象
// 第四步，遍历每个 book 标签对象。然后获取到 book 标签对象内的每一个元素，再通过 getText() 方法拿到
        起始标签和结束标签之间的文本内容

// 第一步，通过创建 SAXReader 对象。来读取 xml 文件，获取 Document 对象
        SAXReader reader = new SAXReader();
        Document document = reader.read("src/books.xml");
// 第二步，通过 Document 对象。拿到 XML 的根元素对象
        Element root = document.getRootElement();
// 打印测试
// Element.asXML() 它将当前元素转换成为 String 对象
// System.out.println( root.asXML() );
// 第三步，通过根元素对象。获取所有的 book 标签对象
// Element.elements(标签名)它可以拿到当前元素下的指定的子元素的集合
        List<Element> books = root.elements("book");
// 第四小，遍历每个 book 标签对象。然后获取到 book 标签对象内的每一个元素，
        for (Element book : books) {
// 测试
// System.out.println(book.asXML());
// 拿到 book 下面的 name，price，author 元素对象
            Element nameElement = book.element("name");
            Element priceElement = book.element("price");
            Element authorElement = book.element("author");
// 再通过 getText() 方法拿到起始标签和结束标签之间的文本内容
            System.out.println("书名" + nameElement.getText() + " , 价格:" + priceElement.getText() + ", 作者：" + authorElement.getText()); } }
```



![1602233897511](JavaWeb.assets\1602233897511.png)

**dom4j** **与** **sax** **之间的对比：【注：必须掌握！】**

```java
 /*  dom4j不适合大文件的解析，因为它是一下子将文件加载到内存中，所以有可能出现内存溢出，
   sax是基于事件来对xml进行解析的，所以他可以解析大文件的xml
   也正是因为如此，所以dom4j可以对xml进行灵活的增删改查和导航，而sax没有这么强的灵活性
   所以sax经常是用来解析大型xml文件，而要对xml文件进行一些灵活（crud）操作就用dom4j
```



# Servlet

什么是 Servlet
1、Servlet 是 JavaEE 规范之一。规范就是接口 
2、Servlet 就 JavaWeb 三大组件之一。三大组件分别是：Servlet 程序、Filter 过滤器、Listener 监听器。 
3、Servlet 是运行在服务器上的一个 java 小程序，**它可以接收客户端发送过来的请求，并响应数据给客户端**。

**通俗流程解释：**
客户端通过get或post方式向服务器**发送请求**，服务器根据请求的类型**执行相应的方法(doGet或doPost方法**)，方法内有HttpServletRequest  req和HttpServletResponse  resp两个参数，req获取客户端信息，resp可以返回信息。同时在**方法内可以通过JDBC与数据库交互，从而实现前后端的交互**(通常JDBC程序(增删查改)要统一写成函数，只提供方法接口，在servlet中直接调用方法就可以了)

**Servlet 的生命周期**

1、执行 Servlet 构造器方法 
2、执行 init 初始化方法
3、执行 service 方法 第三步，每次访问都会调用。
4、执行 destroy 销毁方法 第四步，在 web 工程停止的时候调用。
第一、二步，是在第一次访问的时候创建 Servlet 程序会调用。

## Servlet类中自定义方法

必须要在父类中实现doGet和doPost方法
父类BaseServlet继承HttpServlet，同时实现了doGet和doPost方法；子类继承它，然后实现自定义方法，就可以在<a>等标签中调用自定义的方法：

**详情见下面的    在jsp中调用servlet自定义类   这是大纲中的名字**

Servlet 类的继承体系：

![1602468192080](JavaWeb.assets\1602468192080.png)

## **简单的servlet程序和介绍：**

**先要导包 servlet-api**

1.编写一个类实现 service ，实现doGet,doPost方法   
2.到 web.xml 中去配置 servlet   或**用注解配置(主流)**        二者不能同时使用

**在doGet和doPost方法中编写java代码，如和数据库交互的方法接口**

**一般在实际项目开发中，都是使用继承 HttpServlet 类的方式去实现 Servlet 程序。**

```java
//1.HelloWorld类：
public class HelloWorld extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("doGet方法");
        //java程序  
        //如JDBC接口 
        Teacher_Dao.showTeacher();  //从数据库显示教师信息********************
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("doPost方法");
         //java程序  
         //如JDBC接口 
         //Teacher_Dao.showTeacher();  //从数据库显示教师信息******************
    }
}

//2.web.xml配置信息 或 用注解配置信息 （两种方法二选一）
<web-app>
    <servlet>
        <servlet-name>HelloWorld</servlet-name>
        <servlet-class>HelloWorld</servlet-class>
    </servlet>
    <servlet-mapping>
        <servlet-name>HelloWorld</servlet-name>
        <url-pattern>/hello2</url-pattern>
    </servlet-mapping>
    
      <!-- servlet标签给Tomcat配置Servlet程序-->
    <!--servlet-name标签servlet程序起一个别名（一般是类名）-->
    <!--servlet-class是servlet 程序的全类名,如果直接在src目录下可以填写类名
    或如com.atguigu.servlet.HelloServlet，前面三个字段是src目录下的包名-->
    <!--servlet-mapping 标签给servlet程序配置访问地址-->
    <!--servlet-name标签的作用是告诉服务器，我当前配置的地址给哪个servlet程序使用,和上面的一样-->
    <!--urL-pattern 标签配置访问地址
    斜杠在服务器解析的时候，表示地址为: http://ip:port/工程路径
    /hello2  表示地址为: http://ip:port/工程路径/hello2
  -->
    <!-- 默认访问的地址：index.jsp，路径是 http://ip:port/工程路径/(可加index.jsp)    工程路径就是tomcat服务器名 -->
   <!--两个servlet-name的值必须相同 -->
   
</web-app>

//3.jsp文件
<form action="http://localhost:8770/servlet_01/hello2" method="post">
      <input type="submit" value="按钮">
  </form>
```

## **web.xml配置或注解配置**

**二者不能同时使用**

web.xml配置：详细见上方代码实例

**注解配置：**
**@WebServlet("/hello")**   /hello  是工程名，即访问地址名

```
@WebServlet("/hello")   //  /hello  是工程名，即访问地址名
public class HelloWorld extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
     ...................
    }
```

只需在对应的servlet类中添加servlet注解即可，从浏览器发送请求时，是用当前“项目（web_bs_shopping）”下的路径，会去对应servlet类的上面寻找是否存在对应url名称的@webServlet注解，存在的话，调用并执行对应的servlet类,**url配置和xml一样，即xml的url-pattern和注解的urlPatterns一样**

**注解访问servlet：**
优点：代码少，可读性强，易于理解
缺点：如果大量使用servlet注解，servlet类文件数量过多，不便于查找和修改

**web配置文件访问servlet：**
优点：集中管理各servlet类路径的映射路径，便于修改和管理
缺点：代码多，可读性不强，不易于理解 

注意：有时候在服务上运行的web程序数据不能及时更新，记得重启服务器或者清除浏览器缓存



## ServletConfig和ServletContext

**ServletConfig可以在xml配置init-param**
**ServletContext可以在xml配置context-param，ServletContext对应的是整个web应用程序**

**ServletConfig 类**

是 Servlet 程序的**配置信息类**
Servlet 程序和 ServletConfig 对象都是由 Tomcat 负责创建，我们负责使用。 
Servlet 程序默认是第一次访问的时候创建，ServletConfig 是每个 Servlet 程序创建时，就创建一个对应的 ServletConfig 对象。

**三大作用**
1、可以获取 Servlet 程序的别名 servlet-name 的值 
2、获取初始化参数 **init-param** 
3、获取 ServletContext 对象

web.xml 中的配置：

```xml
<servlet>
        <servlet-name>HelloWorld</servlet-name>
        <servlet-class>HelloWorld</servlet-class>
        <!--init-param是 初 始 化 参 数 -->
        <init-param>
            <!--是 参 数 名 -->
            <param-name>username</param-name>
            <!--是 参 数 值 -->
            <param-value>root</param-value>
        </init-param>
        <!--init-param 是 初 始 化 参 数 -->
        <init-param>
            <!--是 参 数 名 -->
            <param-name>url</param-name>
            <!--是 参 数 值 -->
            <param-value>jdbc:mysql://localhost:3306/test</param-value>
        </init-param>
</servlet>
```

Servlet 中的代码：

```java
    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        System.out.println("2 init 初始化方法");
// 1 、 可 以 获 取 Servlet程 序 的 别 名 servlet-name的 值
        System.out.println("HelloServlet 程序的别名是:" + servletConfig.getServletName());
// 2 、 获 取 初 始 化 参 数 init-param
        System.out.println("初始化参数 username 的值是;" + servletConfig.getInitParameter("username")); 
        System.out.println("初始化参数 url 的值是;" + servletConfig.getInitParameter("url"));
// 3 、 获 取 ServletContext 对 象
        System.out.println(servletConfig.getServletContext());
    }

```

**注意点：**

当是继承HttpServlet的时候：要调用父类的init方法
![1602484737339](JavaWeb.assets\1602484737339.png)



### **ServletContext 类**

1、ServletContext 是一个接口，它表示 **Servlet 上下文对象** 
2、一个 web 工程，只有一个 ServletContext 对象实例。 
3、**ServletContext 对象是一个域对象**。 
4、ServletContext 是在 web 工程部署启动的时候创建。在 web 工程停止的时候销毁。

**ServletContext 类的四个作用(获取上下文)**
1、获取 web.xml 中配置的上下文参数 **context-param** 
2、获取当前的工程路径，格式:/工程路径 
3、获取工程部署后在服务器硬盘上的绝对路径 
4、**像 Map 一样存取数据**

ServletContext 演示代码：

```java
 protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("doGet方法");
        // 1 、 获 取 web.xml中 配 置 的 上 下 文 参 数 context-param
         ServletContext context = getServletConfig().getServletContext();
        String username = context.getInitParameter("username");
        // 2 、 获 取 当 前 的 工 程 路 径 ， 格 式 : / 工 程 路 径
        System.out.println( "当前工程路径:" + context.getContextPath() );
        // 3 、 获取工程部署后在服务器硬盘上的绝对路径
        //   /  斜杠被服务器解析地址为 :http://ip:port/工程名/    映射到IDEA代码的web目录
        System.out.println("工程部署的路径是:" + context.getRealPath("/"));
        System.out.println("工程下 css 目录的绝对路径是:" + context.getRealPath("/css"));
        System.out.println("工程下 imgs 目录 1.jpg 的绝对路径是:" + context.getRealPath("/imgs/1.jpg"));

    }
```

web.xml 中的配置：

```xml
<!--context-param是上下文参数(它属于整个web工程)-->
<context-param>
<param-name>username</param-name>
<param-value>context</param-value>
</context-param>
<! --context-param是上下文参数(它属于整个web工程)-->
<context-param>
<param-name>password</param-name>
<param-value>root</param-value>
</context-param>
```

ServletContext 像 Map 一样存取数据：

```java
在自定义ContextServlet1类的doGet方法中：
//获 取 ServletContext对 象 
ServletContext context = getServletContext(); 
System.out.println(context); 
System.out.println("保存之前: Context1 获取 key1 的值是:"+ context.getAttribute("key1"));

context.setAttribute("key1", "value1");

System.out.println("Context1 中获取域数据 key1 的值是:"+ context.getAttribute("key1"));

在自定义ContextServlet2类的doGet方法中：
ServletContext context = getServletContext(); 
System.out.println(context); 
System.out.println("Context2 中获取域数据 key1 的值是:"+ context.getAttribute("key1"));

在ContextServlet1中定义的，ContextServlet2也可以得到 
因此体现了存取数据的操作范围，是整个 web 工程。   
```



### **域对象** 

域对象，是可以像 Map 一样存取数据的对象，叫域对象。 
这里的**域指的是存取数据的操作范围，整个 web 工程。**

|        | 存数据         | 取数据         | 删除 数据          |
| ------ | -------------- | -------------- | ------------------ |
| Map    | put()          | get()          | remove()           |
| 域对象 | setAttribute() | getAttribute() | removeAttribute(); |

如：
req.setAttribute("stuList",list);
List<Student> list = (List<Student>) request.getAttribute("stuList")

**四大域对象**经常用来保存数据信息。和下面的   jsp中的 5.四大域对象   没什么区别

**Servlet中只有后三个域对象，JSP中多了一个pageContext对象。**

| pageContext  (PageContextImpl类)          | 当前 jsp 页面范围内有效                                    | 封装了8大隐式对象(PageContext对象是JSP页面中才有的对象)      |
| ----------------------------------------- | ---------------------------------------------------------- | ------------------------------------------------------------ |
| request      (HttpServletRequest  类)     | 一次请求内有效                                             | 在整个请求链中共享数据和获得客户端信息                       |
| session       (HttpSession 类)、          | 一个会话范围内有效（打开浏览器访问服务器，直到关闭浏览器） | 服务器在运行时可以为每一个用户的浏览器创建一个其独享的session对象，用户将自己的数据储存在session中，其它web资源也可以用了，节约了空间和时间。 |
| servletContext       (ServletContext  类) | 整个 web 工程范围内都有效（只要 web 工程不停止，数据都在） | 多个Servlet通过ServletContext对象实现数据共享；获取web应用的初始化参数；用ServletContext实现请求转发；利用ServletContext对象读取资源文件 |

**四个域的作用域范围大小和优先顺序**:
PageContext （page域） < request < session < servletContext（application域）

注意：**servletContext和application 是一样的**，就相当于一个类创建了两个不同名称的变量。
          两者的区别就是application用在jsp中，servletContext用在servlet中getAttribute()和findAttribute()的区别

getAttribute()只能获取自己域中保存的属性
而findAttribute()则会按照pageContext->request->session->servletContext的顺序查找有无对应的属性。

详情见：https://www.jianshu.com/p/6c02951267d8

## HttpServletRequest 类(重要)

每次只要有请求进入 Tomcat 服务器，Tomcat 服务器就会把请求过来的 HTTP 协议信息解析好封装到 Request 对象中。 然后传递到 service 方法（doGet 和 doPost）中给我们使用。我们可以通过 HttpServletRequest 对象，获取到所有请求的 信息。

**HttpServletRequest 类的常用方法(很多方法内可以添加参数哦，只是这里没显示出来)**

| i.    getRequestURI()            | 获取请求的资源路径                   |
| -------------------------------- | ------------------------------------ |
| ii.   getRequestURL()            | 获取请求的统一资源定位符（绝对路径） |
| iii.   getRemoteHost()           | 获取客户端的ip地址                   |
| iv.   getHeader()                | 获取请求头                           |
| v.  **getParameter()**           | 获取请求的参数                       |
| vi.  getParameterValues()        | 获取请求的参数（多个值的时候使用）   |
| vii.  getMethod()                | 获取请求的方式GET或POST              |
| viii.  setAttribute(key, value); | 设置域数据                           |
| ix.  getAttribute(key);          | 获取域数据                           |
| x.   getRequestDispatcher()      | 获取请求转发对象                     |

**getParameter()**   内添加input内的name参数 ，可以获得input的内容，如：req.getParameter("username"); 

常用API示例代码：

```java
public class RequestAPIServlet extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException {
//	i.getRequestURI()	获取请求的资源路径
System.out.println("URI => " + req.getRequestURI());
//	ii.getRequestURL()	获取请求的统一资源定位符（绝对路径）
System.out.println("URL => " + req.getRequestURL());
//	iii.getRemoteHost()	获取客户端的ip地址
/**
*	在IDEA中，使用localhost访问时，得到的客户端ip 地址是===>>> 127.0.0.1
*	在IDEA中，使用127.0.0.1访问时，得到的客户端ip 地址是===>>> 127.0.0.1
*	在IDEA中，使用真实ip 访问时，得到的客户端ip 地址是===>>> 真实的客户端ip 地址
*/
System.out.println("客户端 ip地址 => " + req.getRemoteHost());
//	iv.getHeader()	获取请求头
System.out.println("请求头User-Agent ==>> " + req.getHeader("User-Agent"));
//
}
}	vii.getMethod()	获取请求的方式GET或POST
System.out.println( "请求的方式 ==>> " + req.getMethod() );
```

### 表单、servlet实例

**如何获取请求参数表单**  

```java
//表单：
<form action="http://localhost:8770/servlet_01/hello2" method="get">
      用户名：<input type="text" name="username"><br/>
      密码：<input type="password" name="password"><br>
      兴趣爱好：
      <input type="checkbox" name="hobby" value="C">C
      <input type="checkbox" name="hobby" value="JAVA">JAVA
      <input type="checkbox" name="hobby" value="PHP">PHP
      <input type="submit" value="get">
  </form>
  
//Java 代码：
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("doGet方法");

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String[] hobby = req.getParameterValues("hobby");
        System.out.println("用户名："+username);
        System.out.println("密码："+password);
        System.out.println("兴趣爱好："+ Arrays.toString(hobby));
    }
```

**doGet 请求的中文乱码解决**：

```java
// 获取请求参数
String username = req.getParameter("username");
//1 先以iso8859-1进行编码
//2 再以utf-8进行解码
username = new String(username.getBytes("iso-8859-1"), "UTF-8");
```

**POST 请求的中文乱码解决**

```java
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
// 设置请求体的字符集为UTF-8，从而解决post请求的中文乱码问题
req.setCharacterEncoding("UTF-8");
System.out.println("-------------doPost------------");
// 获取请求参数
String username = req.getParameter("username");
String password = req.getParameter("password");
String[] hobby = req.getParameterValues("hobby");
System.out.println("用户名：" + username);
System.out.println("密码：" + password);
System.out.println("兴趣爱好：" + Arrays.asList(hobby));
}

```

### 请求的转发

什么是请求的转发? 
请求转发是指，服务器收到请求后，从一个资源跳转到另一个资源的操作叫请求转发。
请求转发是服务器内部把对一个request/response的处理权，移交给另外一个 
对于客户端而言，它只知道自己最早请求的那个A，而不知道中间的B，甚至C、D。 **传输的信息不会丢失。**

**转发通俗解释**：假设你去办理某个执照，你先去了A局，A局看了以后，知道这个事情其实应该B局来管，但是他没有把你退回来，而是让你坐一会儿，自己到后面办公室联系了B的人，让他们办好后，送了过来。

在doGet或doPost方法里编写代码：
**request.getRequestDispatcher(URL地址).forward(request, response)**

**转发是服务器行为**
**传输的信息不会丢失。**

**请求转发的特点:**
1、浏览器地址栏没有变化
2、他们是**一次请求**
3、他们**共享Request域中的数据**
4、可以转发到WEB-INF目录下
5、不可以访问工程以外的资源

```java
Servlet1 代码：
public class Servlet1 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    
      //请求转发必须要以斜杠打头，╱斜杠表示地址为:http://ip:port/工程名/，映射到IDEA代码的web目录
      //req.getRequestDispatcher(URL地址).forward(request, response)
      //req.getRequestDispatcher("new.jsp").forward(request, response);//转发到new.jsp
      req.getRequestDispatcher("/servlet2").forward(request, response);//转发到/servlet2
    
    }
}
Servlet2 代码：
public class Servlet2 extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
IOException {
      // 处理自己的业务
      System.out.println("2222222222");
      ......................
}
}

xml文件部署：
参照上面的配置实例
```







 **/ 斜杠的不同意义**

![1602559189445](JavaWeb.assets\1602559189445.png)

**base 标签的作用:就是将工程路径赋给它，后面的所有链接 都自动带有了它(就不用重复写工程路径了)**

<img src="JavaWeb.assets\1602557985530.png" alt="1602557985530" style="zoom:67%;" />

```html
<!DOCTYPE html> 
<html lang="zh_CN"> 
<head> 
<meta charset="UTF-8"> 
<title>Title</title> 
<!--base 标 签 设 置 页 面 相 对 路 径 工 作 时 参 照 的 地 址 href 属 性 
就 是 参 数 的 地 址 值 --> 
     <base href="http://localhost:8080/07_servlet/a/b/"> 
</head> 
<body> 
   这是 a 下的 b 下的 c.html 页面<br/> 
   <a href="../../index.html">跳回首页</a><br/> 
</body> 
</html>


或
<head>
<base href="http://localhost:8770/servlet_01/">
   ul li {
            list-style: none;
        }
</head>
<body>    

<%--因为CookieServlet类继承的BaseServlet类中重写了doGet和doPost方法，才可以用下面a链接中的写法--%>
<li><a href="cookieServlet?action=createCookie" target="target">Cookie的创建</a></li>

</body>
```

**在实际开发中，路径都使用绝对路径，而不简单的使用相对路径。** 
1、绝对路径 
2、base+相对

## HttpServletResponse类(重要) 

HttpServletResponse 类和 HttpServletRequest 类一样。每次请求进来，Tomcat 服务器都会创建一个 Response 对象传递给 Servlet 程序去使用。HttpServletRequest 表示请求过来的信息，HttpServletResponse 表示所有响应的信息，我们如果需要设置返回给客户端的信息，都可以通过 HttpServletResponse 对象来进行设置

**注意**：使用了字节流 getOutputStream();  ，就不能再使用字符流getWriter();  ，反之亦然，否则就会报错。

常用方法
设置响应头
    setHeader(String name,String value);//在响应头中添加响应信息，但是同键会覆盖 。可以改编码格式
    addHeader(String name,String value);//在响应头中添加响应信息，但是不会覆盖。
设置响应状态
     sendError(int num,String msg);//自定义响应状态码。
设置响应实体
     resp.getWrite().write(String str);//响应具体的数据给浏览器
设置响应编码格式：
     resp.setContentType("text/html;charset=utf-8");//不仅发送到浏览器的内容会使用UTF-8编码，而且还通知浏览器使用UTF-8编码方式进行显示。所以总能正常显示中文
     resp.setCharacterEncoding(“UTF-8”);
加入Cookie对象:
     resp.addCookie(“key”,"value")//这个对象将被浏览器所保存
请求重定向:
    response.sendRedirect("new.jsp");//重定向到new.jsp

**实例**

```java
如何往客户端回传数据要求：往客户端回传字符串数据
public class ResponseIOServlet extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
IOException {
//	要求：往客户端回传字符串数据。
   PrintWriter writer = resp.getWriter(); 
   writer.write("response's content!!!"); 
   //或直接： resp.getWriter().write("good");
   }
}
```

### **响应的乱码解决**  

```java
解决响应中文乱码方案一（不推荐使用）：
// 设置服务器字符集为UTF-8
resp.setCharacterEncoding("UTF-8");
// 通过响应头，设置浏览器也使用UTF-8字符集
resp.setHeader("Content-Type", "text/html; charset=UTF-8"); 

解决响应中文乱码方案二（推荐）：
// 它会同时设置服务器和客户端都使用UTF-8字符集，还设置了响应头
// 此方法一定要在获取流对象之前调用才有效
resp.setContentType("text/html; charset=UTF-8");     //   text/html是固定的，不要改
```

### 请求重定向

请求重定向，是指客户端给服务器发请求，然后服务器告诉客户端说。我给你一些地址。你去新地址访问。叫请求重定向（因为之前的地址可能已经被废弃)

重定向，其实是至少两次request, 
第一次，客户端request  A,服务器响应，并response回来，告诉浏览器，你应该去B。这个时候IE可以看到地址变了，而且历史的回退按钮也亮了。重定向可以访问自己web应用以外的资源。**在重定向的过程中，传输的信息会被丢失。**

**重定向通俗解释**：假设你去办理某个执照，你先去了A局，A局的人说：“这个事情不归我们管，去B局”，然后，你就从A退了出来，自己乘车去了B局。 

在doGet或doPost方法里编写代码：
**response.sendRedirect("new.jsp");//重定向到new.jsp**

**重定向是客户端行为**
**传输的信息会被丢失**

**请求重定向的特点:**
1、浏览器地址栏会发生变化
2、**两次请求**
3、**不共享Request域中数据**
4、不能访问WEB-INF下的资源
5、可以访问工程外的资源

```java
//请求重定向的第一种方案：
// 设置响应状态码302 ，表示重定向，（已搬迁）
resp.setStatus(302);
// 设置响应头，说明新的地址在哪里
resp.setHeader("Location", "http://localhost:8080");

//请求重定向的第二种方案（推荐使用）：
resp.sendRedirect("http://localhost:8080//服务器名//访问地址名");
//或如： resp.sendRedirect("/servlet_01/hello2");

```



## HTTP 协议 

所谓 HTTP 协议，就是指，客户端和服务器之间通信时，发送的数据，需要遵守的规则，叫 HTTP 协议。
HTTP 协议中的数据又叫报文。HTTP的底层是TCP/IP

客户端给服务器发送数据叫请求。 
服务器给客户端回传数据叫响应。
请求又分为 GET 请求，和 POST 请求两种

**请求的 HTTP 协议格式：**

常用的是get和post

**GET 请求：**
1、请求行 
      (1) 请求的方式                             GET
      (2) 请求的资源路径[+?+请求参数]     /06_servlet/a.html
      (3) 请求的协议的版本号              HTTP/1.1 
2、请求头 key:value    组成不同的键值对，表示不同的含义。
详细的见下图

**POST 请求：**
1、请求行 
      (1) 请求的方式                             POST
      (2) 请求的资源路径[+?+请求参数]     /06_servlet/hello
      (3) 请求的协议的版本号              HTTP/1.1 
2、请求头 
      key:value     不同的请求头，有不同的含义 
      **空行**
3、请求体 ===>>> 就是发送给服务器的数据
详细的见下图

常用请求头的说明:
Accept: 表示客户端可以接收的数据类型 
Accpet-Languege: 表示客户端可以接收的语言类型 
User-Agent: 表示客户端浏览器的信息 
Host： 表示请求时的服务器 ip 和端口号

哪些是 GET 请求，哪些是 POST 请求:
GET 请求有哪些： 
1、form 标签 method=get 
2、a 标签 
3、link 标签引入 css 
4、Script 标签引入 js 文件 
5、img 标签引入图片 
6、iframe 引入 html 页面 
7、在浏览器地址栏中输入地址后敲回车

POST 请求有哪些： 
8、form 标签 method=post      一般用于文件，图像等大的

**get和post的区别：**
详细见：https://www.cnblogs.com/logsharing/p/8448446.html

![1602569965709](JavaWeb.assets\1602569965709.png)

**响应的 HTTP 协议格式:**
1、响应行 
      (1) 响应的协议和版本号    HTTP/1.1	
      (2) 响应状态码                    200
      (3) 响应状态描述符            OK
2、响应头
      key:value     不同的响应头，有不同的含义 
      **空行**
3、请求体 ===>>> 就是回传给客户端的数据

**常用的响应码说明：**
200 表示请求成功 
302 表示请求重定向 
404 表示请求服务器已经收到了，但是你要的数据不存在（请求地址错误） 
500 表示服务器已经收到请求，但是服务器内部错误（代码错误）

**get请求的HTTP协议内容：**

![1602816718855](JavaWeb.assets\1602816718855.png)

**post请求的HTTP协议内容：**

![1602816806591](JavaWeb.assets\1602816806591.png)

MIME 类型说明:
MIME 是 HTTP 协议中数据类型。
MIME 的英文全称是"MultipurposeInternetMailExtensions" 多功能 Internet 邮件扩充服务。MIME 类型的格式是“大类型/小 类型”，并与某一种文件的扩展名相对应。
常见的 MIME 类型：
![1602490540801](JavaWeb.assets\1602490540801.png)

![1602490550005](JavaWeb.assets\1602490550005.png)



# JSP

JSP(全称Java Server Pages)  

jsp 的主要作用是代替 Servlet 程序传回 html 页面的数据。

**jsp的本质，其实是一个 Servlet 程序**：
      当我们第一次访问 jsp 页面的时候。Tomcat 服务器会帮我们把 jsp 页面翻译成为一个 java 源文件。并且对它进行编译成为.class 字节码程序 ；跟踪原代码发现，HttpJspBase 类。它直接地继承了 HttpServlet 类。也就是说。jsp 翻译出来的 java 类，它间接了继承了 HttpServlet 类。也就是说，翻译出来的是一个 Servlet 程序 
      那么当我们访问 一个 **xxx.jsp** 文件后 翻译成 **java** 文件的全名是 **xxx_jsp.java** 文件
不难发现。jsp页面中的html内容被翻译到Servlet程序的service方法中原样输出，这就是我们说jsp是专门用来输出html页面的Servlet程序

通俗解释：JSP就是在jsp页面编写java代码

## 语法  

**1.头部声明(page)**
**2.三种脚本**  
**3.三种注释**
**4.jsp 九大内置对象**  
**5.jsp 四大域对象**
**6. out 和 response.getWriter 输出的区别**
**7.jsp 的常用标签（重点）**



**1.头部声明(page)**

jsp 的 page 指令可以修改 jsp 页面中一些重要的属性，或者行为。

<%@ **page** **contentType**="**text/html;charset=UTF-8**" **language**="**java**" %>

**属性：**
i. language属性	表示 jsp 翻译后是什么语言文件。暂时只支持 java。
ii. contentType属性	表示 jsp 返回的数据类型是什么。也是源码中 response.setContentType()参数值
iii. pageEncoding属性	表示当前 jsp 页面文件本身的字符集。
iv. import属性	跟java源代码中一样。用于导包，导类。
v. autoFlush属性 设置当out输出流缓冲区满了之后，是否自动刷新冲级区。默认值是true。 
vi.  buffer属性 设置out缓冲区的大小。默认是8kb 缓冲区溢出错误：Error:JSP Buffer overflow
vii. errorPage属性  设置当jsp页面运行时出错，自动跳转去的路径 ：
      这个路径一般都是以斜杠打头，它表示请求地址为*http://ip:port/*工程路径*/*   ，映射到代码的*Web*目录
viii. isErrorPage属性获取异常信息。设置当前jsp页面是否是错误信息页面。默认是false。如果是true可以
ix.session 属性	设置访问当前jsp页面，是否会创建HttpSession对象。默认是true。
x. extends 属性	设置jsp翻译出来的java类默认继承谁。



**2.三种脚本**  

2.1：声明脚本(极少使用)

<%!	声明java代码	%>

声明脚本块中，我们可以干 4 件事情：
1.我们可以定义全局变量。
2.定义 static 静态代码块
3.定义方法
4.定义内部类
几乎可以写在类的内部写的代码，都可以通过声明脚本来实现

**2.2：表达式脚本（重点，使用很多）**

**<%=**表达式 **%>**

表达式脚本用于向页面输出内容。
如：<td><%=student.getSex()%></td>

表达式脚本的特点：
1、	所有的表达式脚本都会被翻译到Service() 方法中
2、	表达式脚本都会被翻译成为 **out.print()输出到页面上**
3、	由于表达式脚本翻译的内容都在Service() 方法中,所以Service()方法中的对象都可以直接使用。
4、	表达式脚本中的表达式**不能以分号结束。**

**2.3：代码脚本（重点，使用最多）**

**<%** java 代码 **%>**

**代码脚本里可以书写任意的 java 语句。**
**代码脚本的内容都会被翻译到 service 方法中。**
**所以 service 方法中可以写的 java 代码，都可以书写到代码脚本中**

代码脚本的特点是：
1、	代码脚本翻译之后都在Service 方法中
2、	代码脚本由于翻译到Service()方法中，所以在Service()方法中的现有对象都可以直接使用。
3、	还可以由多个代码脚本块组合完成一个完整的 java 语句。
4、	代码脚本还可以和表达式脚本一起组合使用，在 jsp 页面上输出数据




**3.三种注释**

html 注释  ：
<!-- 这是html注释 -->      html 的注释会被翻译到 java 代码中输出到 html 页面中查看

java 注释  ：
//   或   /* */

jsp 注释  :
<%-- 这是jsp注释 --%>      jsp 注释在翻译的时候会直接被忽略掉



**4.jsp 九大内置对象**  

jsp 中的内置对象，是指 Tomcat 在翻译 jsp 页面成为 Servlet 源代码后，内部提供的九大对象，叫内置对象。

**request 对象： 请求对象，可以获取请求信息** 
**response 对象： 响应对象。可以设置响应信息** 
pageContext 对象 ：当前页面上下文对象。可以在当前上下文保存属性信息 
session 对象 ：会话对象。可以获取会话信息。 
exception 对象 ：异常对象只有在 jsp 页面的 page 指令中设置 isErrorPage="true" 的时候才会存在 
application 对象： ServletContext 对象实例，可以获取整个工程的一些信息。 
config 对象： ServletConfig 对象实例，可以获取 Servlet 的配置信息 
out 对象： 输出流。 
page 对象 ：表示当前 Servlet 对象实例（无用，用它不如使用 this 对象）。

**九大内置对象，都是我们可以在【代码脚本】中或【表达式脚本】中直接使用的对**
**象。**



**5.四大域对象**

四大域对象经常用来保存数据信息。

| pageContext  (PageContextImpl类)        | 当前 jsp 页面范围内有效                                    |
| --------------------------------------- | ---------------------------------------------------------- |
| request      (HttpServletRequest  类)、 | 一次请求内有效                                             |
| session       (HttpSession 类)、        | 一个会话范围内有效（打开浏览器访问服务器，直到关闭浏览器） |
| application        (ServletContext  类) | 整个 web 工程范围内都有效（只要 web 工程不停止，数据都在） |

**域对象是可以像 Map 一样存取数据的对象。四个域对象功能一样。不同的是它们对数据的存取范围**：
它们都可以：setAttribute()，getAttribute()，removeAttribute();
四个域的作用域范围大小和优先顺序是:
PageContext （page域） < request < session < servletContext（application域）

**6. out 和 response.getWriter 输出的区别**

jsp 中的 out 输出和 response.getWriter 输出的区别：

out.write() 输出字符串没有问题
out.print() 输出任意数据都没有问题（都转换成为字符串后调用的 write 输出）

**在 jsp 页面中，一般统一使用 out.print()来进行输出**

**例子：**

```
<body>
<%
    // out输出 
out.write("这是out的第一次输出<br/>");
   // out flush之后。会把输出的内容写入writer的缓冲区中 
out.flush();
   // 最后一次的输出，由于没有手动flush，会在整个页面输出到客户端的时候，自动写入到writer 缓冲区
out.write("这是out的第二次输出<br/>");
   // writer的输出
response.getWriter().write("这是writer的第一次输出<br/>"); 
response.getWriter().write("这是writer的第二次输出<br/>"); 
%>
</body>

结果：
这是out的第一次输出
这是writer的第一次输出
这是writer的第二次输出
这是out的第二次输出
```



<img src="JavaWeb.assets\1602647889007.png" alt="1602647889007"  />

**7.jsp 的常用标签（重点）**

静态包含：很常用
动态包含 ：很少用
转发 ：常用

**静态包含--很常用**

<%@ include file=""%> 就是静态包含
file 属性指定你要包含的jsp页面的路径
地址中第一个斜杠/ 表示为http://ip:port/工程路径/ 映射到代码的web目录

静态包含的特点：
1、	静态包含不会翻译被包含的jsp页面。
2、	静态包含其实是把被包含的jsp页面的代码拷贝到包含的位置执行输出。

```
<%@ include file="/include/footer.jsp"%>
```

**动态包含--很少用**

<jsp:include page=""><</jsp:include> >
这是动态包含 *page* 属性是指定你要包含的*jsp*页面的路径动态包含也可以像静态包含一样。把被包含的内容执行输出到包含位置

动态包含的特点：
1、	动态包含会把包含的jsp页面也翻译成为java代码
2、	动态包含底层代码使用如下代码去调用被包含的jsp页面执行输出。
JspRuntimeLibrary.include(request, response, "/include/footer.jsp", out, false);
3、	动态包含，还可以传递参数

```
<jsp:include page="/include/footer.jsp"> <jsp:param name="username" value="bbj"/> <jsp:param name="password" value="root"/>
</jsp:include>
```

**页面转发--常用**

<jsp:forward page=""><</jsp:forward>> 是请求转发标签，它的功能就是请求转发 page 属性设置请求转发的路径

```
<jsp:forward page="/scope2.jsp"></jsp:forward>
```

![1602658380099](JavaWeb.assets\1602658380099.png)

在这里需要补充说明一点：我们在工作中，**几乎都是使用静态包含**。理由很简单。因为 jsp 页面虽然可以写 java 代码，做其他的功能操作。但是由于 jsp 在开发过程中被定位为专门用来展示页面的技术。也就是说。jsp 页面中，基 本上只有 html，css，js。还有一些简单的 EL，表达式脚本等输出语句。所以我们都使用静态包含。



## jsp联合servlet简单实例（重要）

需要index.jsp，servlet类，a.jsp，Student类，web.xml

打开页面在index.jsp开始，通过get或post提交到相应的servlet，servlet中通过 jdbc接口 获得数据库查询的结果集，在用域对象保存结果集，然后通过转发到a.jsp页面

index.jsp

```
<body>
 开始的jsp页面
 在form表单中记得填写要跳转的 servlet页面url
 <form action="http://localhost:8770/servlet_01/hello" method="get">
     <input type="submit" value="GET">
 </form>
  <form action="http://localhost:8770/servlet_01/hello" method="post">
      <input type="submit" value="POST">
  </form>
</body>
```



servlet代码：

```
public class HelloWorld extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");
        System.out.println("HelloWorld的doGet方法");
        
           //1.List集合存储对象，这里应该是用的JDBC查到的结果集，但为了简单用的这个
        List<Student> list = new ArrayList<>();
        for (int i=0;i<10;i++){
            list.add(new Student("aa"+i,"啥"+i));
        }
          //2.保存查询到的结果（学生信息）到request域中
        req.setAttribute("stuList",list);
          //3.请求转发到a.jsp页面
        req.getRequestDispatcher("a.jsp").forward(req,resp);
}   
```

a.jsp

```
<body>
<p>学生：</p>
<%
    List<Student> list = (List<Student>) request.getAttribute("stuList");
%>

<% for (Student student:list){%>
<tr>
    <td><%=student.getName()%></td>
    <td><%=student.getSex()%></td>
</tr>
<br>
<% } %>
</body>
```

Student类

```
public class Student {
..............
}
```

web.xml

```
..............
<!--上面的servlet实例中有-->
...............
```

# Listener 监听器

1、  Listener 监听器它是 JavaWeb 的三大组件之一。JavaWeb 的三大组件分别是：Servlet 程序、Filter 过滤器、Listener 监听器。

2、  Listener 它是 JavaEE 的规范，就是接口

3、  监听器的作用是，监听某种事物的变化。然后通过回调函数，反馈给客户（程序）去做一些相应的处理。

如：电动车的报警器。当报警器锁上的时候。我们去碰电动车，电动车就会报警。 报警器，就是监听器，电动车就是被监视的对象。报警就是响应的内容。



## ServletContextListener 监听器

ServletContextListener 它可以监听 ServletContext 对象的创建和销毁。
ServletContext 对象在 web 工程启动的时候创建，在 web 工程停止的时候销毁。监听到创建和销毁之后都会分别调用 ServletContextListener 监听器的方法反馈。

两个方法分别是：

```
public interface ServletContextListener extends EventListener {

//在ServletContext 对象创建之后马上调用，做初始化

   public void contextInitialized(ServletContextEvent sce); 

//在ServletContext 对象销毁之后调用
 
   public void contextDestroyed(ServletContextEvent sce);
}

生命周期监听器两个方法：
public void contextInitialized(ServletContextEvent sce) //是 ServletContext 对象的 创建回调
public void contextDestroyed(ServletContextEvent sce) //是 ServletContext 对象的销 毁回调

```

**实例：**

如何使用 ServletContextListener 监听器监听 ServletContext 对象。
**使用步骤如下：**
1、	编写一个类去实现 ServletContextListener
2、	实现其两个回调方法
3、	到 web.xml 中去配置监听器
**监听器实现类：**

```
 public class MyServletContextListenerImpl implements ServletContextListener {
        @Override
        public void contextInitialized(ServletContextEvent sce) { 
              System.out.println("ServletContext对象被创建了");
        }
        @Override
        public void contextDestroyed(ServletContextEvent sce) { 
              System.out.println("ServletContext对象被销毁了");
        }
    }
```

**web.xml中的配置：**

```
<!--配置监听器-->

<listener>
	
<listener-class>	com.atguigu.listener.MyServletContextListenerImpl	</listener-class>
<!--com.atguigu.listener是包路径，listener-class中要写 全类名-->
</listener>	

```

**这个时候，启动 web 工程和正常停止 web 工程，后台都会如下打印：**
<img src="JavaWeb.assets\1602659280369.png" alt="1602659280369" style="zoom: 67%;" />





# EL 表达式

什么是 EL 表达式，EL 表达式的作用?
EL 表达式的全称是：Expression	Language。是表达式语言。
EL 表达式的什么作用：EL 表达式主要是**代替 jsp 页面中的表达式脚本**在 jsp 页面中进行数据的输出。
因为 EL 表达式在输出数据的时候，要比 jsp 的表达式脚本要简洁很多。

**EL 表达式主要是在 jsp 页面中输出数据。主要是输出域对象中的数据。**

## **基本语法**

EL 表达式的格式是：**${表达式}**
EL 表达式在输出 null 值的时候，输出的是空串。jsp 表达式脚本输出 null 值的时候，输出的是 null 字符串。

**简单例子：**

```
<body>
<%
    request.setAttribute("key","aaa");
%>
 表达式脚本输出 key 的值是：
 <%=request.getAttribute("key")%>    //aaa
 <%=request.getAttribute("key1")%>   //null
 <br>
 EL 表达式输出 key 的值是：
 ${key}                        //aaa
 ${key1}                       //
 </body>  
```

**EL 表达式搜索域数据的顺序 **

当四个域中都有相同的 key 的数据的时候，EL 表达式会按照四个域的**从小到大的顺序去进行搜索**，找到就输出  

四个域在使用的时候，优先顺序分别是，他们从小到大的范围的顺序。
	pageContext	>>>	request	==>>>	session	==>>>	application

```
<%
// 往 四 个 域 中 都 保 存 了 相 同 的 key的 数 据
request.setAttribute("key", "request");
session.setAttribute("key", "session"); 
application.setAttribute("key", "application");
pageContext.setAttribute("key", "pageContext");
%>
${ key }
```



**EL** 表达式输出 **Bean** 的普通属性，数组属性。**List** 集合属性，**map** 集合属性  :

**输出格式：key.属性名**       实际是内部调用了该属性的 get方法

i. 需求——输出 Person 类中普通属性，数组属性。list 集合属性和 map 集合属性。

```
public class Person { 
// 需 求 —— 输 出 Person类 中 普 通 属 性 ， 数 组 属 性 。 list集 合 属 性 和 map集 合 属 性 
private String name; 
private String[] phones; 
private List<String> cities; 
private Map<String,Object> map;
private int age;
public int getAge() 
{ 
return 18; 
}
......................

<%
.......................
pageContext.setAttribute("p", person);
%>
输出 Person：${ p }<br/> 
输出 Person 的 name 属性：${p.name} <br> 
输出 Person 的 pnones 数组属性值：${p.phones[2]} <br> 
输出 Person 的 cities 集合中的元素值：${p.cities} <br> 
输出 Person 的 List 集合中个别元素值：${p.cities[2]} <br> 
输出 Person 的 Map 集合: ${p.map} <br> 
输出 Person 的 Map 集合中某个 key 的值: ${p.map.key3} <br> 
输出 Person 的 age 属性：${p.age} <br>
```



**EL 表达式——运算**

**语法：${ 运算表达式 }** ， EL 表达式支持如下运算符：

![1602744890208](JavaWeb.assets\1602744890208.png)

![1602744903314](JavaWeb.assets\1602744903314.png)

![1602744920922](JavaWeb.assets\1602744920922.png)

**empty 运算:**
empty 运算可以判断一个数据是否为空，如果为空，则输出 true,不为空输出 false。

以下几种情况为空： 
1、值为 null 值的时候，为空 
2、值为空串的时候，为空 
3、值是 Object 类型数组，长度为零的时候 
4、list 集合，元素个数为零 
5、map 集合，元素个数为零

**三元运算**

表达式 1？表达式 2：表达式 3

**“.”点运算 和 [] 中括号运算符**

.点运算，可以输出 Bean 对象中某个属性的值。 
[]中括号运算，可以输出有序集合中某个元素的值。 并且[]中括号运算，还可以输出 map 集合中 key 里含有特殊字符的 key 的值。

```
<%
Map<String,Object> map = new HashMap<String, Object>(); 
map.put("a.a.a", "aaaValue"); 
%>
${ map['a.a.a'] } <br> 
```

## **EL 表达式的 11 个隐含对象**

EL 个达式中 11 个隐含对象，是 EL 表达式中自己定义的，可以直接使用。

**${变量.key值}**

| 变量                 | 类型                 | 作用                                                   |
| -------------------- | -------------------- | ------------------------------------------------------ |
| pageContext          | PageContextImpl      | **它可以获取 jsp 中的九大内置对象**                    |
| **pageScope**        | Map<String,Object>   | 它可以获取 pageContext 域中的数据                      |
| **requestScope**     | Map<String,Object>   | 它可以获取 Request 域中的数据                          |
| **sessionScope**     | Map<String,Object>   | 它可以获取 Session 域中的数据                          |
| **applicationScope** | Map<String,Object>   | 它可以获取 ServletContext 域中的数据                   |
| param                | Map<String,String>   | 它可以获取请求参数的值                                 |
| paramValues          | Map<String,String[]> | 它也可以获取请求参数的值，获取多个值的时候使用。       |
| header               | Map<String,String>   | 它可以获取请求头的信息                                 |
| headerValues         | Map<String,String[]> | 它可以获取请求头的信息，它可以获取多个值的情况         |
| cookie               | Map<String,Cookie>   | 它可以获取当前请求的 Cookie 信息                       |
| initParam            | Map<String,String>   | 它可以获取在 web.xml 中配置的<context-param>上下文参数 |

```
<%
pageContext.setAttribute("key2", "pageContext2");
request.setAttribute("key2", "request"); 
session.setAttribute("key2", "session");
application.setAttribute("key2", "application");
%>
${ applicationScope.key2 }


pageContext 对象的使用:
<%--
request.getscheme()它可以获取请求的协议
request.getServerName()获取请求的服务器ip或域名
request.getServerPort()获取请求的服务器端口号
getContextPath()获取当前工程路径
request.getMethod()获取请求的方式(GET或 POST)
request.getRemoteHost()获取客户端的ip地址
session.getId()获取会话的唯一标识
--%>
<%
pageContext.setAttribute( "req", request);
%>
<%=request.getscheme() %><br>
1.协议:${req.scheme }<br>
2.服务器ip:${ pageContext.request.serverName }<br>
3.服务器端口:${ pageContext.request.serverPort }<br>
4.获取工程路径:${ pagecontext.request.contextPath }<br>
5.获取请求方法:${ pageContext.request.method }<br>
6.获取客户端ip地址:${ pageContext.request.remoteHost }<br>
7.获取会话的id编号:${ pageContext.session.id }<br>
```





# **JSTL 标签库**

JSTL 标签库 全称是指 JSP Standard Tag Library JSP 标准标签库。是一个不断完善的开放源代码的 JSP 标 签库。
EL 表达式主要是为了替换 jsp 中的表达式脚本，而**标签库则是为了替换代码脚本**。这样使得整个 jsp 页面 变得更佳简洁。

JSTL 由五个不同功能的标签库组成：

| 功能范围             | URI                                    | 前缀  |
| -------------------- | -------------------------------------- | ----- |
| 核心标签库**--**重点 | **http://java.sun.com/jsp/jstl/core**  | **c** |
| 格式化               | http://java.sun.com/jsp/jstl/fmt       | fmt   |
| 函数                 | http://java.sun.com/jsp/jstl/functions | fn    |
| 数据库(不使用)       | http://java.sun.com/jsp/jstl/sql       | sql   |
| XML(不使用)          | http://java.sun.com/jsp/jstl/xml       | x     |

**JSTL 标签库的使用步骤**
1、**先导入 jstl 标签库的 jar 包(maven项目直接添加依赖)。**
taglibs-standard-impl-1.2.1.jar taglibs-standard-spec-1.2.1.jar
2、**使用 taglib 指令引入标签库**  
<%@ taglib prefix="c"	uri="http://java.sun.com/jsp/jstl/core"%>

**core 核心库使用**

1.**<<c:set/>>**  和 **<<c:if/>>**

![1602750255179](JavaWeb.assets\1602750255179.png)

**2.<<c:choose>>     <<c:when> >       <<c:otherwise>>**

![1602750278126](JavaWeb.assets\1602750278126.png)

**3.<<c:forEach/>>**
作用：遍历输出使用

```
begin 属 性 设 置 开 始 的 索 引
end 属 性 设 置 结 束 的 索 引
step属 性 表 示 遍 历 的 步 长 值
varStatus属 性 表 示 当 前 遍 历 到 的 数 据 的 状 态
var 属性表示循环的变量 (也是当前正在遍历到的数据) 
items表示遍历的数据源（遍历的集合）
var表示当前遍历到的数据

和for (int i = 1; i < 10; i++) 做比较

<table border="1">
  <c:forEach begin="1" end="10" var="i">
    <tr>
    <td>第${i}行</td>
    </tr>
  </c:forEach>
</table>


遍历 Object 数组
<%
request.setAttribute("arr", new String[]{"18610541354","18688886666","18699998888"});
%> 
<c:forEach items="${ requestScope.arr }" var="item"
   ${ item } <br> 
</c:forEach>


遍历 Map 集合
<%
..............
request.setAttribute("map", map);
%> 
<c:forEach items="${ requestScope.map }" var="entry"> 
  <h1>${entry.key} = ${entry.value}</h1> 
</c:forEach>



遍历 List 集合
<%
..............
request.setAttribute("stus", studentList);
%> 
<c:forEach begin="2" end="7" step="2" varStatus="status" items="${requestScope.stus}" var="stu"> 
 <tr> 
   <td>${stu.id}</td> 
   <td>${stu.username}</td> 
   <td>${stu.password}</td> 
   <td>${stu.age}</td> 
   <td>${stu.phone}</td> 
   <td>${status.step}</td> 
 </tr> 
</c:forEach> 

```





# 文件的上传和下载

**文件的上传介绍：**

1、 要有一个form标签，method=post请求

2、 form标签的encType属性值必须为multipart/form-data值

3、 在form标签中使用input type=file添加上传的文件

4、 编写服务器代码（Servlet程序）接收，处理上传的数据。

encType=multipart/form-data 表示提交的数据，以多段（每一个表单项一个数据段）的形式进行拼接，然后以二进制流的形式发送给服务器

![1602836005075](JavaWeb.assets\1602836005075.png)



**文件上传例子：**

需要导入两个 jar 包： commons-fileupload-1.2.1.jar commons-io-1.4.jar

**commons-fileupload.jar** 和 **commons-io.jar** 包中，我们常用的类有哪些？

ServletFileUpload类，用于解析上传的数据。

FileItem 类，表示每一个表单项。

boolean ServletFileUpload.*isMultipartContent*(HttpServletRequest request); 判断当前上传的数据格式是否是多段的格式。

public List<FileItem> parseRequest(HttpServletRequest request) 解析上传的数据

boolean FileItem.isFormField() 判断当前这个表单项，是否是普通的表单项。还是上传的文件类型。true 表示普通类型的表单项 false 表示上传的文件类型

String FileItem.getFieldName() 获取表单项的name属性值

String FileItem.getString() 获取当前表单项的值。

String FileItem.getName(); 获取上传的文件名

void FileItem.write( file ); 将上传的文件写到参数file 所指向抽硬盘位置。

**实例：**
**up.jsp**

```
<body>
<form action="http://localhost:8770/servlet_up/upf" method="post" enctype="multipart/form-data">
    用户名:<input type="text" name="username"> <br>
    头像：<input type="file" name="photo"> <br>
    <input type="submit" value="上传">

</form>
<form action="http://localhost:8770/servlet_up/upf" method="get" enctype="multipart/form-data">
    用户名:<input type="text" name="username"> <br>
    <input type="submit" value="get测试">

</form>
</body>
```

**UpFile类**

```
//测试
@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("ddddddpppppp");
        ServletInputStream inputStream = req.getInputStream();

        byte[] bytes = new byte[102400];
        int read = inputStream.read(bytes);
        System.out.println(new String(bytes,0,read));
        //把字节流输出到控制台了，说明传到了服务器
}

//实例
//使用导入的两个包中的api
 @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("ddddddpppppp");

        System.out.println("dopost");
        //1.先判断上传的数据是否多段数据（只有是多段的数据,才是文件上传的 ）
        if (ServletFileUpload.isMultipartContent(req)){
            //2.创建FileItemFactory工厂实现类
            FileItemFactory fileItemFactory = new DiskFileItemFactory();
            //3.创建用于解析上传数据的工具类ServletFileUpload类
            ServletFileUpload servletFileUpload = new ServletFileUpload(fileItemFactory);
            try {
                // 4.解析上传的数据，得到每一个表单项FileItem
                List<FileItem> list = servletFileUpload.parseRequest(req);
                // 5.循环判断，每一个表单项，是普通类型，还是上传的文件
                for (FileItem fileItem : list){
                    if (fileItem.isFormField()){
                        //普通表单项
                        System.out.println("表单项的name属性值：" + fileItem.getFieldName());
                        // 参数UTF-8.解决乱码问题
                        System.out.println("表单项的value属性值：" + fileItem.getString("UTF-8"));
                    }
                    else{
                        // 上传的文件
                        System.out.println("表单项的name属性值：" + fileItem.getFieldName());
                        System.out.println("上传的文件名：" + fileItem.getName());
                        fileItem.write(new File("d:\\" + fileItem.getName()));
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
```



**文件的下载介绍：**

下载的常用 **API** 说明：

response.getOutputStream(); 
servletContext.getResourceAsStream(); 
servletContext.getMimeType(); 
response.setContentType();

response.setHeader("Content-Disposition", "attachment; fileName=1.jpg");
这个响应头告诉浏览器。这是需要下载的。而attachment表示附件，也就是下载的一个文件。fileName=后面，
表示下载的文件名。

**文件的下载实例：**

```
jsp代码：
<form action="http://localhost:8770/servlet_up/hello2" method="get" enctype="multipart/form-data">
   <%-- 用户名:<input type="text" name="username"> <br>--%>
    <input type="submit" value="下载">

</form>



servlet代码：

@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    System.out.println("文件的下载");
        //1.获取要下载的文件名  3 4步骤可以不要
    String downfile = "2.jpg";
        //获取文件路径上的文件夹，第一个  /  表示服务器解析地址 http://localhost:8770/servlet_up/
    String foder = "/files/";
        // 2.读取要下载的文件内容（通过servletcontext对象可以读取)
    ServletContext servletContext = getServletContext();
        //3.获取要下载的文件类型
    String mimeType = servletContext.getMimeType(foder+downfile);
    System.out.println("下载的文件类型："+mimeType);
        //4.在回传前，通过响应头告诉客户端返回的数据类型
    resp.setContentType(mimeType);
        //5，还要告诉客户端收到的数据是用于下载使用(还是使用响应头)
        //content-Disposition响应头，表示收到的数据怎么处理
        //attachment表示附件，表示下载使用
        //filename=表示指定下载的文件名
        //不要这一行是文件直接显示在 浏览器上
    resp.setHeader("Content-Disposition","attachment;filename="+downfile);//注意是分号哦
      
    //6.获得输入流，正戏开始；关键代码
    InputStream inputStream = servletContext.getResourceAsStream(foder+downfile);
        //获取响应的输出流
    OutputStream outputstream = resp.getOutputStream();
        //3，把下载的文件内容回传给客户端
        //读取输入流中全部的数据，复制给输出流，输出给客户端
        //IOUtils.copy(inputStream,outputstream);
    byte[] bytes=new byte[1024];
    int len=0;
    while ((len=inputStream.read(bytes))!=-1){
        outputstream.write(bytes,0,len);
    }
    inputStream.close();
    outputstream.close();
    System.out.println("文件下载成功");
    }
```

**下载乱码问题：**

**方案一**：**URLEncoder** 解决 IE 和谷歌浏览器的 附件中文名问题：
// 把中文名进行UTF-8编码操作,url编码是把汉字转换成为%xx%xx的格式
String str = "attachment; fileName=" + URLEncoder.encode("中文.jpg", "UTF-8");
// 然后把编码后的字符串设置到响应头中
response.setHeader("Content-Disposition", str);

**方案二**：**BASE64** 编解码解决火狐浏览器的附件中文名问题:

因为火狐使用的是**BASE64**的编解码方式还原响应中的汉字。所以需要使用**BASE64Encoder**类进行编码操作。

// 使用下面的格式进行BASE64编码后
String str = "attachment; fileName=" + "=?utf-8?B?"
+new BASE64Encoder().encode("中文.jpg".getBytes("utf-8")) + "?=";
// 设置到响应头中
response.setHeader("Content-Disposition", str);

**使用User-Agent这个请求头携带过来的浏览器信息判断出是什么浏览器，然后用上面编码格式**

```
String ua = request.getHeader("User-Agent");
// 判断是否是火狐浏览器
if (ua.contains("Firefox")) {
   // 使用下面的格式进行BASE64编码后
   String str = "attachment; fileName=" + "=?utf-8?B?"
   + new BASE64Encoder().encode("中文.jpg".getBytes("utf-8")) + "?=";
   // 设置到响应头中
   response.setHeader("Content-Disposition", str);
} else {
   // 把中文名进行UTF-8编码操作。
   String str = "attachment; fileName=" + URLEncoder.encode("中文.jpg", "UTF-8");
   // 然后把编码后的字符串设置到响应头中
   response.setHeader("Content-Disposition", str);
}

```



# Cookie 和 Session 

## Cookie

cookie保存在  客户端（浏览器）（key,value）

什么是Cookie:

1、	Cookie 翻译过来是饼干的意思。
2、	Cookie 是服务器通知客户端保存**键值对**的一种技术。
3、	客户端有了 Cookie 后，每次请求都发送给服务器。
4、	每个 Cookie 的大小不能超过 4kb 

例子：网站的账户和密码

**1.创建 Cookie** :  Cookie cookie = new Cookie("key1","value1");     resp.addCookie(cookie);
**2.服务器获取 Cookie**：  Cookie[] cookies = req.getCookies();
**3.Cookie 值的修改**：
      3.1   先创建一个新的Cookie对象，key值相同，然后调用 response.addCookie( Cookie );  和Map类似
      3.2   先查找到需要修改的 Cookie 对象,调用 setValue()方法赋于新的 Cookie 值 ,然后调用response.Coo
               kie()通知客户端保存修改

**Cookie 生命控制**：管理 Cookie 什么时候被销毁（删除）  
**setMaxAge()**
        正数，表示在指定的秒数后过期
        负数，表示浏览器一关，Cookie 就会被删除（默认值是-1）零，表示马上删除 Cookie
       cookie.setMaxAge(60 * 60); *//* 设置*Cookie*一小时之后被删除。无效   

**Cookie 有效路径 Path 的设置**  
Cookie 的 path 属性可以有效的过滤哪些 Cookie 可以发送给服务器。哪些不发。
path 属性是通过请求的地址来进行有效的过滤。
**setPath()**

<img src="JavaWeb.assets\1603096459935.png" alt="1603096459935" style="zoom:50%;" />

```
Cookie cookie = new Cookie("path1", "path1"); // getContextPath() ===>>>> 得到工程路径 cookie.setPath( req.getContextPath() + "/abc" ); // ===>>>> resp.addCookie(cookie); resp.getWriter().write("创建了一个带有Path路径的Cookie"); }
```

### **在jsp中调用servlet自定义类**

**实例：CookieServlet类，BaseServlet类，cookie1.jsp**

CookieServlet类：

```
@WebServlet(name = "Servlet",urlPatterns = "/cookieServlet")
public class CookieServlet extends BaseServlet{
//注意：因为CookieServlet类继承的BaseServlet类中重写了doGet和doPost方法，才可以用下面a链接中的写法
    //1.创建 Cookie 
    protected void createCookie(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    
        //1 创建Cookie对象
        Cookie cookie = new Cookie("key1","value1");
        //2 通知客户端保存Cookie
        resp.addCookie(cookie);
        
        resp.getWriter().write("good");

    }
    //2.服务器获取 Cookie
     protected void getCookie(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Cookie[] cookies = req.getCookies();
        for (Cookie cookie:cookies){
            resp.getWriter().write("Cookie["+cookie.getName()+"="+cookie.getValue()+"]<br/>");
        }
    }
}
```

BaseServlet类：

```
public class BaseServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, UnsupportedEncodingException {
               // 解决post请求中文乱码问题
               // 一定要在获取请求参数之前调用才有效
        req.setCharacterEncoding("UTF-8");
           // 解决响应中文乱码问题
        resp.setContentType("text/html; charset=UTF-8");
            // 获取action业务鉴别字符串，获取相应的业务 方法反射对象   action必须是存在的方法名
        String action = req.getParameter("action");
        try {
            
            Method method = this.getClass().getDeclaredMethod(action, HttpServletRequest.class, HttpServletResponse.class);
                     // System.out.println(method);
                 // 调用目标业务 方法
            method.invoke(this, req, resp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
```

cookie1.jsp：

```
<head>
 <base href="http://localhost:8770/servlet_01/">
   ul li {
            list-style: none;
        }
</head>
<body>    

<%--因为CookieServlet类继承的BaseServlet类中重写了doGet和doPost方法，才可以用下面a链接中的写法--%>
<li><a href="cookieServlet?action=createCookie" target="target">Cookie的创建</a></li>

</body>
```



Cookie 的工具类(**查找特定的Cookie对象**)：

```
public class CookieUtils {
    /**
     *	查找指定名称的Cookie对象
     *	@param name
     *	@param cookies
     *	@return
     */ public static Cookie findCookie(String name , Cookie[] cookies){
         if (name == null || cookies == null || cookies.length == 0) {
             return null;
         }
        for (Cookie cookie : cookies) {
            if (name.equals(cookie.getName())) {
                return cookie;
        }
        }
        return null;
    }
}
```

**免输入用户名登录**:

```
jsp代码：
<form action="http://localhost:8770/servlet_01/loginServlet" method="get"> 
用户名：<input type="text" name="username" value="${cookie.username.value}"> <br> 
密码：<input type="password" name="password"> <br> <input type="submit" value="登录"> </form>

servlet代码：
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
IOException {

String username = req.getParameter("username");
String password = req.getParameter("password");
	if ("wzg168".equals(username) && "123456".equals(password)) {
//登录成功
Cookie cookie = new Cookie("username", username);
cookie.setMaxAge(60 * 60 * 24 * 7);//当前Cookie一周内有效
	resp.addCookie(cookie); 
	System.out.println("登录成功");
} else {	
//	登录失败
System.out.println("登录	失败");
}	
}

```



## Session

session保存在  服务器端   （key,value）

**什么是 Session 会话?**

1、Session 就一个接口（HttpSession）。

2、Session 就是会话。它是用来维护一个客户端和服务器之间关联的一种技术。

3、**每个客户端都有自己的一个 Session 会话。**

4、Session 会话中，我们经常用来保存用户登录之后的信息。

**创建 Session 和获取id 号**  
**request.getSession()**
      第一次调用是：创建 Session 会话
      之后调用都是：获取前面创建好的 Session 会话对象。
**isNew()**：判断到底是不是刚创建出来的（新的） 
       true 表示刚创建
        false 表示获取之前创建
每个会话都有一个身份证号。也就是 ID 值。而且这个 ID 是唯一的。
**getId()** 得到 Session 的会话 id 值。

**Session 生命周期控制**  
public void **setMaxInactiveInterval(int interval)** 设置 Session 的超时时间（以秒为单位），超过指定的时长，Session 就会被销毁。值为正数的时候，设定 Session 的超时时长。负数表示永不超时（极少使用），**主要是单独设置超时时长**。
public int getMaxInactiveInterval()获取 Session 的超时时间  
public void **invalidate()** 让当前 Session 会话马上超时无效  

Session 默认的超时时间长为 30 分钟。因为在 Tomcat 服务器的配置文件 web.xml 中默认有以下的配置，它就表示配置了当前 Tomcat 服务器下所有的 Session
**在web.xml中有默认的超时时间( 30 分钟),当然你也可以自己修改:**

```
<session-config>
<session-timeout>30</session-timeout>
</session-config>
```

**实例：**

```
//创建和获取session会话对象
Httpsession session = req.getsession();
//判断当前session会话，是否是新创建出来的
boolean isNew = session.isNew();
/获取session会话的唯一标识id
string id = session.getId();

```

Session 域数据的存取  

```java
protected void setAttribute(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException {
    req.getSession().setAttribute("key1", "value1");
    resp.getWriter().write("已经往Session中保存了数据");
    }
    
protected void getAttribute(HttpServletRequest req,HttpServletResponse resp)throws ServletException, IOException {
Object attribute = req.getSession().getAttribute("key1"); 
resp.getWriter().write("从Session中获取出key1的数据是：" + attribute); 
}

```

# Filter  

1、Filter 过滤器它是 JavaWeb 的三大组件之一。三大组件分别是：Servlet 程序、Listener 监听器、Filter 过滤器

2、Filter 过滤器它是 JavaEE 的规范。也就是接口

3、**Filter 过滤器它的作用是：拦截请求，过滤响应**。

拦截请求常见的应用场景有：

1、权限检查

2、日记操作

3、事务管理等.........

Filter 的生命周期包含几个方法
1、构造器方法
2、init 初始化方法
     第 1，2 步，在 web 工程启动的时候执行（Filter 已经创建）
3、**doFilter 过滤方法**
     第 3 步，每次拦截到请求，就会执行
4、destroy 销毁
     第 4 步，停止 web 工程的时候，就会执行（停止 web 工程，也会销毁 Filter 过滤器）

## **filter简单实例：**

要求：在你的 web 工程下，有一个 admin 目录。这个 admin 目录下的所有资源（html 页面、jpg 图片、jsp 文件、等等）都必须是用户登录之后才允许访问。（我这里有a.html  和 a.jsp）

web.xml配置

```
 <filter>
        <filter-name>AdminFilter</filter-name>
        <filter-class>AdminFilter</filter-class>
    </filter>
    <filter-mapping>
        <filter-name>AdminFilter</filter-name>
        <url-pattern>/admin/*</url-pattern>   <!--/admin/*   是admin下所有的 -->
    </filter-mapping>
    
    <!--filter标 签 用 于 配 置 一 个 Filter过 滤 器 -->
    <!--第一个filter-name给 filter 起 一 个 别 名 -->
     <!--filter-class配置filter的全类名-->
    <!--filter-mapping配置Filter过滤器的拦截路径 -->
    <!--第二个filter-name表 示 当 前 的 拦 截 路 径 给 哪 个 filter使 用  -->
    <!--url-pattern配置拦截路径
    /表示请求地址为:http://ip:port/工程路径/映射到IDEA 的web目录
    / admin/*表示请求地址为: http://ip:port/工程路径/admin/*
    -->
```

login.jsp

```
<body>
这是登录页面，login.jsp页面
<form action="http://localhost:8770/servlet_01/login" method="get">
用户名：<input type="text" name="username"/> <br>
密码：<input type="password" name="password"/> <br>
    <input type="submit" value="提交">

</form>
</body>
```

LoginServlet

```
      resp.setContentType("text/html;charset=UTF-8");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        if ("aaa".equals(username) && "123".equals(password)){
            //设置session   在AdminFilter中会用到判断是否有权限（是过滤条件）
            req.getSession().setAttribute("user",username);
           resp.getWriter().write("登录成功");
        }else {
            req.getRequestDispatcher("/login.jsp").forward(req,resp);
        }
```

AdminFilter

```
 public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest)servletRequest;
        HttpSession session = httpServletRequest.getSession();
        Object user = session.getAttribute("user");
        //如果等于null，说明还没有登录
        if (user == null){
            servletRequest.getRequestDispatcher("/login.jsp")
            .forward(servletRequest,servletResponse);
            
            return;
        }
        else{
            //让程序继续往下访问用户的目标资源
            filterChain.doFilter(servletRequest,servletResponse);
        }

//有了权限后  通过像  http://localhost:8770/servlet_01/admin/a.html    访问admin下的文件
```

##  **FilterConfig 类**  

是 Filter 过滤器的配置文件类  
Tomcat 每次创建 Filter 的时候，也会同时创建一个 FilterConfig 类，这里包含了 Filter 配置文件的配置信息。

FilterConfig 类的作用是获取 filter 过滤器的配置内容
1、	获取 Filter 的名称 filter-name 的内容
2、	获取在 Filter 中配置的 init-param 初始化参数
3、	获取 ServletContext 对象

```
public void init(FilterConfig filterConfig) throws ServletException {
System.out.println("2.Filter的init(FilterConfig filterConfig)初始化");

//	1、获取Filter的名称filter-name的内容
System.out.println("filter-name的值是：" + filterConfig.getFilterName());
//	2、获取在web.xml中配置的init-param初始化参数
System.out.println("初始化参数username的值是："+filterConfig.getInitParameter("username")); System.out.println("初始化参数url的值是：" + filterConfig.getInitParameter("url"));
//	3、获取ServletContext对象
System.out.println(filterConfig.getServletContext()); }

```

```
<init-param> 
<param-name>username</param-name> 
<param-value>root</param-value> 
</init-param>

<init-param> 
<param-name>url</param-name>
<param-value>jdbc:mysql://localhost3306/test</param-value>
</init-param>

```

## FilterChain 过滤器链

Filter 过滤器 
Chain 链，链条 
FilterChain 就是过滤器链（多个过滤器如何一起工作）

FilterChain.doFilter()方法的作用
1、执行下一个Filter过滤努（如果有Filter)
2、执行目标资源（没有Filter)

**在多个Filter过滤器执行的时侯，它们执行的优先顺序是由**
**他们在web.xml中从上到下配置的顺序决定!! !**

多个Filter过滤器执行的特点:
1、所有filter和目标资源获认都执行在同一个线程中
2、多个Filter共同执行的时候，它们都使用同一个Request对象。

![1603195131715](JavaWeb.assets\1603195131715.png)

## Filter 的拦截路径

精确匹配:
<url-pattern>/target.jsp</url-pattern> 
以上配置的路径，表示请求地址必须为：http://ip:port/工程路径/target.jsp

目录匹配
<url-pattern>/admin/*</url-pattern> 
以上配置的路径，表示请求地址必须为：http://ip:port/工程路径/admin/

后缀名匹配
<url-pattern>*.html</url-pattern> 
以上配置的路径，表示请求地址必须以.html 结尾才会拦截到 
<url-pattern>*.do</url-pattern> 以上配置的路径，表示请求地址必须以.do 结尾才会拦截到 
<url-pattern>*.action</url-pattern> 以上配置的路径，表示请求地址必须以.action 结尾才会拦截到

Filter 过滤器它只关心请求的地址是否匹配，不关心请求的资源是否存在！！！

# ==JSON==

一种轻量级的数据交换格式  ，轻量级指的是跟xml做比较。

定义：
json是**由键值对组成，并且由花括号（大括号）包围**。每个键由引号引起来，键和值之间使用冒号进行分隔，
多组键值对之间进行逗号进行分隔。

```javascript
var jsonObj = {
   "key1":12,
   "key2":"abc",
   "key3":true,
   "key4":[11,"arr",false], "key5":{
   "key5_1" : 551,
   "key5_2" : "key5_2_value"
   },
   "key6":[{
   "key6_1_1":6611,
   "key6_1_2":"key6_1_2_value"
   },{
   "key6_2_1":6621,
   "key6_2_2":"key6_2_2_value"
   }]
};
```

json 的访问
json 本身是一个对象。
json 中的 key 我们可以理解为是对象中的一个属性。

**json 中的 key 访问就跟访问对象的属性一样： json 对象.key**

```javascript
alert(typeof(jsonObj));// object json就是一个对象 
alert(jsonObj.key1); //12 
alert(jsonObj.key2); // abc 
alert(jsonObj.key3); // true 
alert(jsonObj.key4);// 得到数组[11,"arr",false]
// json 中数组值的遍历
for(var i = 0; i < jsonObj.key4.length; i++) 
{ 
alert(jsonObj.key4[i]);
} 
alert(jsonObj.key5.key5_1);//551 
alert(jsonObj.key5.key5_2);//key5_2_value 
alert( jsonObj.key6 );// 得到json数组
// 取出来每一个元素都是json对象
var jsonItem = jsonObj.key6[0]; // 
alert( jsonItem.key6_1_1 ); //6611 
alert( jsonItem.key6_1_2 ); //key6_1_2_value
```

**json 的两个常用方法**

json 的存在有**两种形式**。

一种是：对象的形式存在，我们叫它 **json 对象。**

一种是：字符串的形式存在，我们叫它 **json 字符串**。

一般我们要操作 json 中的数据的时候，需要 json 对象的格式。

一般我们要在客户端和服务器之间进行数据交换的时候，使用 json 字符串。

​         **JSON.stringify()   把 json 对象转换成为 json 字符串**

​         **JSON.parse()     把 json 字符串转换成为 json 对象**

示例代码：

```javascript
// 把json对象转换成为json字符串
var jsonObjString = JSON.stringify(jsonObj); // 特别像Java中对象的toString alert(jsonObjString)
// 把json字符串。转换成为json对象
var jsonObj2 = JSON.parse(jsonObjString); alert(jsonObj2.key1);// 12 alert(jsonObj2.key2);// abc
```

==json和javaBean,List,map的转换（重要）：==

导入：gson-2.2.4.jar  包    **使用.toJson()   和 .fromJson()方法**

```xml
 <dependency>
      <groupId>com.google.code.gson</groupId>
      <artifactId>gson</artifactId>
      <version>2.8.6</version>
    </dependency>

```



```java
gson.toJson()  和   gson.fromJson()方法

和javaBean：

Person person = new Person(1,"国哥好帅!");
// 创建Gson对象实例
Gson gson = new Gson();

// toJson方法可以把java对象转换成为json字符串
String personJsonString = gson.toJson(person);
System.out.println(personJsonString);
//传到前端
 resp.getWriter().write(json);

// fromJson把json字符串转换回Java对象
// 第一个参数是json字符串
// 第二个参数是转换回去的Java对象类型

Person person1 = gson.fromJson(personJsonString, Person.class);
System.out.println(person1);

和List,map

list：gson.toJson()  和   gson.fromJson()

List<Person> personList = new ArrayList<>();
personList.add(new Person(1, "国哥"));
personList.add(new Person(2, "康师傅"));
Gson gson = new Gson();
// 把 List 转换为 json 字符串
String personListJsonString = gson.toJson(personList);
System.out.println(personListJsonString);
List<Person> list = gson.fromJson(personListJsonString, new PersonListType().getType());
System.out.println(list);
Person person = list.get(0);
System.out.println(person);

map: gson.toJson()  和   gson.fromJson()

Map<Integer,Person> personMap = new HashMap<>();
personMap.put(1, new Person(1, "国哥好帅"));
personMap.put(2, new Person(2, "康师傅也好帅"));
Gson gson = new Gson();
// 把 map 集合转换成为 json 字符串
String personMapJsonString = gson.toJson(personMap);
System.out.println(personMapJsonString);
// Map<Integer,Person> personMap2 = gson.fromJson(personMapJsonString, new
PersonMapType().getType());
Map<Integer,Person> personMap2 = gson.fromJson(personMapJsonString, new
TypeToken<HashMap<Integer,Person>>(){}.getType());
System.out.println(personMap2);
Person p = personMap2.get(1);
System.out.println(p);
```

#  **AJAX**  

Ajax 是一种浏览器通过 js **异步发起请求**，**局部更新页面的技术**。
Ajax 请求的局部更新，浏览器地址栏不会发生变化 局部更新不会舍弃原来页面的内容

使用ajax方法实现form表单的提交：
https://www.cnblogs.com/han-1034683568/p/7199168.html

原生 AJAX 请求的示例（了解）：D:\Dell学习\javaweb学习\16-JSON和Ajax请求\笔记

原生ajax：

1. 创建对象 
   var xmlhttprequest = new XMLHttpRequest(); 

2. 规定请求的类型、URL 以及是否异步处理请求。
   xmlhttprequest.open("GET","http://localhost:8080/16_json_ajax_i18n/ajaxServlet?action=javaScriptAj ax",true)；// true（异步）或 false（同步） 

   内容..............

3.  将请求发送到服务器
   xmlhttprequest.send();

**jQuery 中的 AJAX 请求**

$.ajax 方法    
$.get 方法和$.post 方法
$.getJSON 方法 
表单序列化 serialize()

$.ajax 方法   $.get 方法和$.post 方法 没什么区别
$.getJSON 方法 主要是可以跨域

详细：
**$.ajax 方法**    jquery中通用的一个ajax封装 
	url	表示请求的地址
	type	表示请求的类型 GET 或 POST 请求
    data	表示发送给服务器的数据
                格式有两种：
                一：name=value&name=value   //string
                二：{key:value}                             //json
    success          请求成功，响应的回调函数  
    dataType       响应的数据类型
                                常用的数据类型有:
                                     text表示纯文本
                                     xml表示 xml数据
                                     json表示json对象

 $ajax返回的是Json字符串，需用eval方法转化为JSON对象 

```js
$("#ajaxBtn").click(function(){ 
   $.ajax({ 
     url:"http://localhost:8080/16_json_ajax_i18n/ajaxServlet", 
     // data:"action=jQueryAjax", 
     data:{action:"jQueryAjax"}, //jQueryAjax是url定位下的类的 方法名  
     type:"GET", 
     success:function (data) { 
     // alert(" 服 务 器 返 回 的 数 据 是 ： " + data); 
     // var jsonObj = JSON.parse(data); 
     $("#msg").html("编号：" + data.id + " , 姓名：" + data.name); 
     }, 
     dataType : "json" 
   }); 
});

```

$.get方法和$.post方法  ：jQuery会自动封装调用底层的`$.ajax` 

 **$.get( url ,[data] ,[callback] )** 
 **$.post(url,[data],[callback],[type])** 
url     请求的url地址
data   发送的数据
callback   成功的回调函数
type        返回的数据类型

```js
// ajax--get请求
$("#getBtn").click(function(){
$.get("http://localhost:8080/16_json_ajax_i18n/ajaxServlet","action=jQueryGet"
,function (data) { 
     $("#msg").html(" get 编号：" + data.id + " , 姓名：" + data.name);
},"json");
});

// ajax--post请求
$("#postBtn").click(function(){
$.post("http://localhost:8080/16_json_ajax_i18n/ajaxServlet","action=jQueryPost"
,function(data){
$("#msg").html(" post 编号：" + data.id + " , 姓名：" + data.name);
 
},"json");
});

```

**$.getJSON方法**     专门为ajax获取json数据而设置的，并且**支持跨域调用** 

 **getJSON(url,[data],[callback])** 

url：string类型， 发送请求地址
data   发送给服务器的数据
callback    成功的回调函数

 **$.getJSON返回的是JSON对象，可以直接使用** 

```js
// ajax--getJson请求
$("#getJSONBtn").click(function(){
$.getJSON("http://localhost:8080/16_json_ajax_i18n/ajaxServlet","action=jQueryGetJSON"
,function(data) {
$("#msg").html(" getJSON 编号：" + data.id + " , 姓名：" + data.name);
});
});
```

表单序列化 serialize()
serialize()可以把表单中所有表单项的内容都获取到，并以 name=value&name=value 的形式进行拼接。

```js
// ajax请 求 
$("#submit").click(function(){ 
    // 把 参 数 序 列 化            $.getJSON("http://localhost:8080/16_json_ajax_i18n/ajaxServlet","action=jQuerySerialize&" + $("#form01").serialize(),function (data) { 
    $("#msg").html(" Serialize 编号：" + data.id + " , 姓名：" + data.name); 
    }); 
});
```



# maven

maven是一个项目管理工具，主要作用是在项目开发阶段对Java项目进行**依赖管理和项目构建。**
**依赖管理**:就是对jar包的管理。通过导入maven坐标，就相当于将仓库中的jar包导入了当前项目中。
**项目构建**:通过maven的一个命令就可以完成项目从清理、编译、测试、报告、打包，部署整个过程。

安装配置maven教程：
https://www.cnblogs.com/my-program-life/p/12031842.html

idea配置maven:
https://www.cnblogs.com/yjd_hycf_space/p/7483921.html
或https://www.cnblogs.com/njuptzheng/p/13154202.html

## 准备：

一、maven下载
地址 http://maven.apache.org/download.cgi

<img src="JavaWeb.assets\1603350304669.png" alt="1603350304669" style="zoom:67%;" />

下载后解压到相应的路径
二、环境变量配置
此电脑→属性→高级系统设置→环境变量→系统变量→新建 MAVEN_HOME
![1603351006054](JavaWeb.assets\1603351006054.png)

**在Path环境变量下添加%MAVEN_HOME%\bin**

<img src="JavaWeb.assets\1603351042172.png" alt="1603351042172" style="zoom:50%;" />

<img src="JavaWeb.assets\1603351068701.png" alt="1603351068701" style="zoom: 67%;" />

**三、maven核心全局配置文件**
第一步：配置maven本地仓库   打开maven文件夹下的**conf**文件夹，打开里面的**setting.xml**文件

![1603351227899](JavaWeb.assets\1603351227899.png)

继续在其中添加阿里云依赖
![1603351339325](JavaWeb.assets\1603351339325.png)

```
<mirror>
      <id>alimaven</id>
      <name>aliyun maven</name>
      <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
      <mirrorOf>central</mirrorOf>
    </mirror>
```

## idea中创建maven项目：

![1603351709095](JavaWeb.assets\1603351709095.png)

E:\ZY\maven\apache-maven-3.6.3\conf\settings.xml
E:\ZY\maven\repository

![1603351984802](JavaWeb.assets\1603351984802.png)

![1603353993418](JavaWeb.assets\1603353993418.png)

点击图上的**“Import Changes”**，因为是maven项目，所以**当依赖包发生变化时**，也就是**pom.xml文件有修改的时候**。它就得重新检查下包的依赖，没有的，自己会去下载的

**然后添加java文件夹和resource文件夹等（如下图）（具体的看下面的    不能创建java文件解决目录   ）**

<img src="JavaWeb.assets/1605151983489.png" alt="1605151983489" style="zoom:67%;" />

## 添加依赖：

具体步骤：https://blog.csdn.net/qq_37525899/article/details/80988184

在pom.xml文件里的<dependencies>标签 里添加





## 基本知识

**maven的仓库类型**
1.本地仓库
2.远程仓库
maven中央仓库(地址: http://repo2.maven.org/maven2/)
maven私服（公司局域网内的仓库，需要自己搭建)
3.其他公共远程仓库（例如apache提供的远程仓库，地址: http://repo.maven.apache.org/maven2/)

**maven常用命令**
clean:清理
compile:编译
test:测试
package:打包
install:安装

**maven坐标书写规范**
<dependency>
<groupId>mysql<groupId>
<artifactId>mysql-connector-java</artifactId>
<version>5.1.32</ version>
</ dependency>

groudId
团体、组织的标识符。团体标识的约定是，它以创建这个项目的组织名称的逆向域名(reverse domain name)开头。一般对应着JAVA的包的结构。例如org.apache
artifactId 
单独项目的唯一标识符。比如我们的tomcat, commons等。不要在artifactId中包含点号(.)；实际对应项目的名称，就是项目根目录的名称
version 
一个项目的特定版本。
packaging 
项目的类型，默认是jar，描述了项目打包后的输出

.................................



![1603334982732](JavaWeb.assets\1603334982732.png)

compile是默认的依赖范围
<scope>test</scope>改变依赖

什么叫做对某个class有效：是否对于我们这个目录能够使用到引用的jar包

## **依赖冲突**

由于依赖传递现象的存在，spring-webmvc-4.2.4依赖spring-beans-4.2.4,spring-aop-5.0.2依赖spring-beans-5.0.2，但是发现spring-beans-4.2.4加入到了工程钟，而我们希望spring-beans-5.0.2加入工程。这就造成了依赖冲突。不知道使用  beans  的那个版本

**解决依赖冲突**

1、使用maven提供的依赖调解原则
      第一声明者优先原则：在pom.xml中先声明的优先
      路径近者优先原则：比如其它jar包会传递beans包，但直接在pom中依赖bens包，就不会使用其它包传递的                                2、依赖排除：使用exclusions标签将传递过来的依赖排除出去
3、**锁定版本**：

```
<!--版本锁定，但不意味着在各个子工程中添加了依赖；只是声明-->
<dependencyManagement>
  <dependencies>
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.11</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
</dependencyManagement>

<!--子模块在引用的时候无需输入版本version，使用版本锁定里的-->
 <dependencies>
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
    </dependency>
  </dependencies>
```

**4、使用版本常量**

```
<!--定义版本常量-->
<properties>
  <spring.version>5.0.2.RELEASE</spring.version>
</ properties>


<dependencies>

    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-beans</artifactId>
      <version>${spring.version}</version>
    </dependency>
    
</dependencies>
```

注：在父项目POM文件中定义的版本常量，在子模块中的POM文件也能使用



## maven不能创建java等文件解决

Maven Web工程：无法创建Java Class文件：
https://blog.csdn.net/gxx_csdn/article/details/79080265

MavenWeb项目不能新建servlet文件
https://blog.csdn.net/Delicious_Life/article/details/89515363

无法创建Java Class文件：
**方法：手动创建Java源目录**
选择 File——>Project Structure——>Project Settings——>Modules：
右键main目录，选择New Folder，创建一个新文件夹~

![1603424186336](JavaWeb.assets\1603424186336.png)

![1603424222873](JavaWeb.assets\1603424222873.png)













# 其他

**idea 部署web项目到tomcat之后，修改html，js等文件浏览器无法生效或者不能及时生效**

**步骤一：**

![1602301737687](JavaWeb.assets\1602301737687.png)



on ‘update‘ action：当用户主动执行更新的时候更新　　　　快捷键:Ctrl + F9 
 on frame deactication:在编辑窗口失去焦点的时候更新

**步骤二：**
完成上面的操作，很大一部分发现html的修改能够及时更新了，但是js或者jsp的修改却一直没有更新，这是为什么呢？ 
 答案是：**浏览器的坑**
我是使用的chrome，F12到调试窗口 

![1602752990437](JavaWeb.assets\1602752990437.png)

勾选上disable cache（禁用缓存）
然后重新restart一次，问题解决了



**servlet配置导致jsp页面显示源码**，则
方法1.将web.xml文件中 web-app后面的内容删除
方法2.将web.xml文件中的servlet文件配置删除改为注解的方式配置
方法3.**直接在网址上输入tomcat访问路径**

原因：可能是配置的<servlet-mapping>把jsp当成静态资源了

配置：https://blog.csdn.net/qq_44366786/article/details/105934905





**报错java.lang.NoClassDefFoundError**：

见：https://www.cnblogs.com/weibanggang/p/9461672.html





**文件NullPointerException，或getResourceAsStream取得null问题**：

右键项目，F4;进入module的配置   然后按下图将res文件夹变成resources(资源)  就可以访问到了

![1602841101784](JavaWeb.assets\1602841101784.png)



**<servlet-mapping> 中url-pattern匹配规则** 

https://www.cnblogs.com/canger/p/6084846.html



**javaweb，即jsp页面中加载不到jquery文件或css文件等(普通的javaweb和用了框架的都可以用)**

1、拦截问题，即默认把jquery文件或css文件等静态文件拦截了，没有加载上静态文件   所以要配置web.xml加载静态文件
2、可能是路径问题，即导入jquery文件路径出错，相对路径找不到等。   用绝对路径或其它路径方法

https://blog.csdn.net/bwddd/article/details/78518429

**1、使用： 配置<servlet-name>default</servlet-name>，**这个配置的作用是：**对客户端请求的静态资源**如：图片、[js](http://lib.csdn.net/base/javascript)文件等的请求交由默认的servlet进行处理，即 Tomcat的defaultServlet来处理静态文件    

web.xml：

```
  <servlet-mapping>
    <servlet-name>default</servlet-name>
    <url-pattern>*.js</url-pattern>
  </servlet-mapping>
  <!--让后缀为js的可以访问到,即js文件-->  
  如果用了框架，要写在DispatcherServlet的前面， 让 defaultServlet先拦截请求，这样请求就不会进入Spring了
  
注意：如果配置  <url-pattern>*.jsp</url-pattern>   那么会将jsp页面识别为静态资源，加载成源码
```

**2、同时jsp页面引入js改为用绝对路径引用，如：**

```
 <script type="text/javascript" src="${pageContext.request.contextPath}/js/jquery-3.3.1.js"></script>
 
当然：因为用到了  EL表达式，El表达式可能在jsp页面显示不出来   
所以最好加上  <%@ page isELIgnored="false" %>
```





![1603334213286](JavaWeb.assets\1603334213286.png)





**<init-parm>、<context-param>二者的区别:** 
<init-parm>配置在<servlet>标签中,用来初始化当前的Servlet的,属于当前Servlet的配置,因此存放在 **servletConfig**对象中
       通过**getServletConfig().getInitParameter("initParam")**的方式获取;

<context-param>直接配置在web.xml的<web-app>标签中,属于上下文参数,在整个web应用中都可以使用,它是全局的,因此存放在**servletContext**对象中(即application对象);

​      通过**getServletContext().getInitParameter("contextParam")**的方式获取;











