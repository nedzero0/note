# **什么是Shiro？**

- Apache Shiro是一个Java的安全(权限）框架。
- Shiro 可以非常容易的开发出足够好的应用，其不仅可以用在JavaSE环境，也可以用在JavaEE环境。
- Shiro可以完成，认证，授权，加密，会话管理，Web集成，缓存等。

 下载：http://shiro.apache.org/                    **具体资料参考pdf**

#  功能简介 

主要的4个：
• ==Authentication==：身份认证/登录，验证用户是不是拥有相应的身份；
• ==Authorization==：授权，即权限验证，验证某个已认证的用户是否拥有某个权限；即判断用
户是否能进行什么操作，如：验证某个用户是否拥有某个角色。或者细粒度的验证某个用户
对某个资源是否具有某个权限；
• ==Session Manager==：会话管理，即用户登录后就是一次会话，在没有退出之前，它的所有
信息都在会话中；会话可以是普通 JavaSE 环境，也可以是 Web 环境的；
• ==Cryptography==：加密，保护数据的安全性，如密码加密存储到数据库，而不是明文存储；

其它：
• Web Support：Web 支持，可以非常容易的集成到Web 环境；
• Caching：缓存，比如用户登录后，其用户信息、拥有的角色/权限不必每次去查，这样可
以提高效率；
• Concurrency：Shiro 支持多线程应用的并发验证，即如在一个线程中开启另一个线程，能
• 把权限自动传播过去；
• Testing：提供测试支持；
• Run As：允许一个用户假装为另一个用户（如果他们允许）的身份进行访问；
• Remember Me：记住我，这个是非常常见的功能，即一次登录后，下次再来的话不用登
录了

![1608111440893](shiro.assets/1608111440893.png)

#  Shiro 架构(Shiro外部来看) 

• ==Subject==：应用代码直接交互的对象是 Subject，也就是说 Shiro 的对外
API 核心就是 Subject。==Subject 代表了当前“用户”==， 这个用户不一定
是一个具体的人，与当前应用交互的任何东西都是 Subject，如网络爬虫，
机器人等；==与 Subject 的所有交互都会委托给 SecurityManager；==
==Subject 其实是一个门面，SecurityManager 才是实际的执行者；==

• ==SecurityManager==：安全管理器；==即所有与安全有关的操作都会与==
==SecurityManager 交互==；且其管理着所有 Subject；可以看出它是 ==Shiro==
==的核心，它负责与 Shiro 的其他组件进行交互==，它相当于 SpringMVC 中
DispatcherServlet 的角色

• ==Realm==：==Shiro 从 Realm 获取安全数据（如用户、角色、权限）==，就是说
SecurityManager 要验证用户身份，那么它需要从 Realm 获取相应的用户
进行比较以确定用户身份是否合法；也需要从 Realm 得到用户相应的角色/
权限进行验证用户是否能进行操作；可以把 Realm 看成 DataSource

![1608111121802](shiro.assets/1608111121802.png)

#  Shiro 架构(Shiro内部来看) 

• Subject：任何可以与应用交互的“用户”；
• SecurityManager ：相当于SpringMVC 中的 DispatcherServlet；是 Shiro 的心脏；
所有具体的交互都通过 SecurityManager 进行控制；它管理着所有 Subject、且负责进
行认证、授权、会话及缓存的管理。
• ==Authenticator：负责 Subject 认证==，是一个扩展点，可以自定义实现；可以使用认证
策略（Authentication Strategy），即什么情况下算用户认证通过了；
• ==Authorizer：授权器、即访问控制器==，用来决定主体是否有权限进行相应的操作；==即控==
==制着用户能访问应用中的哪些功能；==
• Realm：可以有 1 个或多个 Realm，可以认为是安全实体数据源，即用于获取安全实体
的；可以是JDBC 实现，也可以是内存实现等等；由用户提供；所以一般在应用中都需要
实现自己的 Realm；
• ==SessionManager：管理 Session 生命周期的组件==；而 Shiro 并不仅仅可以用在 Web
环境，也可以用在如普通的 JavaSE 环境
• ==CacheManager：缓存控制器==，来管理如用户、角色、权限等的缓存的；因为这些数据
基本上很少改变，放到缓存中后可以提高访问的性能
• ==Cryptography：密码模块==，Shiro 提高了一些常见的加密组件用于如密码加密/解密。

![1608111227018](shiro.assets/1608111227018.png)

# 快速入门

进入shiro官网    http://shiro.apache.org/       点击get started    10分钟的教程  （进的很慢）

1.导入依赖
2.导入日志文件和shiro.ini文件
3.quickstart

```xml
  <dependency>
            <groupId>org.apache.shiro</groupId>
            <artifactId>shiro-core</artifactId>
            <version>1.4.1</version>
        </dependency>

        <!-- configure logging -->
        <dependency>
            <groupId>org.slf4j</groupId>
            <artifactId>jcl-over-slf4j</artifactId>
            <version>1.7.21</version>
        </dependency>
        <dependency>
            <groupId>org.slf4j</groupId>
            <artifactId>slf4j-log4j12</artifactId>
            <version>1.7.21</version>
        </dependency>
        <dependency>
            <groupId>log4j</groupId>
            <artifactId>log4j</artifactId>
            <version>1.2.17</version>
        </dependency>

```

resources下的log4j.properties

```properties
log4j.rootLogger=INFO, stdout

log4j.appender.stdout=org.apache.log4j.ConsoleAppender
log4j.appender.stdout.layout=org.apache.log4j.PatternLayout
log4j.appender.stdout.layout.ConversionPattern=%d %p [%c] - %m %n

# General Apache libraries
log4j.logger.org.apache=WARN

# Spring
log4j.logger.org.springframework=WARN

# Default Shiro logging
log4j.logger.org.apache.shiro=INFO

# Disable verbose logging
log4j.logger.org.apache.shiro.util.ThreadContext=WARN
log4j.logger.org.apache.shiro.cache.ehcache.EhCache=WARN
```

resources下的shiro.ini文件

```ini
[users]
# user 'root' with password 'secret' and the 'admin' role
root = secret, admin
# user 'guest' with the password 'guest' and the 'guest' role
guest = guest, guest
# user 'presidentskroob' with password '12345' ("That's the same combination on
# my luggage!!!" ;)), and role 'president'
presidentskroob = 12345, president
# user 'darkhelmet' with password 'ludicrousspeed' and roles 'darklord' and 'schwartz'
darkhelmet = ludicrousspeed, darklord, schwartz
# user 'lonestarr' with password 'vespa' and roles 'goodguy' and 'schwartz'
lonestarr = vespa, goodguy, schwartz

# -----------------------------------------------------------------------------
# Roles with assigned permissions
# 
# Each line conforms to the format defined in the
# org.apache.shiro.realm.text.TextConfigurationRealm#setRoleDefinitions JavaDoc
# -----------------------------------------------------------------------------
[roles]
# 'admin' role has all permissions, indicated by the wildcard '*'
admin = *
# The 'schwartz' role can do anything (*) with any lightsaber:
schwartz = lightsaber:*
# The 'goodguy' role is allowed to 'drive' (action) the winnebago (type) with
# license plate 'eagle5' (instance specific id)
goodguy = winnebago:drive:eagle5

```

Quickstart.java

```java
/**
        Subject currentUser = SecurityUtils.getSubject(); //获取当前的用户对象的Subject
        Session session = currentUser.getSession();  // 通过当前用户拿到Session
        currentUser.isAuthenticated()  // 判断当前的用户是否被认证   可以执行登录操作
        currentUser.getPrincipal()    //获取当前用户的认证
        currentUser.hasRole("schwartz")  //用户是否拥有什么角色
        currentUser.isPermitted("lightsaber:wield")  //获取当前用户的权限
        currentUser.logout();   //注销
*/	

public class Quickstart {

    private static final transient Logger log = LoggerFactory.getLogger(Quickstart.class);


    public static void main(String[] args) {


        Factory<SecurityManager> factory = new IniSecurityManagerFactory("classpath:shiro.ini");
        SecurityManager securityManager = factory.getInstance();
        SecurityUtils.setSecurityManager(securityManager);

        //获取当前的用户对象的Subject
        Subject currentUser = SecurityUtils.getSubject();

        // 通过当前用户拿到Session
        Session session = currentUser.getSession();
        session.setAttribute("someKey", "aValue");
        String value = (String) session.getAttribute("someKey");
        if (value.equals("aValue")) {
            log.info("Retrieved the correct value! [" + value + "]");
        }

        // 判断当前的用户是否被认证
        if (!currentUser.isAuthenticated()) {
            //令牌，没有获取，随机
            UsernamePasswordToken token = new UsernamePasswordToken("lonestarr", "vespa");
            token.setRememberMe(true);//设置记住我
            try {
                currentUser.login(token);//执行登录操作
            } catch (UnknownAccountException uae) {
                log.info("There is no user with username of " + token.getPrincipal());
            } catch (IncorrectCredentialsException ice) {
                log.info("Password for account " + token.getPrincipal() + " was incorrect!");
            } catch (LockedAccountException lae) {
                log.info("The account for username " + token.getPrincipal() + " is locked.  " +
                        "Please contact your administrator to unlock it.");
            }
            // ... catch more exceptions here (maybe custom ones specific to your application?
            catch (AuthenticationException ae) {
                //unexpected condition?  error?
            }
        }
        //获取当前用户的认证
        //say who they are:
        //print their identifying principal (in this case, a username):
        log.info("User [" + currentUser.getPrincipal() + "] logged in successfully.");

        //用户是否拥有什么角色， 和ini文件里的对应
        //test a role:
        if (currentUser.hasRole("schwartz")) {
            log.info("May the Schwartz be with you!");
        } else {
            log.info("Hello, mere mortal.");
        }
        //粗粒度，获取当前用户的权限
        //test a typed permission (not instance-level)
        if (currentUser.isPermitted("lightsaber:wield")) {
            log.info("You may use a lightsaber ring.  Use it wisely.");
        } else {
            log.info("Sorry, lightsaber rings are for schwartz masters only.");
        }
        //细粒度
        //a (very powerful) Instance Level permission:
        if (currentUser.isPermitted("winnebago:drive:eagle5")) {
            log.info("You are permitted to 'drive' the winnebago with license plate (id) 'eagle5'.  " +
                    "Here are the keys - have fun!");
        } else {
            log.info("Sorry, you aren't allowed to drive the 'eagle5' winnebago!");
        }
        //注销
        //all done - log out!
        currentUser.logout();
        //结束
        System.exit(0);
    }
}

```



# SpringBoot联合Shiro（简单）

参考 ：https://www.cnblogs.com/elvinle/p/9192007.html

## 模板例子

1. **导入shiro整合spring的包**

```xml
  <!--导入shiro整合spring的包，其它包在上面-->
 <dependency>
            <groupId>org.apache.shiro</groupId>
            <artifactId>shiro-spring</artifactId>
            <version>1.4.1</version>
</dependency>
```

**2.编写ShiroConfig： Shiro的核心配置**

```java
@Configuration
public class ShiroConfig {
    //Filter工厂，设置对应的过滤条件和跳转条件以及对那些过滤
   // ShiroFilterFactoryBean：3
    @Bean
    public ShiroFilterFactoryBean getShiroFilterFactoryBean(@Qualifier("securityManager") DefaultWebSecurityManager defaultWebSecurityManager ){
       ShiroFilterFactoryBean bean = new ShiroFilterFactoryBean();
       //设置安全管理器
        bean.setSecurityManager(defaultWebSecurityManager);
        return bean;
    }
    
    //DefaultWebSecurityManager：2
    @Bean(name = "securityManager")
    public DefaultWebSecurityManager getDefaultWebSecurityManager(@Qualifier("userRealm") UserRealm userRealm){
       DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
       //关联UserRealm
        securityManager.setRealm(userRealm);
        return securityManager;

    }
    
   //创建 realm  对象 ，需要自定义：1
    @Bean
    public UserRealm userRealm(){
        return  new UserRealm();
    }
}
```

**3.自定义realm** 

```java
//自定义的 UserRealm   extends AuthorizingRealm
public class UserRealm extends AuthorizingRealm {
    //授权
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        System.out.println("执行了=>授权doGetAuthorizationInfo");
        return null;
    }
    //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        System.out.println("执行了=>认证doGetAuthenticationInfo");
        return null;
    }
}
```

**4.控制器MyController **

```java
@Controller
public class MyController {
    @RequestMapping({"/","/index"})
    public String toIndex(Model model){
        model.addAttribute("msg","hello,shiro");
        return "index";
    }
    @RequestMapping("/user/add")//templtes下的user包内的add.html页面
    public String add(){
       return "user/add";
    }
    @RequestMapping("/user/update")
    public String update(){
        return "user/update";
    }
}
```



5.添加html页面测试add.html和update.html（略）   和首页index.html

```html
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<h1>首页</h1>

<div th:text="${msg}"></div>

<a th:href="@{/user/add}">add</a>   |  <a th:href="@{/user/update}">update</a>


</body>
```



## 详细实例

**https://blog.csdn.net/ligh_sqh/article/details/86624049**

### 基本知识

**shiro的内置过滤器：**

```properties
anon:无需认证就可以访问
authc:必须认证了才能让问
user:必须拥有记住我功能才能用
perms:拥有对某个资源的权限才能访问;
roLe:拥有某个角色权限才能访问
.........
```

![1608195968918](shiro.assets/1608195968918.png)



### 基本的用户拦截认证

**ShiroConfig类中修改：**

```java
 //Filter工厂，设置对应的过滤条件和跳转条件
   // ShiroFilterFactoryBean：3 
@Bean
    public ShiroFilterFactoryBean getShiroFilterFactoryBean(@Qualifier("securityManager") DefaultWebSecurityManager defaultWebSecurityManager ){
       ShiroFilterFactoryBean bean = new ShiroFilterFactoryBean();
       //设置安全管理器
        bean.setSecurityManager(defaultWebSecurityManager);

        //拦截，添加shiro的内置过滤器，对那些过滤   
        Map<String,String> filterMap  = new LinkedHashMap<>();
        filterMap.put("/user/add","authc");
        filterMap.put("/user/update","authc");
        bean.setFilterChainDefinitionMap(filterMap);
        //拦截后跳到登录的页面，设置登录的请求
        bean.setLoginUrl("/toLogin");
        return bean;
    }
//.........
```

MyController 添加：

```java
@RequestMapping("/toLogin")
public String toLogin(){    
return "login";//login.html页面自己写，只有用户名和密码，提交
}
```

### 用户认证，连数据库

**先自己用Mybatis连接数据库**

MyController 里添加：

```java

    @RequestMapping("/login")
    public String login(String username,String password,Model model){
        //获取当前的用户
        Subject subject = SecurityUtils.getSubject();
        //封装用户的登录数据
        UsernamePasswordToken token = new UsernamePasswordToken(username,password);

        try{
            //执行认证   最重要的，和自定义的UserRealm交互,执行认证方法doGetAuthenticationInfo
            subject.login(token);//执行登录的方法，没有异常就ok了  传token到UserRealm里的用户认证
            return "index";//登录成功，返回首页
        }catch (UnknownAccountException e){//用户名不存在
           model.addAttribute("msg","用户名错误");
            return "login";
        }catch (IncorrectCredentialsException ice){//密码不存在
            model.addAttribute("msg","密码错误");
            return "login";
        }
    }
```

UserRealm里修改

```java
  //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        System.out.println("执行了=>认证doGetAuthenticationInfo");

        //用户名  密码 数据库中取   我们这里定义固定的
        String name = "root";
        String password = "123456";

        UsernamePasswordToken userToken = (UsernamePasswordToken) token;

        if (!userToken.getUsername().equals(name)){
            return null;//抛出异常  UnknownAccountException
        }
        //密码认证  shiro做
        return new SimpleAuthenticationInfo("",password,"");
    }

//整合mybatis后的
   System.out.println("执行了=>认证doGetAuthenticationInfo");

        UsernamePasswordToken userToken = (UsernamePasswordToken) token;

        User user = userService.queryUserByName(userToken.getUsername());
        if (user==null){
            return null;
        }
        //密码可以加密  如 MD5加密
        //密码认证  shiro做
        return new SimpleAuthenticationInfo("",user.getPwd(),"");

```

login.html

```html
<body>
<h1>登录</h1>

<p th:text="${msg}" style="color: red"></p>
<form th:action="@{/login}">
    <p>用户名：<input type="text" name="username"></p>
    <p>密码：<input type="text" name="password"></p>
    <p><input type="submit" value="提交"></p>
</form>

</body>
```



### 授权

数据库更改

![1608276716884](shiro.assets/1608276716884.png)



User类添加

```java
 private String perms; //授权
//.........
```

ShiroConfig配置类更改

```java
 public ShiroFilterFactoryBean getShiroFilterFactoryBean(@Qualifier("securityManager") DefaultWebSecurityManager defaultWebSecurityManager ){
       ShiroFilterFactoryBean bean = new ShiroFilterFactoryBean();
       //设置安全管理器
        bean.setSecurityManager(defaultWebSecurityManager);

        //拦截，添加shiro的内置过滤器，对那些过滤
        Map<String,String> filterMap  = new LinkedHashMap<>();
        //授权,正常的情况下,没有授权会跳转到未授权页面
        filterMap.put("/user/add","perms[user:add]");
        filterMap.put("/user/update","perms[user:update]");
        //拦截
        filterMap.put("/user/*","authc");

        bean.setFilterChainDefinitionMap(filterMap);
        //拦截后跳到登录的页面，设置登录的请求
        bean.setLoginUrl("/toLogin");

        //未授权页面
        bean.setUnauthorizedUrl("/noauth");


        return bean;
    }
```

MyController类添加

```java
  @RequestMapping("/noauth")
    @ResponseBody
    public String unauthorized(){
        return "未授权无法访问此页面";
    }

```

UserRealm类更改

```java
//授权
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        System.out.println("执行了=>授权doGetAuthorizationInfo");
         //SimpleAuthorizationInfo
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        //info.addStringPermission("user:add");

        //拿到当前登录的这个对象
        Subject subject = SecurityUtils.getSubject();
        User currentUser = (User) subject.getPrincipal(); //拿到User对象，是下面的认证返回的
        System.out.println(currentUser.getPerms());
        //设置当前用户的权限
        info.addStringPermission(currentUser.getPerms());

        return info;
    }
 //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
    //..............只把  user  添加到返回里了
          return new SimpleAuthenticationInfo(user,user.getPwd(),"");
    }
```

###  thymeleaf和shiro标签整合使用 

1、 导入依赖 

```xml
<!--thymeleaf扩展依赖-->
<dependency>
    <groupId>com.github.theborakompanioni</groupId>
    <artifactId>thymeleaf-extras-shiro</artifactId>
    <version>2.0.0</version>
</dependency>        
```

ShiroConfig添加

```java
//整合ShiroDialect:用来整合shiro thymeLeaf
    @Bean
    public ShiroDialect getShiroDialect(){
        return new ShiroDialect();
    }
```

index.html页面更改

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org"
      xmlns:shiro="http://www.thymeleaf.org/thymeleaf-extras-shiro">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<h1>首页</h1>
<a th:href="@{/toLogin}">登录</a>


<div th:text="${msg}"></div>

<div shiro:hasPermission="user:add">
    <a th:href="@{/user/add}">add</a>
</div>

<div shiro:hasPermission="user:update">
<a th:href="@{/user/update}">update</a>
</div>

</body>
</html>
```



**补充：登录成功取消登录按钮**

UserRealm修改

```java
 //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        System.out.println("执行了=>认证doGetAuthenticationInfo");

        UsernamePasswordToken userToken = (UsernamePasswordToken) token;

        User user = userService.queryUserByName(userToken.getUsername());
        if (user==null){
            return null;
        }
      //添加的内容  这三行代码看你自己添加到什么地方，不一定是在这里
        Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession();
        session.setAttribute("loginUser",user);


       // System.out.println(user);
        //密码认证  shiro做
        return new SimpleAuthenticationInfo(user,user.getPwd(),"");
    }
```

index.html修改

```html
<!--从session中判断值-->
<div th:if="${session.loginUser==null}">
    <a th:href="@{/toLogin}">登录</a>
</div>
```



### 会话（略）

### 缓存（略）







 