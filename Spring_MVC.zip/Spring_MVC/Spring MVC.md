# Spring MVC

![1604385739301](Spring MVC.assets/1604385739301.png)

![1607080077837](Spring MVC.assets/1607080077837.png)

从图 1 可总结出 Spring MVC 的工作流程如下： 

1.  客户端请求提交到 DispatcherServlet。
2.  由 DispatcherServlet 控制器寻找一个或多个 HandlerMapping，找到处理请求的 Controller。
3.  DispatcherServlet 将请求提交到 Controller。
4.  Controller 调用业务逻辑处理后返回 ModelAndView。
5.  DispatcherServlet 寻找一个或多个 ViewResolver 视图解析器，找到 ModelAndView 指定的视图。
6.  视图负责将结果显示到客户端。

SpringMVC 框架是以请求为驱动，围绕 Servlet 设计，将请求发给控制器，然后通过模型对象，分派器来展示请求结果视图。其中核心类是 DispatcherServlet，它是一个 Servlet，顶层是实现的Servlet接口。

SpringMVC 是spring的一个子框架

**SpringMVC 其实相当于前后端交互，代替servlet来交互**

**是解决 WEB 层问题的 MVC 框架** 

**处理器映射器、处理器适配器、视图解析器**称为SpringMVC的三大组件。



# 准备工作

1.在maven项目中导入（当然还有其它包，不要忘了）

```xml
 <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-webmvc</artifactId>
      <version>5.0.5.RELEASE</version>
    </dependency>
```

2.新建springmvc配置文件，我这里是在recources资源文件中配置的，记得要和spring配置文件区分开：
spring-mvc.xml（命名看你自己）

# 快速入门+实例

**后面的代码参照这个**

**SpringMVC的开发步骤**
1、导入SpringMVC相关坐标
2、配置SpringMVC核心控制器DispathcerServlet
3、创建Controller类和视图页面
4、使用注解配置Controller类中业务方法的映射地址
5、配置SpringMVC核心文件spring-mvc.xml
6、客户端发起请求测试
**注意：在maven中配置的时候jar版本最好一致**

web.xml配置

```xml
<!--  配置SpringMVC的前端控制器-->
<servlet>
  <servlet-name>DispatcherServlet</servlet-name>
 <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
           <!-- 配置DispatcherServlet的初始化参数：SpringMvc配置文件的位置和名称 -->
  <init-param>
    <param-name>contextConfigLocation</param-name>
    <param-value>classpath:spring-mvc.xml</param-value>
  </init-param>
  <load-on-startup>1</load-on-startup>
           <!--load-on-startup是否应该在web应用程序启动的时候就加载这个servlet-->
</servlet>

<servlet-mapping>
  <servlet-name>DispatcherServlet</servlet-name>
  <url-pattern>/</url-pattern>
</servlet-mapping>
  
```

UserController类

```java
package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller    //定义控制器类
public class UserController {

    @RequestMapping("/quick")   //使用注解配置Controller类中业务方法的映射地址
    public String save(){
         System.out.println("Controller save running......");       
       //可以直接返回 return "/WEB-INF/pages/one.jsp"; 
       //或者在spring-mvc.xml中配置，然后返回(这里用这种)
         return "one";      
    }
}
```

index.jsp 开始的页面

```
<h1>入门程序</h1>
<a href="quick">入门</a>
```

one.jsp

```
<body>
<h1>入门成功</h1>
</body>
```

spring-mvc.xml

```xml
<!--扫描包-->
<context:component-scan base-package="controller"></context:component-scan>

<!--配置内部资源视图解析器，可用可不用-->
    <bean id="internalResourceViewResolver" class="org.springframework.web.servlet.view.InternalResourceViewResolver">
     <property name="prefix" value="/WEB-INF/pages/"></property>
     <property name="suffix" value=".jsp"></property>
    </bean>  
       <!--prefix是前缀；suffix是后缀-->

<!--mvc的注解驱动-->
<mvc:annotation-driven/>
```

地址：
http://localhost:8770/springmvc/
http://localhost:8770/springmvc/quick

结果：

<img src="Spring MVC.assets/1604385094027.png" alt="1604385094027" style="zoom: 67%;" />

<img src="Spring MVC.assets/1604385107303.png" alt="1604385107303" style="zoom:67%;" />

#  SpringMVC的注解解析

## **@RequestMapping**

作用:用于建立请求URL和处理请求方法之间的对应关系
位置:
           类上，请求URL的第一级访问目录。此处不写的话，就相当于应用的根目录
           方法上，请求URL的第二级访问目录，与类上的使用@ReqquestMapping标注的一级目录一起组成访问虚      -----拟路径
**属性**:
      value:用于指定请求的URL。它和path属性的作用是一样的，只有一个时可以不加
      method:用于指定请求的方式
      params:用于指定限制请求参数的条件.它支持简单的表达式.要求请求参数的key和value必须和配置的一模一样
       例如:
              params = {"accountName"}，表示请求参数必须有accountName
               params = {"moeny!100"}表示请求参数中money不能是100

```java
// 访问地址：  http://localhost:8770/springmvc/user/quick?username=12

@Controller
@RequestMapping("/user")
public class UserController {     //添加请求参数
    @RequestMapping(value = "/quick",method = RequestMethod.GET,params = {"username"})
    public String save(){
        System.out.println("Controller save running......");
        return "one";
    }
}
```



# XML配置解析（三大组件）

https://www.cnblogs.com/jimisun/p/7916615.html

**springMVC三大组件：**

**处理器映射器—RequestMappingHandlerMapping**    用户请求路径到Controller方法的映射

**处理器适配器—RequestMappingHandlerAdapter**     根据handler(controlelr类）的开发方式（注解开发/其他开发） 方式的不同区寻找不同的处理器适配器

**springMVC视图解析器**—**InternalResourceViewResolver**     根据handler返回的view地址文件类型（jsp/pdf….）去寻找相应的视图解析器来进行解析

**在springMVC配置文件中配置：**

## 处理器映射器

```
<!-- 配置处理器映射器 -->
<bean class="
org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping"/>
```

## 处理器适配器

```
<!-- 处理器适配器 -->
<bean class="
org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter" />
```

以上两项为配合使用，配置在springMVC核心配置文件中，不可只进行单一配置，但是这种配置方法太过于复杂，所以**万能的官方为我们提供了更简单的方式：**

```
    <!-- 注解驱动:
        作用:替我们自动配置最新版的注解的  处理器映射器 和 处理器适配器     哦，记得引入名称空间 mvc
     -->
    <mvc:annotation-driven></mvc:annotation-driven>
```

## Spring 视图解析器

```java
<!--配置内部资源视图解析器   可配可不配
作用:在controller中指定页面路径的时候就不用写页面的完整路径名称了,可以直接写页面去掉扩展名的名称
-->
<bean class="org.springframework.web.servlet.view.InternalResourceViewResolver" >
    <!--配置视图响应的  前缀-->
    <property name="prefix" value="/WEB-INF/pages/"/>
    <!--配置视图响应的  后缀-->
    <property name="suffix" value=".jsp"/>
</bean>
 <!--根据需要自己是否要在bean中加id-->
```

上述视图解析器配置了前缀和后缀两个属性，然后以后的路径会自动添加前缀和后缀。

## ==入门必配：==

在springmvc配置文件中，即spring-mvc.xml：

```xml
<!-- 配置@Controller注解扫描 exclude-filter和 include-filter看自己配不配(记得在这个标签里)-->
<context:component-scan base-package="包路径或类路径"></context:component-scan>

<!-- 注解驱动:作用:替我们自动配置最新版的注解的处理器映射器和处理器适配器-->
<mvc:annotation-driven></mvc:annotation-driven>

<!-- 配置视图解析器  可配可不配
    作用:在controller中指定页面路径的时候就不用写页面的完整路径名称了,可以直接写页面去掉扩展名的名称
    -->
    <bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
        <!-- 真正的页面路径 =  前缀 + 去掉后缀名的页面名称 + 后缀 -->
        <!-- 前缀 -->
        <property name="prefix" value="/WEB-INF/jsp/"></property>
        <!-- 后缀 -->
        <property name="suffix" value=".jsp"></property>
    </bean>
```

web.xml配置配置：

```xml
<!--  配置SpringMVC的前端控制器-->
<servlet>
  <servlet-name>DispatcherServlet</servlet-name>
 <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
           <!-- 配置DispatcherServlet的初始化参数：SpringMvc配置文件的位置和名称 -->
  <init-param>
    <param-name>contextConfigLocation</param-name>
    <param-value>classpath:spring-mvc.xml</param-value>
  </init-param>
  <load-on-startup>1</load-on-startup>
           <!--load-on-startup是否应该在web应用程序启动的时候就加载这个servlet-->
</servlet>

<servlet-mapping>
  <servlet-name>DispatcherServlet</servlet-name>
  <url-pattern>/</url-pattern>
</servlet-mapping>
```



# 转发与重定向

**redirect 和  forward**

在 Spring MVC框架中，控制器类中处理方法的 ==return 语句默认就是转发实现==，只不过实现的是转发到视图

```java
@RequestMapping("/quick")
public String quick() {
    return "a";  //转发到a.jsp
}
```

重定向与转发的示例代码如下： 

```java
@Controller
@RequestMapping("/index")
public class IndexController {
    @RequestMapping("/login")
    public String login() {
        //转发到一个请求方法（同一个控制器类可以省略/index/）
        return "forward:/index/isLogin";
    }

    @RequestMapping("/isLogin")
    public String isLogin() {
        //重定向到一个请求方法
        return "redirect:/index/isRegister";
    }

    @RequestMapping("/isRegister")
    public String isRegister() {
        //转发到一个视图
        return "register";
    }
}
```



# 数据响应

 SpringMVC的数据响应方式
1、页面跳转
         直接返回字符串
         通过ModelAndView对象返回
2、回写数据
         直接返回字符串
         返回对象或集合

## 页面跳转

**1.返回字符串形式**
直接返回字符串:此种方式会将返回的字符串与视图解析器的前后缀拼接后跳转。

<img src="Spring MVC.assets/1604373091193.png" alt="1604373091193" style="zoom: 67%;" />

**2.返回ModelAndView对象**

访问地址：http://localhost:8770/springmvc/user/quick2   等

```java
@Controller
@RequestMapping("/user")
public class UserController {

//方式1：返回ModelAndView对象
    @RequestMapping("/quick2")
    public ModelAndView save2(){
      /*  Model:模型 作用封装数据
        View:视图  作用展示数据
      */
        ModelAndView modelAndView = new ModelAndView();
       //设置模型数据   放到了request域对象中
         modelAndView.addObject("username","value值或对象");
       //设置视图名称   one是要在   /WEB-INF/pages/  下有的，参照快速入门实例
        modelAndView.setViewName("one");
        return modelAndView;
    }
//方式二：
    @RequestMapping("/quick3")
    public ModelAndView save3(ModelAndView modelAndView){
        modelAndView.addObject("username","value值3");
        modelAndView.setViewName("one");
        return modelAndView;
    }

//方式三：将模型和视图拆开  Model是模型  字符串代表视图 Model是框架帮你封装好的对象
    @RequestMapping("/quick4")
    public String save4(Model model){
        model.addAttribute("username","value值4");
        return "one";
    }

//原生的方式：用request对象；虽然这里是普通类和普通方法，但是是框架调用，常用的对象人家都想好了的
    //所以加形参，框架会帮你做； 原生的方式不常用
    @RequestMapping("/quick5")
    public String save5(HttpServletRequest request){
        request.setAttribute("username","value值5");
        return "one";
    }
     
   
//返回字符串形式
   @RequestMapping(value = "/quick")
    public String save(){
        System.out.println("Controller save running......");
        return "one";
    }
}
```

one.jsp

```java
<h1>入门成功 ${username}</h1>
```



## 回写数据

   直接返回字符串
   返回对象或集合

**1、直接返回字符串**
Web基础阶段，客户端访问服务器端，如果想直接回写字符串作为响应体返回的话，只需要使用
response.getWriter().print(“hello world”)即可，那么在Controller中想直接回写字符串该怎样呢?

**1.1：**通过SpringMVC框架注入的response对象，使用response.getWriter).print(“hello world”)回写数
据，此时不需要视图跳转，业务方法返回值为void。

```java
 @RequestMapping("/quick6")
       public void save6(HttpServletResponse response) throws IOException {
        response.getWriter().println("back");
       }
```

**1.2：**将需要回写的字符串直接返回，但此时需要通过**@ResponseBody注解告知SpringMVC框架，方法返回的字符串不是跳转是直接在http响应体中返回**。

**@ResponseBody：告诉页面不进行页面跳转**

```java
  @RequestMapping(value = "/quick7")
    @ResponseBody  //告知SpringMVC框架  不进行视图跳转  直接进行数据响应
    public String save7(){
        return "hello return String";
    }
```

**1.3：回写json字符串**

```xml
    <dependency>
      <groupId>com.fasterxml.jackson.core</groupId>
      <artifactId>jackson-core</artifactId>
      <version>2.10.0</version>
    </dependency>

    <dependency>
      <groupId>com.fasterxml.jackson.core</groupId>
      <artifactId>jackson-databind</artifactId>
      <version>2.10.0</version>
    </dependency>
```

```java
方式一：直接回写
 @RequestMapping(value = "/quick8")
    @ResponseBody
    public String save8(){
        return "{\"username\":\"JOJO\",\"age\":18}";
    }
    
    
方式二：使用json的转换工具将对象转换成json格式字符串在返回
 @RequestMapping(value = "/quick9")
    @ResponseBody
    public String save9() throws JsonProcessingException {
        User user = new User("JoJo",12);
        //使用json的转换工具将对象转换成json格式字符串再返回
        ObjectMapper objectMapper =new ObjectMapper();
        String json = objectMapper.writeValueAsString(user);
        return json;
    }
```



**2、返回对象或集合**

导入包：

```xml
   <dependency>
      <groupId>com.fasterxml.jackson.core</groupId>
      <artifactId>jackson-core</artifactId>
      <version>2.10.0</version>
    </dependency>
  
    <dependency>
      <groupId>com.fasterxml.jackson.core</groupId>
      <artifactId>jackson-databind</artifactId>
      <version>2.10.0</version>
    </dependency>
   
    <dependency>
      <groupId>com.fasterxml.jackson.core</groupId>
      <artifactId>jackson-annotations</artifactId>
      <version>2.10.0</version>
    </dependency>
```

**2.1：配置方式一（较为麻烦，不常用）**：

```xml
 <!--配置处理器映射器-->
    <bean class="org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter">
        <property name="messageConverters">
            <list>
                <bean class="org.springframework.http.converter.json.MappingJackson2HttpMessageConverter"></bean>
            </list>
        </property>
    </bean>
```

**2.2：配置方式二(最简单实用):mvc的注解驱动**

## **mvc的注解驱动（重要）**

在方法上添加@ResponseBody就可以返回json格式的字符串，但是这样配置比较麻烦，配置的代码比较多（上面的代码）因此，我们可以**使用mvc的注解驱动代替上述配置**。

```
<!--mvc的注解驱动-->
<mvc:annotation-driven/>
```

在SpringMVC的各个组件中，**处理器映射器、处理器适配器、视图解析器**称为SpringMVC的三大组件。使用<mvcannotation-driven>**自动加载**RequestMappingHandlerMapping (**处理映射器**）和
RequestMappingHandlerAdapter(**处理适配器**），可用在Spring-xml.xml配置文件中使用<mvc:annotation-driven>替代注解处理器和适配器的配置。

同时使用<mvcannotation-driven>默认底层就会集成jackson进行对象或集合的json格式字符串的转换。

**注入名称空间mvc  并  配置mvc的注解驱动**

```xml
 ...........
 xmlns:mvc="http://www.springframework.org/schema/mvc"
   http://www.springframework.org/schema/mvc http://www.springframework.org/schema/mvc/spring-mvc.xsd
 ...........
 
  <!--将2.1中的配置注解掉，用下面的这个-->
 
 <!—-mvc的注解驱动-->
<mvc:annotation-driven/>
```

类中：

```java
   @RequestMapping(value = "/quick10")
    @ResponseBody
    //SpringMVC自动将User转换成json格式的字符串
    public User save10(){
        User user = new User("DioDio",32);
        return user;
    }
```



# ==获得请求数据==

客户端请求参数的格式是: name=value&name=value.....
服务器端要获得请求的参数，有时还需要进行数据的封装，SpringMVC可以接收如下类型的参数:

**基本类型参数**
**POJO类型参数**
**数组类型参数**
**集合类型参数**

## 接受的参数类型

**获得基本类型参数**
Controller中的   **业务方法的参数名称要  与  请求参数的name**   一致，参数值会自动映射匹配。
大白话就是：通过带    请求参数和形参一致，SpringMVC会自动匹配  ，如：

请求中：http://localhost:8770/springmvc/user/quick11?username=JOJO&age=120 有参数

```java
    //访问：请求参数和形参一致就会自动匹配
    @RequestMapping(value = "/quick11")
    @ResponseBody
    public void save11(String username,int age){
        System.out.println(username);
        System.out.println(age);
    }
结果：
JOJO
120
 
```

**获得POJO类型参数**
Controller中的业务方法的POJO参数的属性名与请求参数的name一致，参数值会自动映射匹配。如：
请求中：http://localhost:8770/springmvc/user/quick11?username=DioDio&age=230 有参数

```java
    @RequestMapping(value = "/quick12")
    @ResponseBody
    public void save12(User user){
        System.out.println(user.toString());
    }
    
结果：
User{username='DioDio', age=230}

User类有username和age属性
```



**获得数组类型参数**
Controller中的业务方法数组名称与请求参数的name一致，参数值会自动映射匹配。如：
http://localhost:8770/springmvc/user/quick13?strs=aaa&strs=bbb&strs=ccc

```java
    @RequestMapping(value = "/quick13")
    @ResponseBody
    public void save1(String[] strs){
        System.out.println(Arrays.asList(strs));
    }
结果：
[aaa, bbb, ccc]
```



**集合类型参数**

方法一：
获得集合参数时，要将集合参数包装到一个POJO中才可以。（不常用）
实例：略
我的要报错：500

方法二：
当使用ajax提交时，可以指定contentType为json形式，那么在方法参数位置使用@RequestBody可以直接接收集合数据而无需使用POJO进行包装。
我的要报错：500

**所以我在方法二基础上用第三方包来解析json格式的字符串**

**步骤：**
1、导入第三方包
2、编写jsp,获得数据，然后数据通过ajax传入后台，**传入格式为json的字符串** 因为前后端都是传字符串或二进制
3、**获得字符串**，通过第三方包解析

导入阿里巴巴的第三方包  来解析json

```xml
 <dependency>
      <groupId>com.alibaba</groupId>
      <artifactId>fastjson</artifactId>
      <version>1.2.58</version>
    </dependency>
```

ajax.jsp

```html
 <script>
        var userList = new Array();
        userList.push({username:"DioDio",age:180});
        userList.push({username:"jojo",age:29});

        $.ajax({
            type:"POST",
            url:"http://localhost:8770/springmvc/user/quick15",
            data:JSON.stringify(this.userList),
            contentType:"application/json ",
            success:function (data) {
                alert("成功");
            },
            dataType: "json"

        });
    </script>

```

后台解析：

```java
    //获取集合参数用这种
    @RequestMapping(value = "/quick15",method = RequestMethod.POST)
    @ResponseBody
        public void save15(@RequestBody String userList) throws IOException{
        System.out.println(userList);
        //用第三方包转换  字符串为集合对象   （字符串是json格式）
        List<User> users= JSONArray.parseArray(userList,User.class);
        System.out.println(users);
        System.out.println(userList);
    }
```



## **请求数据乱码问题**

**当post请求时，数据会出现乱码**，我们可以设置一个过滤器来进行编码的过滤。

web.xml中配置：

```xml
<!--配置全局过滤的filter-->
<filter>
    <filter-name>CharacterEncodingFilter</filter-name>
    <filter-class>org.springframework.web.filter.CharacterEncodingFilter</filter-class>
    <init-param>
        <param-name>encoding</param-name>
        <param-value>UTF-8</param-value>
    </init-param>
</filter>
<filter-mapping>
    <filter-name>CharacterEncodingFilter</filter-name>
    <url-pattern>/*</url-pattern>
</filter-mapping>
```



## **参数绑定注解@RequestParam**(用的多)

当请求的参数名称与Controller的业务方法参数名称不一致时，就需要通过@RequestParam注解显示的绑定。

![1604542110083](Spring MVC.assets/1604542110083.png)

![1604542227690](Spring MVC.assets/1604542227690.png)



## 其它（了解，要知道有）

**获得Restful风格的参数(了解)**

**使用@PathVariable注解(了解)：**

**自定义类型转换器(了解)**

**获得servlet原生的API**

**获得请求头（用的不多）**

**@CookieValue**



**获得Restful风格的参数(了解)**

Restful是一种软件**架构风格、设计风格**，而不是标准，只是提供了一组设计原则和约束条件。主要用于客户端和服务器交互类的软件，基于这个风格设计的软件可以更简洁，更有层次，更易于实现缓存机制等。	

Restful风格的请求是使用“**url+请求方式**”表示一次请求目的的，HTTP协议里面四个表示操作方式的动词如下:
GET:用于获取资源
POST:用于新建资源
PUT:用于更新资源
DELETE:用于删除资源

例如:
/user1 GET :    得到id = 1的user
/user/1 DELETE:   删除 id = 1的user
/user/1 PUT:   更新id =1的user
/userPOST:     新增user

**使用@PathVariable注解(了解)：**

![1604542743560](Spring MVC.assets/1604542743560.png)



**自定义类型转换器(了解)**

SpringMVC默认已经提供了一些常用的类型转换器，例如客户端提交的字符串转换成int型进行参数设置。
但是不是所有的数据类型都提供了转换器，没有提供的就需要自定义转换器，例如:日期类型的数据就需要自定义转换器。

自定义类型转换器的开发步骤:
1、定义转换器类实现Converter接口
2、在配置文件中声明转换器    
3、在<annotation-driven>中引用转换器    //注解扫描的时候会自动用我们自己定义的转换器完成日期的转换

Date类不会改，就是这样的，因为在配置文件中用了声明，会自动转入。

http://localhost:8770/springmvc/user/quick18?date=2020-12-21    时间是这样的格式却不会报错



![1604576320472](Spring MVC.assets/1604576320472.png)

![1604543475618](Spring MVC.assets/1604543475618.png)

![1604543601074](Spring MVC.assets/1604543601074.png)

![1604543613841](Spring MVC.assets/1604543613841.png)



**获得servlet原生的API**

![1604544309648](Spring MVC.assets/1604544309648.png)





**获得请求头（用的不多）**

**@RequestHeader**
使用@RequestHeader可以获得请求头信息，相当于web阶段学习的 request.getHeader(name)
@RequestHeader注解的属性如下:
value:请求头的名称
required:是否必须携带此请求头

![1604544759186](Spring MVC.assets/1604544759186.png)

**@CookieValue**

使用@CookieValue可以获得指定Cookie的值
@CookieValue注解的属性如下:
value:指定cookie的名称
required:是否必须携带此cookie

![1604545044074](Spring MVC.assets/1604545044074.png)



## 静态资源访问的开启

<img src="Spring MVC.assets/1604539927784.png" alt="1604539927784" style="zoom:67%;" />



DispatcherServlet会拦截到所有的资源，导致一个问题就是静态资源（img、css、js）也会被拦截到，从而 不能被使用
即：前端控制器DispatcherServlet内部要帮你进行一个虚拟路径的匹配，匹配的是如：@RequestMapping（value="/quidk12"）这种，但在请求时，它把如jquery-3.3.1.js这种静态资源也当成了@RequestMapping进行匹配，当然我们是没有这个@RequestMapping的，所以访问不到

**解决方式一：自己配置**

```xml
<!--开法资源的访问-->
<mvc:resources mapping="/js/**" location="/js/"></mvc:resources>
<mvc:resources mapping="/img/**" location="/img/"></mvc:resources>

或可能因为<mvc:interceptors> 设置了拦截器，上面的可能不管用
<!-- 前端控制器 声明不必拦截的静态资源位置，location 属性里面 /后面加上**-->
<mvc:resources mapping="/js/**" location="/js/**"></mvc:resources>
<mvc:resources mapping="/img/**" location="/img/**"></mvc:resources>
```

**解决方式二：让tomcat内部的机制自动找静态资源**

表示在访问资源时找匹配的对应地址，如果找不到就交由原始的容器，这里的的原始容器是tomcat：
大白话即：mvc框架找不到资源时，就交由原始的容器tomcat来找

```xml
<mvc:default-servlet-handler/>
```



# 文件上传

**文件上传客户端三要素**：
表单项type= “file”
表单的提交方式是post
表单的enctype属性是多部分表单形式，及enctype= “multipart/form-data”

## **单文件上传步骤**

导入fileupload和io坐标
配置文件上传解析器
编写文件上传代码

导入fileupload和io坐标：

```xml
   <dependency>
      <groupId>commons-fileupload</groupId>
      <artifactId>commons-fileupload</artifactId>
      <version>1.3.1</version>
    </dependency>
    <dependency>
      <groupId>commons-io</groupId>
      <artifactId>commons-io</artifactId>
      <version>2.3</version>
    </dependency>
```

配置文件上传解析器：

```xml
    <!--配置文件上传解析器-->
<bean id="multipartResolver" class="org.springframework.web.multipart.commons.CommonsMultipartResolver">
    <!--上传文件总大小-->
    <property name="maxUploadSize" value="5242800"></property>
    <!--上传单个文件的大小-->
    <property name="maxUploadSizePerFile" value="5242800"></property>
    <!--上传文件的编码格式-->
     <property name="defaultEncoding" value="UTF-8"></property>
</bean>
```

编写文件上传代码
**记得把前端里的    name值   要和   后端参数MultipartFile的参加名   一样**
**即 <input type="file" name="file">中的name值要和   MultipartFile file 的参数一样都是file，不一样会报空指针异常：500**

```java
    @RequestMapping(value = "/quick21")
    @ResponseBody
    public void save21(String name, MultipartFile file) throws IOException {
        //获得文件名称
        String filename = file.getOriginalFilename();
        //保存文件
        file.transferTo(new File(new File("D:\\") + filename));
    }
```

```html
<p>单文件上传</p>
<form action="http://localhost:8770/springmvc/user/quick21" method="post" enctype="multipart/form-data">
   名称： <input type="text" name="name"><br>
    文件：<input type="file" name="file"><br>
    <input type="submit" name="提交">
</form>
```



## **多文件上传实现**

用多个参数的方式

![1604547745744](Spring MVC.assets/1604547745744.png)



![1604547769591](Spring MVC.assets/1604547769591.png)



用数组的方式

![1604547978986](Spring MVC.assets/1604547978986.png)

![1604547989269](Spring MVC.assets/1604547989269.png)





# 拦截器

**Spring MVC的拦截器类似于Servlet开发中的过滤器Filter，用于对处理器进行预处理和后处理。**

将拦截器按一定的顺序联结成一条链，这条链称为拦截器链(Interceptor Chain)。在访问被拦截的方法或字段时，拦截器链中的拦截器就会按其之前定义的顺序被调用。拦截器也是AOP思想的具体实现。

![1604558670546](Spring MVC.assets/1604558670546.png)



## 自定义拦截器

==interceptor==    拦截器

1、创建拦截器类实现Handlerlnterceptor接口
2、配置拦截器
3、测试拦截器的拦截效果

测试方法:

```java
    @RequestMapping(value = "/quick23")
    @ResponseBody
    public ModelAndView save23(){
        System.out.println("目标资源执行了");
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("name","itcast");
        modelAndView.setViewName("one");//跳转到one.jsp页面
        return modelAndView;
    }
```

创建拦截器类实现Handlerlnterceptor接口
返回**true代表放行**    返回**false代表不放行**

```java
public class MyInterceptor implements HandlerInterceptor {
    //在目标方法执行之前执行
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        System.out.println("preHandle");
        String param = request.getParameter("param");
        //测试路径   http://localhost:8770/springmvc/user/quick23?param=yese
        if ("yes".equals(param))  return true;
        else {           //注意，  /  代表资源在webapp下
            request.getRequestDispatcher("/error.jsp").forward(request,response);
            return false;
        }
    }
    //在目标方法执行之后视图对象返回之前执行
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        System.out.println("postHandle");
    }

  //该方法将在整个请求结束之后
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        System.out.println("afterCompletion");
    }
}
```

**配置拦截器**

```xml
 /**的意思是所有文件夹及里面的子文件夹 
 /*是所有文件夹，不含子文件夹 
 /是web项目的根目录
 
 <!--配置拦截器, 多个拦截器,顺序执行 -->
 
 
   <!--配置拦截器-->
  <mvc:interceptors>
      <mvc:interceptor>
          <!-- 哪些进行拦截 -->
          <mvc:mapping path="/**"/>
          <!-- 哪些不进行拦截 -->
<!--          <mvc:exclude-mapping path="/userController/login"/>-->
          <!-- 注册拦截器对象 -->
          <bean class="Dao.MyInterceptor"></bean>
      </mvc:interceptor>
  </mvc:interceptors>
  
  
  <!-- 当设置多个拦截器时，先按顺序调用preHandle方法，然后逆序调用每个拦截器的postHandle和afterCompletion方法 -->
```

测试：
http://localhost:8770/springmvc/user/quick23?param=yes
结果：
preHandle
目标资源执行了
postHandle
afterCompletion
并跳转到指定页面

测试：
http://localhost:8770/springmvc/user/quick23?param=yesee
跳转到error.jsp页面，不放行

![1604560195079](Spring MVC.assets/1604560195079.png)





# 异常处理

![1604564710091](Spring MVC.assets/1604564710091.png)



用传统的try catch等耦合度太高，而且每个可能的异常都要写一遍，增加了代码量。
在springmvc中使用统一的异常管理，进行全局的异常控制



**1.2异常处理常用3种方式**
1、使用Spring MVC提供的简单**异常处理器SimpleMappingExceptionResolver**
2、实现Spring的异常处理**接口HandlerExceptionResolver**自定义自己的异常处理器
3、还有  局部处理 使用@ExceptionHandler注释  ：使用该注解有一个不好的地方就是：进行异常处理的方法必须与出错的方法在同一个Controller里面，我们这里不用

**使用SimpleMappingExceptionResolver：**
在springmvc.xml配置文件中

```xml
    <!--配置简单的映射异常处理器-->
    <bean class="org.springframework.web.servlet.handler.SimpleMappingExceptionResolver">
    <!--默认错误视图,当下面的都不匹配的时候执行这个-->
        <property name="defaultErrorView" value="error"/>  
        <property name="exceptionMappings">
          <map>
                 <!--这里可以映射异常，将需要的映射过来就可以了-->
                 <!--如：这个是类型转换异常，跳转到的error.jsp页面-->
            <entry key="java.lang.ClassCastException" value="error"></entry>
             <entry key="java.lang.ArrayIndexOutOfBoundsException" value="error"></entry>
          </map>
      <!--也可以不用map标签，用props标签-->
           <!-- <props>
                <prop key="java.lang.ArrayIndexOutOfBoundsException">error</prop>
            </props>-->
        </property>
    </bean>
```

测试：

```java
    @RequestMapping(value = "/quick25")
    public String save25(int i){
      //数组越界异常
        String [] arr=new String[10];
        System.out.println(arr[i]);
        return "one";
    }
    
    @RequestMapping(value = "/quick24")
    @ResponseBody
    public void save24(){
        System.out.println("抛出类型转换异常");
        Object s = "sdf";
        Integer num = (Integer)s;
    }
http://localhost:8770/springmvc/user/quick24  触发异常，跳转到error页面
http://localhost:8770/springmvc/user/quick25?i=12 数组越界异常
```



**异常处理接口HandlerExceptionResolver**

自定义异常处理步骤：
创建异常处理器类实现HandlerExceptionResolver
配置异常处理器
测试异常跳转

 MyExceptionResolver类：

```java
public class MyExceptionResolver implements HandlerExceptionResolver {

    @Override
    public ModelAndView resolveException(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
        ModelAndView modelAndView = new ModelAndView();
        if (e instanceof MyException){
            modelAndView.addObject("info","自定义异常");
        }
        else if (e instanceof ClassCastException){
            modelAndView.addObject("info","类转换异常");
        }
        modelAndView.setViewName("error");
        return modelAndView;
    }
}
//参数Exception:异常对象
//返回值ModelAndView:跳转到错误视图信息
```

```java
//自定义异常类：
public class MyException extends Exception {}
```

在springmvc.xml配置

```xml
<!---自定义异常处理器-->
<bean class="Dao.MyExceptionResolver"></bean>
```



# SpringMVC常用注解：

https://blog.csdn.net/weixin_40753536/article/details/81285046

@Controller ：用于定义控制器类，在spring项目中由控制器负责将用户发来的URL请求转发到对应的服务接口（service层），一般这个注解在类中，通常方法需要配合注解@RequestMapping。

@RequestMapping：提供路由信息，负责URL到Controller中的具体函数的映射。
如：@RequestMapping(value = "/quick25")   http://localhost:8770/springmvc/quick25   springmvc是服务器名

@requestParam  

@ResponseBody：告诉页面不进行页面跳转

@RequestBody

@RequestHeader

@CookieValue

@ModelAttribute  该方法会先执行，可以进行密码验证等

@SessionAttributes  使得模型中的数据存储一份到session域中

等..........





# 其它

**SpringMVC中JSP页面不显示EL表达式的原因：**
https://blog.csdn.net/renfufei/article/details/54599835
原因是**web.xml**使用了 **老旧的JSP 1.2描述方式**

解决方法一：**手动开启（推荐）**：

```html
<head>
<%@ page isELIgnored="false" %>
</head>
```

解决方法二：使用JSP 2.0 或 更新的 Servlet 3.1 规范  定义格式

```xml
<web-app id="WebApp_ID" version="2.4"
..........
</web-app>
或
<web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee"
   .........
     version="3.1">
.......
</web-app>

```





**严重: Unable to process Jar entry ..........from Jar.......Jar包...for annotations**
org.apache.tomcat.util.bcel.classfile.ClassFormatException: Invalid byte tag in constant pool: 19
..................................

**解决方案：换用tomcat高版本或者降低jar的版本。最好在maven依赖中降低jar包的版本**















