

## 添加依赖为阿里云镜像

在SpringBoot 项目的 Pom.xml 文件，在里面添加下列代码（更改镜像为阿里云）

```xml
<repositories>
        <repository>
            <id>aliyun-repos</id>
            <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
            <snapshots>
                <enabled>false</enabled>
            </snapshots>
        </repository>
</repositories>
    <pluginRepositories>
        <pluginRepository>
            <id>aliyun-plugin</id>
            <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
            <snapshots>
                <enabled>false</enabled>
            </snapshots>
        </pluginRepository>
    </pluginRepositories>
```

## pom.xml其它依赖

```xml

<!-- 父依赖 -->
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>2.2.5.RELEASE</version>
    <relativePath/>
</parent>

<dependencies>
    <!-- web场景启动器 -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <!-- springboot单元测试 -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
        <!-- 剔除依赖 -->
        <exclusions>
            <exclusion>
                <groupId>org.junit.vintage</groupId>
                <artifactId>junit-vintage-engine</artifactId>
            </exclusion>
        </exclusions>
    </dependency>
</dependencies>

<build>
    <plugins>
        <!-- 打包插件 -->
        <plugin>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-maven-plugin</artifactId>
             <!--跳过项目运行测试用例  看自己需要添加-->
        <skipTests>true</skipTests>
        </plugin>
    </plugins>
</build>
```



## Spring Boot HelloWorld

一个功能：

浏览器发送hello请求，服务器接受请求并处理，响应Hello World字符串；



1、创建一个maven工程；（jar）

2、导入spring boot相关的依赖，在pom.xml文件中  可以在创建的时候默认导入

```xml
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>1.5.9.RELEASE</version>
    </parent>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
    </dependencies>
```

3、编写一个主程序；启动Spring Boot应用

```java
/**
 *  @SpringBootApplication 来标注一个主程序类，说明这是一个Spring Boot应用
 */
@SpringBootApplication
public class HelloWorldMainApplication {

    public static void main(String[] args) {

        // Spring应用启动起来
        SpringApplication.run(HelloWorldMainApplication.class,args);
    }
}
```

4、编写相关的Controller、Service

```java
@Controller
public class HelloController {

    @ResponseBody
    @RequestMapping("/hello")
    public String hello(){
        return "Hello World!";
    }
}

```

**==4.5:注意，要将Controller、Service等的包放在和启动类一个包下==**

然后测试







## 扩展SpringMVC

注意：重定向到templates包下的资源要经过视图解析器处理，==而重定向默认是不会经过视图解析器的==，所以我们要先编写一个视图映射。

可使用 继承 WebMvcConfigurationSupport 类和实现 WebMvcConfigurer接口 两种方法。推荐后一种

编写视图映射：

```java
@Configuration
public  class MyMvcConfig implements WebMvcConfigurer{
@Override
public void addViewControllers(ViewControllerRegistry registry) {
registry.addViewController("/main.html").setViewName("dashboard");
    //重定向可以直接设置这个，不用设置setViewName   和modeview.setViewName类似
    // 重定向返回   return "redirect:/own/album.html";
    registry.addViewController("/own/album.html");
        //重定向就要像这样自己配置才能生效
        
         /* 同时因为springboot 2.0后静态资源也经过拦截器，如果资源页面在templates的一个子包下，可能会出现 No mapping for GET的问题，这时可以配置，如：    */
    registry.addViewController("/own/personInfo.html");
       /* 就可以是用超链接来访问页面了，不配置就会出现 No mapping for GET的问题  参考下图
        */

}}
```



## ==springboot配置静态资源访问路径==

SpringBoot中的五种对静态资源的映射规则:
https://www.cnblogs.com/yichunguo/archive/2004/01/13/12115550.html

第一种：在配置文件中进行配置

```xml
#静态资源访问路径
spring.mvc.static-path-pattern=/**
#静态资源映射路径
spring.resources.static-locations=classpath:/
```

 第二种：通过编程进行设置 

```java
@Configuration
public class WebMvcConfig extends WebMvcConfigurerAdapter {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {         
    	registry.addResourceHandler("/**").addResourceLocations("file:F:/AppFiles/");
        registry.addResourceHandler("/setUp/**").addResourceLocations("file:D:/setUp/");
        //访问  /setUp/**  就是默认访问  D:/setUp/  下的资源    
    }
}

```

## 



## **ajax传输json和后台获取**

```js
//这里用到了layui的传输方式
layui.use('form', function(){
        var form = layui.form;

        //监听提交,使用ajax提交
        form.on('submit(formDemo)', function(data){
            layer.msg(JSON.stringify(data.field));
            alert(JSON.stringify(data.field));
            $.ajax({
                type:"post",
                dataType:"JSON",
                url:"/user/updatePersonDate",
                data:JSON.stringify(data.field),
                success:function (result) {
                   console.log(result);
                },
                error:function () {
                  alert("异常！")
                },
                contentType:"application/json;charsetset=UTF-8"
            });

            return false;
        });
    });

//普通传输的方式
function submitForm() {
    $.ajax({
      type: 'post',
      url: '',
      contentType: 'application/json',
      dataType: 'json',
      data: JSON.stringify(getFormData($form1)),
      //或  data: JSON.stringify(getFormData($("#form1"))),//表单数据
      success: function (result) {
        //正确处理
      },
      error: function () {
        //错误处理
      }
    });
  }

//在用ajax提交表单数据时，我们常需要将form表单数据转为JSON格式，这样后端控制器可以方便的将JSON字符串转为Bean形式。在此提供一小段代码1，让你快速的将form表单数据转为JSON格式。
function getFormData($form) {
    var unindexed_array = $form.serializeArray();
    var indexed_array = {};

    $.map(unindexed_array, function (n, i) {
      indexed_array[n['name']] = n['value'];
    });

    return indexed_array;
}


```

==后台==

```xml
 <!--导入json解析包,终极完整版不需要-->
        <dependency>
            <groupId>com.google.code.gson</groupId>
            <artifactId>gson</artifactId>
            <version>2.8.6</version>
        </dependency>
```



```java
//测试获取json字符串版  获取json直接在方法的参数里添加String类型的参数就可以自动获取了
//修改个人信息，同时更改session里的信息
    @RequestMapping("/updatePersonDate")
    public String updatePersonDate(HttpServletRequest req, HttpServletResponse resp, @RequestBody String obj){
        //@RequestBody 是 获取前端的json数据
        //这步是将json的数据顺序按我们的表单来输出
        JsonObject asJsonObject = new JsonParser().parse(obj).getAsJsonObject();
        String data = asJsonObject.toString();
        System.out.println(data);
        return null;
    }


//相对完整版
 //修改个人信息，同时更改session里的信息
    @RequestMapping("/updatePersonDate")
    @ResponseBody
    public String updatePersonDate(HttpServletRequest req, HttpSession session, @RequestBody String obj){
        JsonObject asJsonObject = new JsonParser().parse(obj).getAsJsonObject();
        String data = asJsonObject.toString();
        //System.out.println(data);
        Gson gson = new Gson();
        User user = gson.fromJson(data,User.class);
       // System.out.println("User是："+user);
        userService.updateUser(user);

        User user1 = (User)session.getAttribute("user");
        user1.setEmail(user.getEmail());
        user1.setBirthday(user.getBirthday());
        user1.setSex(user.getSex());
        user1.setAddress(user.getAddress());
        user1.setAutograph(user.getAutograph());

        session.setAttribute("user",user1);

        //System.out.println(user1);

        return "success";
    }


//终极完整版，直接在传输的时候就封装为对象 后端的Controller可以采用@RequestBody来接收JSON字符串，并自动转为对应的Bean。
    @RequestMapping("/updatePersonDate")
    @ResponseBody
    public String updatePersonDate(HttpServletRequest req, HttpSession session, @RequestBody User user){
      /*  JsonObject asJsonObject = new JsonParser().parse(obj).getAsJsonObject();
        String data = asJsonObject.toString();
        //System.out.println(data);
        Gson gson = new Gson();
        User user = gson.fromJson(data,User.class);*/

        System.out.println("User是："+user);
        userService.updateUser(user);
       //更新session中的user
        User user1 = (User)session.getAttribute("user");
        user1.setEmail(user.getEmail());
        user1.setBirthday(user.getBirthday());
        user1.setSex(user.getSex());
        user1.setAddress(user.getAddress());
        user1.setAutograph(user.getAutograph());

        session.setAttribute("user",user1);

        System.out.println(user1);

        return "success";
    }

```



## Thymeleaf使用

1、引入thymeleaf；

```xml
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-thymeleaf</artifactId>
         <!-- 默认是 2.1.6 版本-->
		</dependency>

<!--设置thymeleaf版本，可以不用写   版本不对可能无法return跳转,我这里改了版本-->
<properties>
		<thymeleaf.version>3.0.11.RELEASE</thymeleaf.version>
		<!-- 布局功能的支持程序  thymeleaf3主程序  layout2以上版本 -->
		<!-- thymeleaf2   layout1-->
		<thymeleaf-layout-dialect.version>2.1.1</thymeleaf-layout-dialect.version>
  </properties>
```

**最好在配置文件设置thymeleaf属性（当然也可以不设置，默认已经自动设置了一部分了）**

```xml
spring.thymeleaf.cache=false
spring.thymeleaf.prefix=classpath:/templates/   
spring.thymeleaf.suffix=.html
spring.thymeleaf.encoding=UTF-8
spring.thymeleaf.content-type=text/html
spring.thymeleaf.mode=HTML5
```

**测试：**
**在resources/templates新建success.html文件（略）**
**编写controller**

```java
@Controller
public class Hello {
    @RequestMapping("/succe")
    public String success(){
        System.out.println("dfdsdf");
        return "success";
    }
}
```



==2、Thymeleaf使用==

源码解释：

```java
@ConfigurationProperties(prefix = "spring.thymeleaf")
public class ThymeleafProperties {

	private static final Charset DEFAULT_ENCODING = Charset.forName("UTF-8");

	private static final MimeType DEFAULT_CONTENT_TYPE = MimeType.valueOf("text/html");

	public static final String DEFAULT_PREFIX = "classpath:/templates/";

	public static final String DEFAULT_SUFFIX = ".html";
  	//
```

只要我们把HTML页面放在classpath:/templates/，thymeleaf就能自动渲染；

==使用：==

1、导入thymeleaf的名称空间

```xml
<html lang="en" xmlns:th="http://www.thymeleaf.org">
```

2、使用thymeleaf语法；这个默认已经自动配置了的mvc规则，但你也可以扩展springmvc    
      thymeleaf语法默认支持转发，不支持重定向

```java
 @RequestMapping("/succe")
    public String success(Map<String,Object> map){
        map.put("k1","<h1>你好</h1>");
        map.put("users", Arrays.asList("张三","李四","王五"));
        return "success";//默认是转发   如果要用重定向，需要自己配置mvc
    }
```

```properties
#清空缓存
spring.thymeleaf.cache=false
```

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <h1>成功！</h1>
    <!--th:text 将div里面的文本内容设置为 -->
    <div th:text="${k1}">这是显示欢迎信息</div>    <!--k1不存在则显示div里的内容 --> 
    
    <div id="div01" class="myDiv" th:id="${k1}" th:class="${k1}" th:text="${k1}">欢迎信息</div>
<hr>
<!--utext是不转义-->
<div th:text="${k1}"></div>
<div th:utext="${k1}"></div>
<hr>

<h4 th:text="${user}" th:each="user:${users}"></h4>
<hr>
<h4>
    <span th:each="user:${users}"> [[${user}]]</span>
</h4>
</body>
</html>
```

==3、语法规则==

==参考==：https://www.cnblogs.com/itdragon/archive/2018/04/13/8724291.html



# 五、SpringBoot与整合其他技术

## ==5.1 SpringBoot整合Mybatis==

5.1.1 添加Mybatis的起步依赖

```xml
<!--mybatis起步依赖-->
<dependency>
    <groupId>org.mybatis.spring.boot</groupId>
    <artifactId>mybatis-spring-boot-starter</artifactId>
    <version>2.1.0</version>
</dependency>
```

5.1.2 添加数据库驱动坐标

```xml
<!-- MySQL连接驱动 -->
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
</dependency>
<!-- 德鲁伊连接池-->
<dependency>
       <groupId>com.alibaba</groupId>
       <artifactId>druid</artifactId>
       <version>1.1.12</version>
</dependency>
```

5.1.3 添加数据库连接信息

在application.properties中添加数据量的连接信息

```properties
#DB Configuration:
spring.datasource.driverClassName=com.mysql.jdbc.Driver
spring.datasource.url=jdbc:mysql://127.0.0.1:3306/test?&useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8
spring.datasource.username=root
spring.datasource.password=182008
#........
```

==或application.yml,用这个==

```yml
spring:
  datasource:
    username: root
    password: 182008
    url: jdbc:mysql://127.0.0.1:3306/test?&useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8
    driver-class-name: com.mysql.jdbc.Driver
    type: com.alibaba.druid.pool.DruidDataSource

    initia1size: 5
    minId1e: 5
    maxActive: 20
    maxwait: 6000
    timeBetweenEvictionRunsMi11is: 6000
    minEvictableIdleTimeMi1lis: 30000
    validationQuery: SELECT 1 FROM DUAL
    testWhileId1e: true
    test0nBorrow: false
    testOnReturn: false
    poolPreparedStatements: true
    #配置监控统计拦截的filters，去掉后监控界面sqL无法统计， 'wall '用于防火墙
    filters: stat,wal1, log4j
    maxPoo1PreparedStatementPerConnectionSize: 20
    useGloba1DataSourceStat: true
    connectionProperties: druid.stat.mergeSql=true;druid.stat.slowSqlNillis=500
#schema :
#- classpath: department.sql
```



5.1.4 创建user表

在test数据库中创建user表

```sql
-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'zhangsan', '123', '张三');
INSERT INTO `user` VALUES ('2', 'lisi', '123', '李四');
```

5.1.5 创建实体Bean

```java
public class User {
    // 主键
    private Long id;
    // 用户名
    private String username;
    // 密码
    private String password;
    // 姓名
    private String name;
  
    //此处省略getter和setter方法 .. ..
    
}
```

5.1.6 编写Mapper,即一个接口

```java
@Repository
@Mapper  
public interface UserMapper {
	public List<User> queryUserList();
    public User queryUserByName(String username);
}
```

注意：==@Mapper标记该类是一个mybatis的mapper接口，可以被spring boot自动扫描到spring上下文中，默认使用  接口代理方式，即接口命名等要和mapper映射文件要一 一对应==

5.1.7 配置Mapper映射文件

在src\main\resources\mapper路径下加入UserMapper.xml配置文件"

```xml
<?xml version="1.0" encoding="utf-8" ?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd" >
<mapper namespace="com.itheima.mapper.UserMapper">
    <select id="queryUserList" resultType="user">
        select * from user
    </select>
    <select id="queryUserByName" parameterType="String" resultType="User">
       select * from user where username=#{username}
   </select>
</mapper>
```

5.1.8 在application.properties中添加mybatis的信息

```properties
#spring集成Mybatis环境
#pojo别名扫描包  pojo下是各个javabean,如User,Admin
mybatis.type-aliases-package=com.itheima.pojo
#加载Mybatis映射文件  *Mapper.xml是  带Mapper结尾的xml文件
mybatis.mapper-locations=classpath:mapper/*Mapper.xml    
```

5.1.9 编写测试Controller

```java
@Controller
public class MapperController {

    @Autowired
    private UserMapper userMapper;

    @RequestMapping("/queryUser")
    @ResponseBody
    public List<User> queryUser(){
        List<User> users = userMapper.queryUserList();
        return users;
    }

}
```

5.1.10 测试

![](SpringBoot.assets/14.png)

## 







































