# Mybatis

**解决数据的持久化问题的框架**

MyBatis是一款优秀的持久层框架，它支持定制化 SQL、存储过程以及高级映射。MyBatis避免了几乎所有的JDBC代码和手动设置参数以及获取结果集。MyBats可以使用简单的XML或注解来配置和映射原生信息，将接口和Java的POJOs(Plain old Java objects,普通的Java对象)映射成数据库中的记录。

# Mybatis快速入门

maven项目

在pom.xml添加

```xml
   <dependency>
      <groupId>org.mybatis</groupId>
      <artifactId>mybatis</artifactId>
      <version>3.4.5</version>
    </dependency>
```

User类

```java
public class User {
   private int id;
   private String name;
   private int age;
   ..............
```



映射文件：UserMapper.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<!--上面的是映射文件头,必须要有的-->        
        
<mapper namespace="userMapper">
    <!-- 配置查询所有操作 -->
    <select id="findAll" resultType="Dao.User">
        select *from user
    </select>
</mapper>
```

核心配置文件：SqlMapConfig.xml

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<!--核心约束头，必须要有的-->
        
<configuration>

<!--数据源环境,default和id看自己的命名-->
    <environments default="development">
        <environment id="development">
            <!-- 配置事务的类型 -->
            <transactionManager type="JDBC"></transactionManager>
            <!-- 配置连接数据库的信息：用的是数据源(连接池) -->
            <dataSource type="POOLED">
                <property name="driver" value="com.mysql.jdbc.Driver"/>
                <property name="url" value="jdbc:mysql://127.0.0.1:3306/test?&amp;useSSL=false&amp;serverTimezone=UTC&amp;characterEncoding=UTF-8"/>
                <property name="username" value="root"/>
                <property name="password" value="182008"/>
            </dataSource>
        </environment>
    </environments>
    <!-- 告知 mybatis 映射配置的位置,我这里是在同一个包下 -->
    <mappers>
        <mapper resource="UserMapper.xml"></mapper>
    </mappers>

</configuration>
```

测试类：

```java
 public static void main(String[] args) throws IOException {
         //获得核心配置文件
        InputStream resourceAsStream = Resources.getResourceAsStream("SqlMapConfig.xml");
        //获得session工厂对象
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
        //获得session回话对象
        SqlSession sqlSession = sqlSessionFactory.openSession();
        

        //执行操作  参数：   namepace+id
        List<User> userList = sqlSession.selectList("userMapper.findAll");
        System.out.println(userList);
        
        //如果是增删改 操作，还要手动提交事务,数据才会改变
        // sqlSession.commit();
           
        //释放资源
        sqlSession.close();
    }
```



# ==映射文件==

可以有多个（如：UserMapping(接口) 就有一个配置文件UserMapping.xml    一个接口一个配置文件？大概）

头部：

```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<!--上面的是映射文件头-->     
```

参数为：  #{属性名}   方式引用实体中的属性名



<img src="Mybatis.assets/1604910957703.png" alt="1604910957703" style="zoom: 67%;" />

![1604891878047](Mybatis.assets/1604891878047.png)



# ==核心配置文件==

![1604892302373](Mybatis.assets/1604892302373.png)



头部：

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<!--核心约束头-->
```

**1、environments标签**

![1604892632157](Mybatis.assets/1604892632157.png)

<img src="Mybatis.assets/1604892527660.png" alt="1604892527660"  />

## **2、mappers标签**

```xml
  <mappers>
        <mapper resource="UserMapper.xml"></mapper>
        <!--或直接加载包  包下的文件都自动 映射-->
     <!--   <package name="包路径"/>     -->
    </mappers>
```

```xml
<!-- 加载其它映射文件 -->
<mappers>
    <!--
    子元素：mapper
        属性：
        resource：加载类路径下指定的配置文件，注：分隔符是/，而不是点号
        url: 读取指定路径下配置文件，或者网络的配置文件
        <mapper url="file:///d:/UserMapper.xml"/>
        class: 指定接口的完全限定名，用于注解的配置，不需要XML文件。
        <mapper class="com.itheima.dao.UserMapper"/>

    子元素：package
        1. 指定扫描哪个包下所有的DAO接口，如果使用这种写法，接口名与配置文件名字要相同。
        如：接口名UserMapper.java 配置文件名：UserMapper.xml
        2. 接口与配置文件必须放在同一个包下，或包名相同，如我下图的示例
    -->
    
    <package name="com.itheima.dao"/>

```

<img src="Mybatis.assets/1605093451977.png" alt="1605093451977" style="zoom:67%;" />

![1604892829272](Mybatis.assets/1604892829272.png)



**3、Properties标签**

![1604892898241](Mybatis.assets/1604892898241.png)



## **4、typeAliases标签**

![1604893072958](Mybatis.assets/1604893072958.png)

mybatis框架已经为我们设置好的一些常用的类型的别名：
string -----String      long-------Long      int--------Integer       double---------Double      boolean-----Boolean

```
<typeAliases>
     <!--包名   这是该包下的所有都自动定义  别名   别名是文件名或文件名开头小写-->
    <package name="Doa"/>
</typeAliases>
```

## **总结：**

![1605093671682](Mybatis.assets/1605093671682.png)





# 相应的API

SqlSessionFactoryBuider:

![1604902236397](Mybatis.assets/1604902236397.png)

SqlSessionFactory:

![1604902308220](Mybatis.assets/1604902308220.png)

SqlSession:

![1604902860026](Mybatis.assets/1604902860026.png)

映射文件中：

```
   <select id="findAll" resultType="Dao.User" parameterType="int">
        select *from user where id = #{id}
    </select>
```



# ==Dao层实现（主要）==

传统方式：略

**接口代理方式（主要方式）：**

![1604903696423](Mybatis.assets/1604903696423.png)

![1604904835532](Mybatis.assets/1604904835532.png)

**例子：**

UserMapper接口：

```java
public interface UserMapper {
    public List<User> findAll();
    public User findById(int id);
    public List<User> findByCondition(User user);
    public List<User> findByIds(List<Integer> ids);
    //其它方法等.......
}
```

映射文件：

```xml
<mapper namespace="Dao.UserMapper">
    <!-- 查询操作 ,虽然要返回的是list，但主要还是看的集合里的类型-->
    <select id="findAll" resultType="Dao.User">
        select *from user
    </select>
    <!-- 根据id查询 -->
    <select id="findById" resultType="Dao.User" parameterType="int">
        select *from user where id = #{id}
    </select>
   ................
</mapper>
```

测试：

```java
 public static void main(String[] args) throws IOException {
        InputStream resourceAsStream = Resources.getResourceAsStream("SqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        
        //主要的部分
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        List<User> all = mapper.findAll();
        System.out.println(all);
           
        //释放资源
        sqlSession.close();
    }
```



# 映射文件深入(动态sql语句)

## **if语句(动态添加条件,主要)**

```xml
<select id="findByCondition" resultType="Dao.User" parameterType="Dao.User">
    select *from user where id=#{id} and name=#{name} and age=#{age}
</select>

这种过于复杂，每个条件都缺一不可，可以用if解决
```

```xml
<select id="findByCondition" resultType="Dao.User" parameterType="Dao.User">
        select *from user
        <where>
            <if test="id!=0">
              and id=#{id}
            </if>
            <if test="name!=null">
              and name = #{name}
            </if>
            <if test="age!=0">
                and age = #{age}
            </if>
        </where>
    </select>
```

测试：

```
        User user = new User();
        user.setName("陈策");

        List<User> users = mapper.findByCondition(user);
        System.out.println(users);

```



## **foreach语句(用的少)**

```xml
<select id="findByIds" resultType="Dao.User" parameterType="list">
    select *from user where id in(1,2,3);
</select>
这种是静态的
```

```xml
    <select id="findByIds" resultType="Dao.User" parameterType="list">
        select *from user
        <where>
            <foreach collection="list" open="id in(" close=")" item="id" separator=",">
                #{id}
            </foreach>
        </where>
    </select>
```

测试：

```java
   List<Integer> list = new ArrayList<Integer>();
        list.add(12);
        list.add(16);

        List<User> list1 = mapper.findByIds(list);
        System.out.println(list1);
```

## sql片段抽取

```xml
  用sql标签抽取，include标签引入
  
  <sql id="selectUser">select *from user</sql>
    
    <!-- 查询操作 -->
    <select id="findAll" resultType="Dao.User">
         <!--select *from user不用这种  用include引入的方式-->
       <include refid="selectUser"></include>
    </select>
```





# 核心配置文件深入

## **plugins标签：分页**

MyBatis可以使用第三方的插件来对功能进行扩展，分页助手PageHelper是将分页的复杂操作进行封装，使用简单的方式即可获得分页的相关数据
开发步骤:
1、导入通用PageHelper的坐标
2、在mybatis核心配置文件中配置PageHelper插件
3、测试分页数据获取

```
 <!-- https://mvnrepository.com/artifact/com.github.pagehelper/pagehelper -->
    <dependency>
      <groupId>com.github.pagehelper</groupId>
      <artifactId>pagehelper</artifactId>
      <version>5.1.10</version>
    </dependency>
```

```xml
  <!--配置分页助手插件,高版本会自动识别，不用加dialect：方言(这是低版本的配置)-->
  
   <！--高版本的配置-->
   <plugins>
       <plugin interceptor="com.github.pagehelper.PageInterceptor">
       </plugin>
   </plugins>
  
  <！--低版本的配置，不要用了-->
  <plugins>
   <plugin interceptor="com.github.pagehelper.PageHelper">
          <!-- <property name="dialect" value="mysql"/>-->
   </plugin>
  </plugins>
```

测试：

```java
   ..............
   //设置分页相关参数   当前页+每页显示的条数
        PageHelper.startPage(2,3);

        List<User> userList = mapper.findAll();
        for (User user:userList){
            System.out.println(user);
        }
        //获得与分页相关的参数
        PageInfo<User> pageInfo = new PageInfo<User>(userList);
        System.out.println("当前页： "+pageInfo.getPageNum());
        System.out.println("每页显示的条数： "+pageInfo.getPageSize());
        System.out.println("总条数： "+pageInfo.getTotal());
        System.out.println("上一页： "+pageInfo.getPrePage());
        System.out.println("下一页： "+pageInfo.getNextPage());
        System.out.println("是否是第一个： "+pageInfo.isIsFirstPage());
        System.out.println("是否是最后一个： "+pageInfo.isIsLastPage());
    ........
```







typeHandlers标签（用的少）

![1604912765980](Mybatis.assets/1604912765980.png)





# 多表操作(xml方式)

一对一配置:使用<resultMap>做配置
一对多配置:使用<resultMap>+<collection>做配置
多对多配置:使用<resultMap>+<collection>做配置



## **一对一的配置实例：**

![1604978600495](Mybatis.assets/1604978600495.png)

建立 orders 和user的实体类（参数与表对应），和相应的接口（每个接口配置映射文件） 

然后在核心配置文件配置别名和映射

```
  <typeAliases>

        <typeAlias type="Mybatis.Order" alias="order"></typeAlias>
        <typeAlias type="Mybatis.OrderMapper" alias="orderMap"></typeAlias>
    </typeAliases>
    
      <!-- 告知 mybatis 映射配置的位置 -->
    <mappers>
        <mapper resource="UserMapper.xml"></mapper>
        <mapper resource="OrderMapper.xml"></mapper>
    </mappers>
```

OrderMapper.xml：

```
...................
<mapper namespace="Mybatis.OrderMapper">

    <resultMap id="orderMap" type="order">
     <!--   手动指定字段与实体属性的映射关系
        colunmn:数据表的字段名称
        property:实体的属性名称-->
      <id column="oid" property="id"></id>
      <result column="total" property="total"></result>
       <!-- 方法一-->
 <!--       <result column="uid" property="user.id"></result>
        <result column="name" property="user.name"></result>
        <result column="age" property="user.age"></result>-->

      <!-- 方法二：
        property:当前实体(order)中的属性名称(private User user)
        javaType:当前实体(order)中的属性的类型(User)-->
      <association property="user" javaType="Dao.User">
        <id column="uid" property="id"></id>
          <id column="name" property="name"></id>
          <id column="age" property="age"></id>
      </association>
    </resultMap>

<select id="findAll" resultMap="orderMap">
 select *,o.id oid from orders o,user u where o.uid = u.id
</select>
```

测试：

```
...................
        OrderMapper mapper = sqlSession.getMapper(OrderMapper.class);
        List<Order> userList = mapper.findAll();
        for (Order user:userList){
            System.out.println(user);
        }
..............
```



## **一对多的配置实现：**

<img src="Mybatis.assets/1604979891091.png" alt="1604979891091" style="zoom:67%;" />



<img src="Mybatis.assets/1604980128610.png" alt="1604980128610" style="zoom: 67%;" />

<img src="Mybatis.assets/1604980156605.png" alt="1604980156605" style="zoom: 80%;" />



## **多对多配置实现**

**和一对多差不多，只是存在了一张中间表**

<img src="Mybatis.assets/1604989084956.png" alt="1604989084956" style="zoom:80%;" />



![1604990247672](Mybatis.assets/1604990247672.png)



![1604990040570](Mybatis.assets/1604990040570.png)



# 注解开发

@Insert:实现新增
@Update:实现更新
@Delete:实现删除
@Select:实现查询
@Result:实现结果集封装
@Results:可以与@Result一起使用，封装多个结果集
@One:实现一对一结果集封装
@Many:实现一对多结果集封装
等........................

**数据和表结构参照上面的xml配置方式的**

## **简单查询：**

1、接口添加方法
2、核心配置文件加载映射关系
3、测试

![1604991414628](Mybatis.assets/1604991414628.png)

![1604992165415](Mybatis.assets/1604992165415.png)

## **复杂映射开发**

![1604992357100](Mybatis.assets/1604992357100.png)

![1604992375313](Mybatis.assets/1604992375313.png)

### 一对一查询

实例
注解方式一：两个表一起查
![1604992854833](Mybatis.assets/1604992854833.png)

注解方式二：相当于根据一个表的某个字段去查找另一个表的数据

![1604993345610](Mybatis.assets/1604993345610.png)



### 一对多查询

**UserMapper**
![1604996111417](Mybatis.assets/1604996111417.png)

**OrderMapper:**

![1604996159910](Mybatis.assets/1604996159910.png)

### 多对多查询

![1604996984634](Mybatis.assets/1604996984634.png)

UserMapper:

![1604997038159](Mybatis.assets/1604997038159.png)



# 缓存

http://www.kuangstudy.com/bbs/1337710857777336322#

# 其它

暂无







# ssm整合（重点来了）

<img src="Mybatis.assets/1605095919757.png" alt="1605095919757" style="zoom:67%;" />



**准备工作：**

数据库：

![1605095994144](Mybatis.assets/1605095994144.png)

User类 （建立和数据库对应的类）
UserMapper接口（为mybatis服务） 
UserService接口   **UserServiceImpl实现类**（为spring服务）
UserController类（为springmvc服务）

配置文件：mysqlconn.properties
spring配置文件：**applicationContext.xml**
springmvc配置文件：spring-mvc.xml
mybatis核心配置文件：**SqIMapConfig.xml**      映射配置文件：UserMapper.xml
展示全部数据：userList.jsp
添加user：save.jsp



User类

```
public class User {
   private int id;
   private String name;
   private int age;
  .................
```

UserMapper接口

```
public interface UserMapper {
    public List<User> findAll();
    public void save(User user);
    ............
```

UserService接口 

```
@Service
public interface UserService {
    public void save(User user);
    public List<User> findAll();
}
```

UserController类

```
@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;


   //保存
    @RequestMapping(value = "/save",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String save(User user){
        userService.save(user);
        return "保存成功";
    }

    //查询
    @RequestMapping(value = "/findAll")
    public ModelAndView findAll(){
        List<User> userList = userService.findAll();
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("userList",userList);
        modelAndView.setViewName("userList");
        return modelAndView;
    }
}
```

mysqlconn.properties：

```
driver=com.mysql.cj.jdbc.Driver
url=jdbc:mysql://127.0.0.1:3306/test?&useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8
user=root
password=182008
```

spring-mvc.xml

```
<!--加载注解-->
<context:component-scan base-package="controller"></context:component-scan>

<!--配置视图解析器-->
    <bean id="internalResourceViewResolver" class="org.springframework.web.servlet.view.InternalResourceViewResolver">
     <property name="prefix" value="/WEB-INF/pages/"></property>
     <property name="suffix" value=".jsp"></property>
    </bean>
<!--    mvc的注解驱动-->
    <mvc:annotation-driven/>
    
<!--开法资源的访问方式二-->
    <mvc:default-servlet-handler/>
```

UserMapper.xml

```
<mapper namespace="Mapper.UserMapper">    
    <sql id="selectUser">select *from user</sql>
    
    <!-- 查询操作 -->
    <select id="findAll" resultType="Dao.User">
       <include refid="selectUser"></include>
    </select>
    <!--插入操作-->
    <insert id="save" parameterType="user">
        insert into user values (#{id},#{name},#{age})
    </insert>
</mapper>
```



userList.jsp

```
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ page isELIgnored="false" %>

<html>
<head>
    <title>展示user信息</title>
</head>
<body>

<h1>展示user信息</h1>
<table>
    <tr>
        <td>id</td>
        <td>姓名</td>
        <td>年龄</td>
    </tr>
    <c:forEach items="${userList}" var="user">
        <tr>
            <td>${user.id}</td>
            <td>${user.name}</td>
            <td>${user.age}</td>
        </tr>
    </c:forEach>

</table>


</body>
</html>

```

save.jsp

```
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>添加用户</title>
</head>
<body>
<h1>添加用户</h1>
<form name="userForm" action="user/save" method="post">
    姓名：<input type="text" name="name"><br>
    年龄：<input type="text" name="age"><br>
    <input type="submit" value="提交">
</form>
</body>
</html>
```



## 剩余的有两个版本

**第二版和第一版的区别在于：第二版将SqlSesssionFactory工厂和Mybatis里的一些配置放到了spring配置文件中，集中了配置。**

 UserServiceImpl实现类（第一版）

```java
@Service("userService")
public class UserServiceImpl implements UserService {
    @Override
    public void save(User user) {
        try {
            InputStream resourceAsStream = Resources.getResourceAsStream("SqlMapConfig.xml");
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
            SqlSession sqlSession = sqlSessionFactory.openSession();
            UserMapper mapper = sqlSession.getMapper(UserMapper.class);

           mapper.save(user);
           sqlSession.commit();
            sqlSession.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public List<User> findAll() {
   try {
            InputStream resourceAsStream = Resources.getResourceAsStream("SqlMapConfig.xml");
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
            SqlSession sqlSession = sqlSessionFactory.openSession();
            UserMapper mapper = sqlSession.getMapper(UserMapper.class);

            List<User> userList = mapper.findAll();
            sqlSession.close();
            return userList;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
```

 UserServiceImpl实现类（第二版）

```java
@Service("userService")
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;
    
    @Override
    public void save(User user) {
        userMapper.save(user);
    }

    @Override
    public List<User> findAll() {
        return userMapper.findAll();
    }
}

```





SqIMapConfig.xml （第一版）

```java
<configuration>

    <properties resource="mysqlconn.properties"></properties>

    <typeAliases>
        <typeAlias type="Dao.User" alias="user"></typeAlias>
    </typeAliases>


<!--数据源环境-->
    <environments default="development">
        <environment id="development">
            <!-- 配置事务的类型 -->
            <transactionManager type="JDBC"></transactionManager>
            <!-- 配置连接数据库的信息：用的是数据源(连接池) -->
            <dataSource type="POOLED">
                <property name="driver" value="${driver}"/>
                <property name="url" value="${url}"/>
                <property name="username" value="${user}"/>
                <property name="password" value="${password}"/>
            </dataSource>
        </environment>
    </environments>
    <!-- 告知 mybatis 映射配置的位置 -->
    <mappers>
      <!--  <mapper resource="UserMapper.xml"></mapper>
        <mapper resource="OrderMapper.xml"></mapper>-->
        <package name="Mapper"/>
    </mappers>

</configuration>
```

SqIMapConfig.xml （第二版）

```java
<!--第二版只有别名-->
<configuration>
    <typeAliases>
        <typeAlias type="Dao.User" alias="user"></typeAlias>
    </typeAliases>
</configuration>
```



applicationContext.xml（第一版）

```xml
<context:component-scan base-package="Dao,Mybatis,controller,service"> </context:component-scan>

<aop:aspectj-autoproxy></aop:aspectj-autoproxy>

    <!--加载文件信息-->
    <context:property-placeholder location="classpath:mysqlconn.properties" />
</beans>
```

applicationContext.xml（第二版，将SqIMapConfig.xml 的配置和SqlSesssionFactory工厂放到了这里）

```xml

<context:component-scan base-package="Dao,Mybatis,controller,service"></context:component-scan>

<aop:aspectj-autoproxy></aop:aspectj-autoproxy>

    <!--加载文件信息-->
    <context:property-placeholder location="classpath:mysqlconn.properties" />

    <bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource">
        <property name="url" value="${url}" />
        <property name="username" value="${user}" />
        <property name="password" value="${password}" />
        <property name="driverClassName" value="${driver}" />
    </bean>

    <!--配置sessionFactor-->
    <bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
        <property name="dataSource" ref="dataSource"></property>
        <!--加载mybatis核心配置文件-->
        <property name="configLocation" value="classpath:SqlMapConfig.xml"></property>
    </bean>
    <!--mapper所在的包 为mapper创建实现类,然后将其放入spring容器中  和MyBatis核心配置文件中的mappers标签的page用法类似 -->
    <bean class="org.mybatis.spring.mapper.MapperScannerConfigurer">
        <property name="basePackage" value="Mapper"></property>
     </bean>

    <!--声明式事务控制-->
    <!--平台事务管理器-->
    <bean id="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
        <property name="dataSource" ref="dataSource"></property>
    </bean>
    <!--配置事务增强-->
    <tx:advice id="txAdvice">
       <tx:attributes>
           <tx:method name="*"/>
       </tx:attributes>
    </tx:advice>

    <!--事务的aop织入-->
    <aop:config>
        <aop:advisor advice-ref="txAdvice" pointcut="execution(* service.Impl.*.*(..))"></aop:advisor>
    </aop:config>
</beans>
```

