# 	Spring

课程内容介绍 ：
1、Spring 框架概述 
2、IOC 容器 
（1）IOC 底层原理 
（2）IOC 接口（BeanFactory） 
（3）IOC 操作 Bean 管理（基于 xml） 
（4）IOC 操作 Bean 管理（基于注解） 
3、Aop 
4、JdbcTemplate 
5、事务管理 
6、Spring5 新特性 

**详细见：Spring5框架课堂笔记**

【根据视频总结笔记】：
1、https://blog.csdn.net/weixin_45496190/article/details/107059038
2、https://blog.csdn.net/weixin_45496190/article/details/107067200
3、https://blog.csdn.net/weixin_45496190/article/details/107071204
4、https://blog.csdn.net/weixin_45496190/article/details/107082732
5、https://blog.csdn.net/weixin_45496190/article/details/107092107 

## 配置准备

配置：https://blog.csdn.net/jiahanghacker/article/details/88871207

建立resources资源目录，然后点击右键，依次选择New-->XML Configuration File-->Spring Config，创建**applicationContext.xml配置文件**(命名可以自己来)    

**maven项目下的配置：**在pom.xml文件下添加：

```xml
<dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-core</artifactId>
      <version>4.3.7.RELEASE</version>
    </dependency>

    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-beans</artifactId>
      <version>4.3.7.RELEASE</version>
    </dependency>

    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-context</artifactId>
      <version>4.3.7.RELEASE</version>
    </dependency>

    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-expression</artifactId>
      <version>4.3.7.RELEASE</version>
    </dependency>
  其他按需求添加
```

非maven下的配置：
下载spring   和   spring需要的jar包





## Spring 框架概述 

1、Spring 是轻量级的开源的 JavaEE 框架 

2、Spring可以解决企业应用开发的复杂性 

3、Spring 有两个核心部分：IOC 和 Aop 
（1）IOC：控制反转，把创建对象过程交给 Spring 进行管理 
（2）Aop：面向切面，不修改源代码进行功能增强 

4、Spring 特点 
（1）方便解耦，简化开发 
（2）Aop 编程支持 
（3）方便程序测试 
（4）方便和其他框架进行整合 
（5）方便进行事务操作 
（6）降低 API 开发难度 

spring实现了对象池，一些对象创建和使用完毕之后不会被销毁，放进对象池（某种集合）以备下次使用，下次再需要这个对象，不new，直接从池里出去来用。节省时间，节省cpu.

## IOC 容器 

1、什么是 IOC 
（1）控制反转，把对象创建和对象之间的调用过程，交给 Spring 进行管理 
（2）使用 IOC 目的：为了耦合度降低 
（3）做入门案例就是 IOC 实现 

2、IOC 底层原理 ：xml 解析、工厂模式、反射 



![1603682250230](Spring.assets/1603682250230.png)

 

### IOC（BeanFactory 接口） 

1、IOC 思想基于 IOC 容器完成，IOC 容器底层就是对象工厂 

2、Spring 提供 IOC 容器实现两种方式：（两个接口） 
（1）BeanFactory：IOC 容器基本实现，是 Spring 内部的使用接口，不提供开发人员进行使用 * 加载配置文件时候不会创建对象，在获取对象（使用）才去创建对象 
（2）ApplicationContext：BeanFactory 接口的子接口，提供更多更强大的功能，一般由开发人 员进行使用 * 加载配置文件时候就会把在配置文件对象进行创建 

<img src="Spring.assets/1603682645459.png" alt="1603682645459" style="zoom:67%;" />

### IOC 操作 Bean 管理

1、什么是 Bean 管理 :
Bean 管理指的是两个操作 
（1）Spring 创建对象 （2）Spirng 注入属性 

2、Bean 管理操作有两种方式 
（1）基于 xml 配置文件方式实现 
（2）基于注解方式实现 

#### 测试类(xml和注解通用)

```java
 public static void main(String[] args) {
         //1 加载 spring 配置文件
        ApplicationContext context=
                new ClassPathXmlApplicationContext("bean1.xml");
        //2 获取配置创建的对象    book是在  <bean>标签或注解  建立好的别名
        Book book = context.getBean("book",Book.class);
        //3.执行book对象的方法等
    }
```

#### 基于 xml

##### **基于 xml 方式创建对象** 

配置User对象创建
<bean id="user" class="类全路径"></bean>

```xml
<bean id="book" class="com.atguigu.spring5.collectiontype.Book" scope="prototype"><!--设置为多实例-->
        <property name="list" ref="bookList"></property>
</bean>
```

（1）在 spring 配置文件中，使用 **bean 标签**，标签里面添加对应属性，就可以实现对象创建 
（2）在 bean 标签有很多属性，介绍常用的属性 
              id 属性：唯一标识 ,别名
              class 属性：类全路径（包类路径） 也可以是外部引入的jar包下的
（3）创建对象时候，**默认也是执行无参数构造方法完成对象创建** 

##### ==基于 xml 方式注入属性== 

   **DI：依赖注入，就是注入属性**

```xml
<!--    1. 使用 set方法 注入属性,默认调用的无参构造方法-->
    <bean id="book" class="DaoUtil.Book">;
        <property name="bname" value="上下五千年"></property>
        <property name="bprice" value="100"></property>
    </bean>

<!--    2. 使用 有参数构造 注入属性-->
    <bean id="book" class="DaoUtil.Book">
        <constructor-arg name="bname" value="我的世界"></constructor-arg>
        <constructor-arg name="bprice" value="404"></constructor-arg>
    </bean>

   <!--3.p 名称空间注入（了解）-->
```

##### **xml 注入其他类型属性**

1、字面量 
（1）null 值
    <! -- null 值 -- > 
  <property name="address">     
    <null/>
   </property> 
（2）属性值包含特殊符号

```
  <! -- 属性值包含特殊符号     
1 把 <> 进行转义 &lt; &gt;     
2 把带特殊符号内容写到 CDATA -- >

<property name="address">     
<value><![CDATA[<<南京>>]]></value>
</property>
```

==2、注入属性-外部 bean==  

（1）创建两个类 service 类和 dao 类
（2）在 service 调用 dao 里面的方法
（3）在 spring 配置文件中进行配置

```java
public class UserService {
 //创建 UserDao 类型属性，生成 set 方法
 private UserDao userDao;
 public void setUserDao(UserDao userDao) {
 this.userDao = userDao;
 }
 public void add() {
 System.out.println("service add...............");
 userDao.update();
 }
}
```

```xml
<!--1 service 和 dao 对象创建-->
<bean id="userService" class="com.atguigu.spring5.service.UserService">
 <!--注入 userDao 对象
 name 属性：类里面属性名称
 ref 属性：创建 userDao 对象 bean 标签 id 值
 -->
 <property name="userDao" ref="userDaoImpl"></property>
</bean>
<bean id="userDaoImpl" class="com.atguigu.spring5.dao.UserDaoImpl"></bean>
```

3、注入属性-内部 bean  见pdf

4、注入属性-级联赋值  见pdf

5、xml 注入集合属性   见pdf

##### ==Bean管理,作用域( scope ),生命周期,继承等:见pdf==

作用域,生命周期,后置处理器,继承等见:
====https://www.w3cschool.cn/wkspring/pesy1icl.html====

====https://blog.csdn.net/weixin_45496190/article/details/107067200====

**基于xml的自动装配（一般不用，用注解自动装配）**：
见pdf

##### **名称空间注入**

在spring配置文件引入名称空间(如 util)

复制粘贴以前有的并改名   一般以util的为模板

![1603714092100](Spring.assets/1603714092100.png)



#### 基于注解

1、什么是注解 
（1）注解是代码特殊标记，格式：**@注解名称(属性名称=属性值, 属性名称=属性值..)** 
（2）使用注解，注解作用在类上面，方法上面，属性上面 
（3）使用注解目的：简化 xml 配置 

2、Spring 针对 Bean 管理中创建对象提供注解 
（1）**@Component** 
（2）**@Service** 
（3）**@Controller** 
（4）**@Repository** 
上面四个注解功能是一样的，都可以用来创建 bean实例，可以根据文件作用用不同的，如servlet就可以@Service

**基于注解方式实现对象创建 ：**
步骤：
1、先引入依赖  ：spring-aop-版本号.jar

##### ==2.开启组件扫描 :==

==先在spring配置文件引入名称空间context,详情见上面的示例==，然后添加：
<context:component-scan base-package="包名"><</context:component-scan>> 
**如果扫描多个包，多个包使用逗号隔开**     扫描包上层目录 

可以开启组件扫描**细节配置** ：

```xml
<!--
use-default-filters="false" 表示现在不使用默认 filter ，自己配置 filter    
context: include-filter ，设置扫描哪些内容
 -->

//只扫描DaoUtil包下的有Controller注解的
<context:component-scan base-package="DaoUtil" use-default-filters="false">
    <context:include-filter type="annotation" expression="org.springframework.stereotype.Controller"/>
</context:component-scan>

//context:exclude-filter ： 设置哪些内容不进行扫描 
<context:component-scan base-package="DaoUtil">     
        <context:exclude-filter type="annotation"                             expression="org.springframework.stereotype.Controller"/> 
</context:component-scan>
```



##### 3.在类上面添加创建对象注解 

// **在注解里面 value 属性值可以省略不写** 
// **默认值是类名称，首字母小写**
 //UserService -- userService

```java
@Component   
或  @Component(value = "userService")  //等于<bean id="userService" class=".."/>
public class UserService {    
public void add() {         
System. out .println("service add......."); 
} 
} 
```

##### 4.基于注解方式实现属性注入 

**@Autowired：根据属性类型进行自动装配，一定要注意这个** 
**@Qualifier：根据名称进行注入，具体的哪个实现类,和上面@Autowired 一起使用 ** 
@Resource：可以根据类型注入，可以根据名称注入 (不建议用)
**@Value：注入普通类型属性** 

（1）**@Autowired：根据属性类型进行自动装配** 

**就是将该类的   自身或其实现类(因为该类可能是接口)注入，  不用命名**

```java
第一步 把 service 和 dao 对象创建，在 service 和 dao 类添加创建对象注解 
第二步 在 service 注入 dao 对象，在 service 类添加 dao 类型属性，在属性上面使用注解 
注意：UserDao是接口  实现类可能有多个

UserService类::
@Service 
public class UserService {     
// 定义 dao 类型属性     
// 不需要添加 set 方法    
// 添加注入属性注解  (必须) 会自动注入该属性的子类对象  比如就是实现了该接口的实现类

@Autowired     
private UserDao userDao; //这里其实是UserDaoTest1对象注入了

public void add() {      
    System. out .println("service add.......");         
    userDao.add();     
    } 
} 


UserDaoTest1类::
@Repository
public class UserDaoTest1 implements UserDao {
    public void add(){
        System.out.println("test1..........");
    }
}
######################################
但由于该接口可能有多个实现类，所以用这种方法可能在添加注入属性注解时不知道用那个实现类
```

（2）**@Qualifier：根据名称进行注入** 
这个@Qualifier 注解的使用，和上面@Autowired 一起使用 

**可以将类添加名称   根据具体的名称注入**

```java
// 定义 dao 类型属性 
// 不需要添加 set 方法  
// 添加注入属性注解 
@Autowired  // 根据类型进行注入 
@Qualifier(value = "userDaoTest1") // 根据名称进行注入 记得userDaoTest1类要添加                                           value值哦
private UserDao userDao;


UserDaoTest1类::
@Repository(value = "userDaoTest1")
public class UserDaoTest1 implements UserDao {
  ................
}
```

（3）@Resource：可以根据类型注入，可以根据名称注入 (不建议用)

```java
//@Resource  
// 根据类型进行注入 
@Resource(name = "userDaoImpl1")  // 根据名称进行注入
 private UserDao userDao; 
```

（4）**@Value：注入普通类型属性** 

```java
@Value(value = "abc") 
private String name; 
```

6、**完全注解开发** 

完全注解开发就是**SpringBoot**
（1）创建配置类，替代 xml 配置文件 

```java
@Configuration  // 作为配置类，替代 xml 配置文件
@ComponentScan(basePackages = {"包名"}) 
public class SpringConfig { } 
```

（2）编写测试类 

```java
@Test 
public void testService2() {     
// 加载配置类  和加载xml文件所用的 方法不同
ApplicationContext context  = new AnnotationConfigApplicationContext(SpringConfig.class);    UserService userService = context.getBean("userService", UserService.class);    
   System. out .println(userService);    
  userService.add(); 
} 
```



## AOP

通俗易懂的讲解：https://blog.csdn.net/bookssea/article/details/107092569

1、什么是 AOP 
（1）面向切面编程（方面），利用 AOP 可以对业务逻辑的各个部分进行隔离，从而使得 业务逻辑各部分之间的耦合度降低，提高程序的可重用性，同时提高了开发的效率。 

（2）通俗描述：**不通过修改源代码方式，在主干功能里面添加新功能** 

 使用登录例子说明 AOP 

![1607045705935](Spring.assets/1607045705935.png)

AOP底层原理: 有两种情况动态代理  

![1603853357571](Spring.assets/1603853357571.png)



### AOP（术语） 

1、连接点
     类里面哪些方法可以被增强,这些方法称为连接点
2、切入点
     实际被真正增强的方法，称为切入点
3、通知（增强)
(1）实际增强的逻辑部分称为通知（增强)
(2）通知有多钟类型

4、切面 
是动作
(1)把通知应用到切入点过程

#### AOP 操作（==准备工作==）

Spring 框架一般都是基于 AspectJ 实现 AOP 操作 
 1、导入AspectJ 依赖    在pom.xml文件配置

```xml
 <dependency>
      <groupId>org.aspectj</groupId>
      <artifactId>aspectjrt</artifactId>
      <version>1.9.2</version>
    </dependency>
```

 2、在spring配置文件开启注解扫描 **并** 引入空间名称 aop  和 开启 Aspect 生成代理对象 

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
 xmlns:context="http://www.springframework.org/schema/context"
 xmlns:aop="http://www.springframework.org/schema/aop"
 xsi:schemaLocation="http://www.springframework.org/schema/beans
http://www.springframework.org/schema/beans/spring-beans.xsd
 http://www.springframework.org/schema/context
http://www.springframework.org/schema/context/spring-context.xsd
 http://www.springframework.org/schema/aop
http://www.springframework.org/schema/aop/spring-aop.xsd">
 <!-- 开启注解扫描 -->
 <context:component-scan basepackage="com.atguigu.spring5.aopanno"></context:component-scan>
<!-- 开启 Aspect 生成代理对象-->
<aop:aspectj-autoproxy></aop:aspectj-autoproxy>
```

3、准备切入点表达式   

#### 切入点表达式 

（1）切入点表达式作用：**知道对哪个类里面的哪个方法进行增强** 
（2）语法结构： execution([权限修饰符] [返回类型] [类全路径] [方法名称]([参数列表]) ) 

举例 1：对 com.atguigu.dao.BookDao 类里面的 add 进行增强 
execution(*  com.atguigu.dao.BookDao.add(..)) 
举例 2：对 com.atguigu.dao.BookDao 类里面的所有的方法进行增强 
execution(*  com.atguigu.dao.BookDao.* (..)) 
举例 3：对 com.atguigu.dao 包里面所有类，类里面所有方法进行增强 
execution(*  com.atguigu.dao.*.* (..)) 

<img src="Spring.assets/1603866306611.png" alt="1603866306611" style="zoom:67%;" />

**注意**：不知道为什么 在方法参数里加  ..  号

#### 通知类型

| 类型                                                         | 注解格式                                                     | spring配置文件格式    |
| ------------------------------------------------------------ | ------------------------------------------------------------ | --------------------- |
| **前置通知**                                                 | @Before(value = "切入点表达式")                              | 见下面的完全spring... |
| **后置通知**                                                 | @AfterReturning(value = "切入点表达式")                      |                       |
| **环绕通知**                                                 | @Around(value = "切入点表达式")                              |                       |
| **异常通知**                                                 | @AfterThrowing(value = "切入点表达式")                       |                       |
| **最终通知**                                                 | @After(value = "切入点表达式")                               |                       |
| 其它                                                         |                                                              |                       |
| ==生成代理对象==                                             | @Aspect                                                      | 见下面的代码          |
| ==相同的切入点抽取==：<br />把相同的切入点表达式提取出来     | @Pointcut(value = "切入点表达式")<br />public void pointdemo(){}<br />然后比如这样：<br />@Before(value = "pointdemo()") |                       |
| ==设置增强类优先级==：<br />有多个增强类多同一个方法进行增强 | @Order(数字类型值)   <br />数字类型值越小优先级越高<br />比如@Order(1) |                       |

#### 实例

要先完成 前面的准备工作

User类

```java
@Component
public class User {    
  public void add() {        
  System. out .println("User add......");    
} 
} 
```

UserProxy类（增强类）

```java
@Component //创建对象
@Aspect    // 生成代理对象 
public class UserProxy {
  //相同的切入点抽取
    @Pointcut(value = "execution(* DaoUtil.User.add(..))")  
    public void pointdemo(){}
  //前置通知
    @Before(value = "pointdemo()")
    public void before(){
        System.out.println("前置通知：before");
    }
  //后置通知
    @AfterReturning(value = "pointdemo()")
    public void afterReturning(){
        System.out.println("后置通知：afterReturning");
    }
}
```

测试类

```java
public class test1 {
    public static void main(String[] args) {
        //1 加载 spring 配置文件
        ApplicationContext context=
                new ClassPathXmlApplicationContext("bean1.xml");
        //2 获取配置创建的对象
        User user = context.getBean("user", User.class);
       // user.add();
        user.add();
    }
}

结果：
前置通知：before
User add......
后置通知：afterReturning
```

**完全使用注解开发（了解）** 

```java
创建配置类，不需要创建 xml 配置文件 
@Configuration 
@ComponentScan(basePackages = {"com.atguigu"}) 
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class ConfigAop { }
```

**完全使用spring配置文件xml格式:**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
 xmlns:aop="http://www.springframework.org/schema/aop"
 xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd
 http://www.springframework.org/schema/aop http://www.springframework.org/schema/aop/spring-aop-4.3.xsd">
 <!-- 目标对象 -->
 <bean id="knight" class="com.cjh.aop2.BraveKnight"/>
 <!-- 切面bean -->
 <bean id="mistrel" class="com.cjh.aop2.Minstrel"/>
 <!-- 面向切面编程 -->
 <aop:config>
 <!-- 设置切面 -->
 <aop:aspect ref="mistrel">
  <!-- 定义切点 -->
  <aop:pointcut expression="execution(* *.saying(..))" id="embark"/>
  <!-- 声明前置通知 (在切点方法被执行前调用)-->
  <aop:before method="beforSay" pointcut-ref="embark"/>
  <!-- 声明后置通知 (在切点方法被执行后调用)-->
  <aop:after method="afterSay" pointcut-ref="embark"/>
 </aop:aspect>
 </aop:config>
</beans>
```



## JdbcTemplate

1、什么是 JdbcTemplate 
     Spring 框架对 JDBC 进行封装，使用 JdbcTemplate 方便实现对数据库操作 

### **准备工作**

1、引入相关 jar 包 ：spring-jdbc包    spring-tx包(和事务相关)  连接池的jar包(这里用druid)  mysql-connector包
在maven项目下依赖

```xml
<!--阿里连接池-->
<dependency>
      <groupId>com.alibaba</groupId>
      <artifactId>druid</artifactId>
      <version>1.2.1</version>
    </dependency>
    
     <dependency>
      <groupId>mysql</groupId>
      <artifactId>mysql-connector-java</artifactId>
      <version>8.0.19</version>
    </dependency>
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-jdbc</artifactId>
      <version>5.2.9.RELEASE</version>
    </dependency>
    
  <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-tx</artifactId>
      <version>5.2.9.RELEASE</version>
    </dependency>
```

2、在 spring 配置文件配置数据库连接池 **并** 配置 JdbcTemplate 对象，注入 DataSource 

最好载入外部资源文件properties

```xml
<!--把外部 properties 属性文件引入到 spring 配置文件中
* 引入 context 名称空间-->
<beans 
xmlns:context="http://www.springframework.org/schema/context"
...................
xsi:schemaLocation="........
                    http://www.springframework.org/schema/context
http://www.springframework.org/schema/context/spring-context.xsd">
</beans>


<!--载入外部资源文件mysqlconn.properties-->   
<context:property-placeholder location="classpath:mysqlconn.properties"/>
   <!--配置连接池-->
   <bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource">
        <property name="url" value="${url}" />
        <property name="username" value="${user}" />
        <property name="password" value="${password}" />
        <property name="driverClassName" value="${driver}" />
    </bean>
    
     <!-- JdbcTemplate 对象 -->
    <bean id="jdbcTemplate" class="org.springframework.jdbc.core.JdbcTemplate">
        <!-- 注入 dataSource -->
        <property name="dataSource" ref="dataSource"></property>
    </bean>
  <!-- 组件扫描 -->
<context:component-scan base-package="com.atguigu"></context:component-scan>  

  <!--    
mysqlconn.properties内容：
driver=com.mysql.jdbc.Driver
url=jdbc:mysql://127.0.0.1:3306/test?&useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8
user=root
password=182008
-->
```

### 实例

BookDaoImpl实现类     要新建BookDao接口

```java
@Component
public class BookDaoImpl implements BookDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void add(User user) {
        String sql = "insert into user(name,pwd) values(?,?)";
        Object[] args = {user.getName(),user.getPws()};
        int update = jdbcTemplate.update(sql,args);
        System.out.println(update);

    }
}
```

Bookservice类

```
@Service
public class Bookservice {
    @Autowired
    private BookDao bookDao;

    public void addBook(User user){
        bookDao.add(user);
    }

}
```

User类（略）

测试类

```
public class test1 {
    public static void main(String[] args) {
        //1 加载 spring 配置文件
        ApplicationContext context=
                new ClassPathXmlApplicationContext("bean1.xml");
        //2 获取配置创建的对象
        Bookservice user = context.getBean("bookservice", Bookservice.class);
       // user.add();
        User user1 = new User();
        user1.setName("得到ddd");
        user1.setPws("0000202");
        user.addBook(user1);
    }
}
```

### 方法

JdbcTemplate主要提供以下五类方法：

- execute方法：可以用于执行任何SQL语句，一般用于执行DDL语句；
- update方法及batchUpdate方法：update方法用于执行新增、修改、删除等语句；batchUpdate方法用于执行批处理相关语句；
- query方法及queryForXXX方法：用于执行查询相关语句；
- call方法：用于执行存储过程、函数相关语句。 

**JdbcTemplate类支持的回调类（略）**

其他方法自己百度

(完)



## 事务操作

什么是事务（通俗解释）：

 https://blog.csdn.net/weixin_38070406/article/details/78308222 

事务是数据库操作最基本单元，逻辑上一组操作，要么都成功，如果有一个失败所有操作都失败 

### spring事务实例

具体的看  pdf  和  https://blog.csdn.net/CHINACR07/article/details/78817449



## Spring和junit集成测试

**第一步：在项目导入 spring-test的jar包**

```
<dependency>
   <groupId>org.springframework</groupId>
   <artifactId>spring-test</artifactId>
   <version>4.1.3.RELEASE</version>
</dependency>
```

**第二步： 使用 @RunWith注解 和 @ContextConfiguration 注解 集成测试**

```

@RunWith(SpringJUnit4ClassRunner.class)
//使用spring内核的一个地方去跑，它帮我进行一个测试

@ContextConfiguration(locations = "classpath:applicationContext.xml")
//指定配置文件的位置,xml方式
//@ContextConfiguration(classes = {UserService.class})
//注解方式，后面是具体的类


public class UserControllerTest {
    @Autowired
    private UserService userService;//测试userService
    
    @Test
    public void findUserById() throws Exception {
        System.out.println(userService.findUserById(1L));
    }
}
```



## spring集成web环境

因为第一步加载配置文件

```
//1 加载 spring 配置文件
        ApplicationContext context=
                new ClassPathXmlApplicationContext("bean1.xml");
//2 获取配置创建的对象
Bookservice user = context.getBean("bookservice", Bookservice.class);
```

每次都要调用，重复的代码太多了。所以为了优化，可以:
将步骤1的代码放到监听器中去，将spring的应用上下文对象context存储在ServletContext中（用.setAttribute)，实现在web程序启动的时候自动加载 （当然，这步之前bean1.xml文件名会存储在web.xml文件中），然后获取（用getAttribute）

**但这些步骤都有spring-web包封装了，所以拿来用就可以了**

**具体步骤：**

**第一步：在项目导入 spring-web的jar包，并配置ContextLoaderListener监听器** 

```
<dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-web</artifactId>
      <version>5.0.5.RELEASE</version>
    </dependency>
```

```
<!--全局初始化参数，将spring配置文件的名字当作value值-->
 <context-param>
    <param-name>contextConfigLocation</param-name>
    <param-value>classpath:bean1.xml</param-value>
  </context-param>

<!--配置监听器，用第三方包的，它什么都配置好了，用就行了-->
<listener>
  <listener-class>org.springframework.web.context.ContextLoaderListener</listener-class>
</listener>

<servlet>
................
```

**第二步，在servlet文件的doGet等方法中使用WebApplicationContextUtil获得应用上下文**

```
  ServletContext servletContext = this.getServletContext();
        ApplicationContext app = WebApplicationContextUtils.getWebApplicationContext(servletContext);
        UserService userService = app.getBean(UserService.class);
        
//getWebApplicationContext返回之前存储的ApplicationContext对象
```



## 其他问题

**IDEA中Spring配置错误：class path resource [.xml] cannot be opened because it does not exist**

见：https://blog.csdn.net/baidu_32045201/article/details/78386058



Spring加载properties文件的两种方式:

https://blog.csdn.net/eson_15/article/details/51365707


